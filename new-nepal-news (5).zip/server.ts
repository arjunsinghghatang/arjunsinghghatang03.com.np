import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// API Endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    company: 'New Nepal News Pvt. Ltd.',
    headOffice: 'Waling Syangja Nepal',
    timestamp: new Date().toISOString(),
  });
});

// Gemini AI News Summarizer
app.post('/api/ai/summarize', async (req, res) => {
  try {
    const { title, content, language } = req.body;
    if (!content) {
      return res.status(400).json({ error: 'Article content is required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.json({
        summary:
          language === 'np'
            ? `• ${title}\n• सम्पादकीय विश्लेषण: आधिकारिक स्रोत तथा स्थानीय वालिङ ब्युरोसँग समन्वय गरी तयार पारिएको सामग्री।\n• यस घटनाले आगामी दिनमा विकास, नीतिगत सुधार र समाजमा सकारात्मक प्रभाव पार्ने अपेक्षा छ।`
            : `• Key Focus: ${title}\n• Comprehensive overview verified by New Nepal News editorial team in Waling.\n• Expected to drive key policy improvements and economic interest across Gandaki Province.`,
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const targetLangPrompt =
      language === 'np'
        ? 'in Nepali language (नेपाली भाषामा विन्दुगत रूपमा)'
        : 'in 3 clear bullet points in English';

    const prompt = `You are an executive news editor for "New Nepal News Pvt. Ltd." (Headquartered in Waling, Syangja, Nepal). Provide a crisp, unbiased 3-bullet summary ${targetLangPrompt} for the following news piece:

Headline: ${title}
Article Text: ${content}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    res.json({ summary: response.text });
  } catch (err: any) {
    console.error('Error in AI summary:', err);
    res.status(500).json({ error: 'Failed to generate AI summary.' });
  }
});

// Gemini AI News Desk Q&A Bot
app.post('/api/ai/ask', async (req, res) => {
  try {
    const { question, language } = req.body;
    if (!question) {
      return res.status(400).json({ error: 'Question is required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.json({
        answer:
          language === 'np'
            ? `नमस्ते! न्यू नेपाल न्यूज प्रा. लि. को सम्पादकीय डेस्कमा स्वागत छ। तपाईंको प्रश्न "${question}" सम्बन्धी जानकारी: वालिङ स्याङ्जा प्रधान कार्यालयबाट सम्प्रेषित समाचारहरू निष्पक्ष र तथ्यपरक हुन्छन्।`
            : `Hello! Welcome to the New Nepal News Pvt. Ltd. Editorial Desk. Regarding "${question}": We provide 24/7 verified journalism from Syangja and across Nepal.`,
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `You are the AI Editorial Desk Assistant for New Nepal News Pvt. Ltd., an independent digital news platform based in Waling, Syangja, Nepal. Answer the user's question accurately, politely, and succinctly in ${
      language === 'np' ? 'Nepali (नेपाली)' : 'English'
    }. Keep it professional like a news organization representative.

User Question: ${question}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    res.json({ answer: response.text });
  } catch (err: any) {
    console.error('Error in AI Ask:', err);
    res.status(500).json({ error: 'Failed to process AI query.' });
  }
});

// Newsletter Subscription
app.post('/api/newsletter/subscribe', (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes('@')) {
    return res.status(400).json({ message: 'Valid email required' });
  }
  return res.json({
    success: true,
    message: 'Successfully subscribed to New Nepal News Daily Digest!',
  });
});

// News Tip Submission
app.post('/api/tips/submit', (req, res) => {
  const { name, email, phone, location, details, category } = req.body;
  if (!details) {
    return res.status(400).json({ message: 'Tip details required' });
  }
  const trackingCode =
    'NNN-' + Math.floor(100000 + Math.random() * 900000).toString();
  return res.json({
    success: true,
    trackingCode,
    message: `Thank you, ${
      name || 'Citizen Reporter'
    }! Your news tip has been received by our editorial desk in Waling, Syangja. Tracking Code: ${trackingCode}`,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
