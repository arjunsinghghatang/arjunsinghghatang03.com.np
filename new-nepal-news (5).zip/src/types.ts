export type CategoryId =
  | 'breaking'
  | 'politics'
  | 'business'
  | 'technology'
  | 'sports'
  | 'entertainment'
  | 'health'
  | 'education'
  | 'tourism'
  | 'opinion'
  | 'international';

export interface Category {
  id: CategoryId;
  nameEn: string;
  nameNp: string;
  descriptionEn: string;
  descriptionNp: string;
  iconName: string;
  color: string;
}

export interface Comment {
  id: string;
  author: string;
  avatar?: string;
  date: string;
  content: string;
  likes: number;
}

export interface NewsArticle {
  id: string;
  titleEn: string;
  titleNp: string;
  excerptEn: string;
  excerptNp: string;
  contentEn: string;
  contentNp: string;
  category: CategoryId;
  author: string;
  authorRole: string;
  authorAvatar?: string;
  publishedAt: string;
  readTimeMinutes: number;
  imageUrl: string;
  imageCaptionEn?: string;
  imageCaptionNp?: string;
  isBreaking?: boolean;
  isTrending?: boolean;
  isFeatured?: boolean;
  isEditorPick?: boolean;
  views: number;
  reactions: {
    like: number;
    important: number;
    inspiring: number;
    sad: number;
  };
  tags: string[];
  comments: Comment[];
  location?: string;
  videoUrl?: string;
  isWorldNews?: boolean;
  isNepalViral?: boolean;
  sourceAgency?: string;
  safetyStatus?: 'verified_safe' | 'filter_passed';
  autoStreamTimestamp?: string;
}

export interface TeamMember {
  id: string;
  nameEn: string;
  nameNp: string;
  roleEn: string;
  roleNp: string;
  bioEn: string;
  bioNp: string;
  email: string;
  avatar: string;
  socials: {
    facebook?: string;
    twitter?: string;
    linkedin?: string;
  };
}

export interface ServiceItem {
  id: string;
  titleEn: string;
  titleNp: string;
  descEn: string;
  descNp: string;
  icon: string;
}

export interface AdPackage {
  id: string;
  titleEn: string;
  titleNp: string;
  priceNpr: string;
  impressions: string;
  featuresEn: string[];
  featuresNp: string[];
  recommended?: boolean;
}

export interface CareerJob {
  id: string;
  titleEn: string;
  titleNp: string;
  departmentEn: string;
  departmentNp: string;
  typeEn: string;
  typeNp: string;
  locationEn: string;
  locationNp: string;
  deadline: string;
  descriptionEn: string;
  descriptionNp: string;
  requirementsEn: string[];
  requirementsNp: string[];
}

export interface VideoNews {
  id: string;
  titleEn: string;
  titleNp: string;
  thumbnailUrl: string;
  duration: string;
  youtubeId: string;
  publishedAt: string;
  category: CategoryId;
  views: string;
}

export interface ReelStoryItem {
  id: string;
  titleEn: string;
  titleNp: string;
  creatorName: string;
  creatorAvatar: string;
  videoUrl?: string;
  thumbnailUrl: string;
  views: number;
  likes: number;
  commentsCount: number;
  sharesCount: number;
  publishedAt: string;
  category: CategoryId;
  articleId?: string;
  duration?: string;
  isVerified?: boolean;
}

export type PageView =
  | 'home'
  | 'latest'
  | 'reels'
  | 'category'
  | 'article'
  | 'about'
  | 'team'
  | 'contact'
  | 'services'
  | 'careers'
  | 'legal'
  | 'gallery'
  | 'analytics';

export type Language = 'en' | 'np';

export interface WeatherInfo {
  locationEn: string;
  locationNp: string;
  temp: number;
  conditionEn: string;
  conditionNp: string;
  high: number;
  low: number;
}
