import logoImg from '../assets/images/new_nepal_news_logo_1786013344493.jpg';

export const NEW_NEPAL_NEWS_LOGO = logoImg;
