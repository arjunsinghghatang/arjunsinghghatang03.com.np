export interface AdItem {
  id: string;
  titleEn: string;
  titleNp: string;
  sponsorEn: string;
  sponsorNp: string;
  taglineEn: string;
  taglineNp: string;
  categoryEn: string;
  categoryNp: string;
  image: string;
  ctaEn: string;
  ctaNp: string;
  badgeEn?: string;
  badgeNp?: string;
  phone?: string;
  locationEn?: string;
  locationNp?: string;
  offerDiscount?: string;
  videoPreviewUrl?: string;
  accentColor?: string;
}

export const adsData: AdItem[] = [
  {
    id: 'ad-1',
    titleEn: 'Waling Fibernet 300 Mbps Ultra Broadband',
    titleNp: 'वालिङ फाइबरनेट ३०० Mbps अति द्रुत गति इन्टरनेट',
    sponsorEn: 'Syangja Fibernet Cable Pvt. Ltd.',
    sponsorNp: 'स्याङ्जा फाइबरनेट केबल प्रा. लि.',
    taglineEn: 'Seamless 4K Streaming, Fiber TV & Unlimited Connectivity in Waling Syangja',
    taglineNp: 'वालिङ स्याङ्जामा ४K स्ट्रिमिङ, फाइबर टिभी र असीमित इन्टरनेट सुविधा',
    categoryEn: 'Telecommunications & Broadband',
    categoryNp: 'दूरसञ्चार तथा ब्रॉडब्यान्ड',
    image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Get Free Installation: +977-063-440123',
    ctaNp: 'निःशुल्क जडानका लागि: +९७७-०६३-४४०१२३',
    badgeEn: 'SPONSORED AD',
    badgeNp: 'प्रायोजित विज्ञापन',
    phone: '+977-063-440123',
    locationEn: 'Waling-8, Syangja',
    locationNp: 'वालिङ-८, स्याङ्जा',
    offerDiscount: 'Free Router + 20% OFF',
    accentColor: 'from-blue-600 to-indigo-800'
  },
  {
    id: 'ad-2',
    titleEn: 'Gandaki Green Energy & Clean Hydro Summit 2026',
    titleNp: 'गण्डकी हरित ऊर्जा तथा स्वच्छ जलविद्युत् सम्मेलन २०८२',
    sponsorEn: 'Gandaki Hydro & Renewable Energy Association',
    sponsorNp: 'गण्डकी जलविद्युत् तथा नविकरणीय ऊर्जा संघ',
    taglineEn: 'Invest in Nepal’s Clean Energy Future | Sep 15 - 18, Pokhara City Hall',
    taglineNp: 'नेपालको स्वच्छ ऊर्जा क्षेत्रमा लगानी गर्नुहोस् | भदौ ३० - असोज २, पोखरा सभाहल',
    categoryEn: 'Energy & Investment',
    categoryNp: 'ऊर्जा तथा लगानी',
    image: 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Book Expo Stall / Free Pass',
    ctaNp: 'स्टल बुकिङ तथा प्रवेश पास',
    badgeEn: 'MAJOR SPONSOR',
    badgeNp: 'मुख्य प्रायोजक',
    phone: '+977-061-532100',
    locationEn: 'Pokhara & Waling Desk',
    locationNp: 'पोखरा तथा वालिङ न्युजरुम',
    offerDiscount: 'Early Bird 15% Pass Discount',
    accentColor: 'from-emerald-600 to-teal-800'
  },
  {
    id: 'ad-3',
    titleEn: 'Syangja Fresh Organic Citrus & CTC Himalaya Tea',
    titleNp: 'स्याङ्जा अर्गानिक सुन्तला जुस तथा हिमालयन सीटीसी चिया',
    sponsorEn: 'Himalayan Organic Tea & Agro Farm Waling',
    sponsorNp: 'हिमालयन अर्गानिक टी तथा एग्रो फार्म वालिङ',
    taglineEn: '100% Export Quality Garden Fresh Citrus Juices & Special CTC Tea',
    taglineNp: '१००% शुद्ध प्राङ्गारिक स्याङ्जाली सुन्तला रस र सीटीसी चिया',
    categoryEn: 'Agriculture & Exports',
    categoryNp: 'कृषि तथा निर्यात',
    image: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Order Home Delivery Online',
    ctaNp: 'अनलाइन होम डेलिभरी अर्डर',
    badgeEn: 'LOCAL BRAND',
    badgeNp: 'स्थानीय उत्पादन',
    phone: '+977-9856012345',
    locationEn: 'Putalibazar, Syangja',
    locationNp: 'पुतलीबजार, स्याङ्जा',
    offerDiscount: 'Buy 2 Get 1 Free',
    accentColor: 'from-amber-600 to-orange-700'
  },
  {
    id: 'ad-4',
    titleEn: 'Namaste Nepal Airlines - Pokhara & Kathmandu Flights',
    titleNp: 'नमस्ते नेपाल एयरलाइन्स - पोखरा र काठमाडौँ दैनिक उडान',
    sponsorEn: 'Namaste Nepal Domestic Aviation Pvt. Ltd.',
    sponsorNp: 'नमस्ते नेपाल आन्तरिक उड्डयन प्रा. लि.',
    taglineEn: 'Daily Scenic Flights with On-Time Guarantee & Premium In-flight Comfort',
    taglineNp: 'नियमित उडान, समयमै प्रस्थान र उत्कृष्ट हवाई यात्रा अनुभव',
    categoryEn: 'Aviation & Travel',
    categoryNp: 'हवाई सेवा तथा पर्यटन',
    image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Book Air Tickets with 20% Off',
    ctaNp: '२०% छुटमा टिकट बुकिङ गर्नुहोस्',
    badgeEn: 'PREMIUM AIRLINE',
    badgeNp: 'प्रिमियम उडान सेवा',
    phone: '+977-01-4432111',
    locationEn: 'Kathmandu / Pokhara Airport',
    locationNp: 'काठमाडौँ / पोखरा विमानस्थल',
    offerDiscount: '20% Special Fare Discount',
    accentColor: 'from-red-600 to-rose-900'
  },
  {
    id: 'ad-5',
    titleEn: 'Syangja Multipurpose Co-operative & Smart Banking',
    titleNp: 'स्याङ्जा बहुउद्देश्यीय सहकारी तथा मोबाइल बैंकिङ',
    sponsorEn: 'Syangja Citizens Co-operative Bank Ltd.',
    sponsorNp: 'स्याङ्जा नागरिक सहकारी संस्था लि.',
    taglineEn: '9.5% High Fixed Returns & Instant Micro Loans for Small Businesses',
    taglineNp: '९.५% उच्च मुद्दती ब्याजदर र साना व्यवसायीका लागि तत्काल ऋण सुविधा',
    categoryEn: 'Banking & Cooperatives',
    categoryNp: 'बैंकिङ तथा सहकारी',
    image: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Open Account with Mobile App',
    ctaNp: 'मोबाइल एपबाटै खाता खोल्नुहोस्',
    badgeEn: 'TRUSTED BANKING',
    badgeNp: 'विश्वासिलो सहकारी',
    phone: '+977-063-440555',
    locationEn: 'Waling Bazar, Syangja',
    locationNp: 'वालिङ बजार, स्याङ्जा',
    offerDiscount: 'Zero Fee Mobile Banking',
    accentColor: 'from-cyan-700 to-blue-900'
  },
  {
    id: 'ad-6',
    titleEn: 'Pokhara Annapurna Tandem Paragliding & Ultralight',
    titleNp: 'पोखरा अन्नपूर्ण टेन्डेम प्याराग्लाइडिङ तथा अल्ट्रालाइट',
    sponsorEn: 'Annapurna Sky Adventures Pokhara',
    sponsorNp: 'अन्नपूर्ण स्काई एड्भेन्चर्स पोखरा',
    taglineEn: 'Fly over Phewa Lake with Certified Pilots & Free 4K GoPro Videos',
    taglineNp: 'फेवाताल र अन्नपूर्ण हिमश्रृङ्खला माथि प्याराग्लाइडिङ र निःशुल्क ४K भिडियो',
    categoryEn: 'Tourism & Extreme Sports',
    categoryNp: 'पर्यटन तथा साहसिक खेल',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    ctaEn: 'Reserve Flight (25% Group Discount)',
    ctaNp: '२५% छुटमा उडान बुकिङ गर्नुहोस्',
    badgeEn: 'FEATURED ADVENTURE',
    badgeNp: 'विशेष साहसिक अनुभव',
    phone: '+977-061-465432',
    locationEn: 'Lakeside, Pokhara',
    locationNp: 'लेकसाइड, पोखरा',
    offerDiscount: 'Free 4K Video + Photo Package',
    accentColor: 'from-purple-600 to-indigo-900'
  }
];
