import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Radio, Maximize2, Sparkles, Film } from 'lucide-react';
import { Language, NewsArticle } from '../types';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface NewsAutoVideoPlayBarProps {
  article: NewsArticle;
  language: Language;
  onOpenVideoModal?: (article: NewsArticle) => void;
  compact?: boolean;
}

// Fallback high quality video streams for news field reports
const sampleVideoUrls = [
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyflights.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
];

export const NewsAutoVideoPlayBar: React.FC<NewsAutoVideoPlayBarProps> = ({
  article,
  language,
  onOpenVideoModal,
  compact = false,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Pick a video URL deterministically based on article id or use article.videoUrl
  const videoIndex = Math.abs(
    article.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)
  ) % sampleVideoUrls.length;
  
  const videoSrc = article.videoUrl || sampleVideoUrls[videoIndex];

  const handleTimeUpdate = () => {
    if (videoRef.current && videoRef.current.duration) {
      const current = videoRef.current.currentTime;
      const total = videoRef.current.duration;
      setProgress((current / total) * 100);
    }
  };

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  if (compact) {
    return (
      <div className="w-full bg-slate-950 text-white rounded-xl overflow-hidden border border-slate-800 shadow-md group relative mt-2">
        {/* Progress bar top */}
        <div className="w-full h-1 bg-slate-800">
          <div
            className="h-full bg-gradient-to-r from-red-600 to-amber-400 transition-all duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="p-2 flex items-center justify-between gap-2 text-xs">
          {/* Mini Video Player */}
          <div className="relative w-16 h-10 rounded-md overflow-hidden bg-black shrink-0 border border-slate-700">
            <video
              ref={videoRef}
              src={videoSrc}
              autoPlay
              loop
              muted={isMuted}
              playsInline
              onTimeUpdate={handleTimeUpdate}
              className="w-full h-full object-cover"
            />
            <button
              onClick={togglePlay}
              className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            >
              {isPlaying ? <Pause className="w-3 h-3 text-white" /> : <Play className="w-3 h-3 text-white fill-current" />}
            </button>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 text-[10px] text-amber-400 font-bold uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping" />
              <span>{language === 'np' ? 'भिडियो रिपोर्ट' : 'AUTO VIDEO REPORT'}</span>
            </div>
            <p className="text-[11px] text-slate-200 truncate font-medium">
              {language === 'np' ? article.titleNp : article.titleEn}
            </p>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={toggleMute}
              className="p-1 text-slate-400 hover:text-white transition-colors"
              title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-slate-400" /> : <Volume2 className="w-3.5 h-3.5 text-amber-400" />}
            </button>
            {onOpenVideoModal && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenVideoModal(article);
                }}
                className="p-1 text-slate-400 hover:text-amber-300"
                title="Full Video Mode"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 text-white rounded-2xl overflow-hidden border border-slate-800 shadow-xl relative group mt-3">
      {/* Animated Top Scrub Bar */}
      <div className="w-full h-1 bg-slate-800">
        <div
          className="h-full bg-gradient-to-r from-red-600 via-amber-400 to-emerald-400 transition-all duration-200"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="p-3 sm:p-4 flex flex-col sm:flex-row items-center gap-3">
        {/* Video Frame */}
        <div className="relative w-full sm:w-36 h-24 rounded-xl overflow-hidden bg-black shrink-0 border border-slate-700 shadow-inner group/video">
          <video
            ref={videoRef}
            src={videoSrc}
            autoPlay
            loop
            muted={isMuted}
            playsInline
            onTimeUpdate={handleTimeUpdate}
            className="w-full h-full object-cover group-hover/video:scale-105 transition-transform duration-500"
          />

          <div className="absolute inset-0 bg-slate-950/30 group-hover/video:bg-slate-950/10 transition-colors" />

          {/* Top Left Live Badge */}
          <div className="absolute top-1.5 left-1.5 bg-red-700/90 text-white text-[9px] font-black uppercase px-1.5 py-0.5 rounded-sm flex items-center gap-1 backdrop-blur-xs">
            <Radio className="w-2.5 h-2.5 animate-pulse text-amber-300" />
            <span>{language === 'np' ? 'भिडियो' : 'AUTO VIDEO'}</span>
          </div>

          {/* Top Right Logo Watermark Badge */}
          <div className="absolute top-1.5 right-1.5 bg-slate-950/80 backdrop-blur-xs px-1 py-0.5 rounded-md border border-white/20 flex items-center gap-1 shadow-md">
            <img src={NEW_NEPAL_NEWS_LOGO} alt="NNN" className="w-3 h-3 rounded-full object-cover border border-amber-300" />
          </div>

          {/* Center Play Overlay */}
          <button
            onClick={togglePlay}
            className="absolute inset-0 m-auto w-8 h-8 rounded-full bg-red-600/90 hover:bg-red-600 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          {/* Bottom Time */}
          <div className="absolute bottom-1 right-1 bg-black/80 text-[9px] font-mono text-slate-300 px-1 py-0.5 rounded-xs">
            02:15
          </div>
        </div>

        {/* Info Column */}
        <div className="flex-1 min-w-0 space-y-1 text-left w-full">
          <div className="flex items-center gap-2">
            <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-bold uppercase px-2 py-0.5 rounded-md flex items-center gap-1">
              <Film className="w-3 h-3 text-amber-400" />
              <span>{language === 'np' ? 'प्रत्यक्ष समाचार भिडियो क्लिप' : 'Auto Field Video Summary'}</span>
            </span>
            <span className="text-[10px] text-slate-400 hidden sm:inline">
              HD 1080p
            </span>
          </div>

          <h4 className="font-serif font-bold text-xs sm:text-sm text-slate-100 group-hover:text-amber-300 transition-colors line-clamp-1">
            {language === 'np' ? article.titleNp : article.titleEn}
          </h4>

          <p className="text-[11px] text-slate-400 line-clamp-1">
            {language === 'np'
              ? 'यस समाचारको स्थलगत भिडियो दृश्य तथा प्रत्यक्ष रिपोर्टिङ अंश स्वतः प्ले हुँदैछ।'
              : 'Auto-playing live video footage & field reporting snippet for this news story.'}
          </p>

          <div className="pt-1 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={togglePlay}
                className="text-[11px] font-bold text-slate-200 hover:text-amber-300 flex items-center gap-1"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-3 h-3 text-red-500" />
                    <span>{language === 'np' ? 'रोक्नुहोस्' : 'Pause'}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 text-amber-400 fill-current" />
                    <span>{language === 'np' ? 'प्ले गर्नुहोस्' : 'Play'}</span>
                  </>
                )}
              </button>
              <span className="text-slate-700">|</span>
              <button
                onClick={toggleMute}
                className="text-[11px] text-slate-300 hover:text-white flex items-center gap-1"
              >
                {isMuted ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                    <span>{language === 'np' ? 'आवाज खोल्नुहोस्' : 'Unmute Sound'}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>{language === 'np' ? 'म्युट गर्नुहोस्' : 'Muted'}</span>
                  </>
                )}
              </button>
            </div>

            {onOpenVideoModal && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenVideoModal(article);
                }}
                className="bg-red-700 hover:bg-red-600 text-white font-bold text-[10px] px-2.5 py-1 rounded-md transition-colors flex items-center gap-1 shadow-xs"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{language === 'np' ? 'पूर्ण भिडियो हेर्नुहोस्' : 'Full HD Video'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
