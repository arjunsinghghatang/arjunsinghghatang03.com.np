import React, { useState, useEffect } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2 } from 'lucide-react';
import { Language } from '../types';

interface ZoomControllerProps {
  language: Language;
}

export const ZoomController: React.FC<ZoomControllerProps> = ({ language }) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isOpen, setIsOpen] = useState<boolean>(false);

  useEffect(() => {
    // Apply zoom transform scale or body zoom if available
    const rootElement = document.getElementById('root');
    if (rootElement) {
      rootElement.style.transform = zoomLevel === 100 ? 'none' : `scale(${zoomLevel / 100})`;
      rootElement.style.transformOrigin = 'top center';
      rootElement.style.transition = 'transform 0.2s ease-out';
    }
  }, [zoomLevel]);

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 10, 200));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 10, 40));
  };

  const handleFitScreen = () => {
    const screenWidth = window.innerWidth;
    const fitPercent = Math.min(100, Math.max(40, Math.round((screenWidth / 1220) * 100)));
    setZoomLevel(fitPercent);
  };

  const handleReset = () => {
    setZoomLevel(100);
  };

  return (
    <div className="fixed top-20 right-3 z-50 flex flex-col items-end gap-1.5 pointer-events-auto">
      {/* Zoom Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-slate-900/95 text-amber-300 border border-slate-700 hover:border-amber-400 px-2.5 py-1.5 rounded-xl shadow-xl backdrop-blur-md flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer active:scale-95"
        title={language === 'np' ? 'जुम नियन्त्रण' : 'Zoom View Controls'}
      >
        <Maximize2 className="w-4 h-4 text-amber-400" />
        <span className="font-mono">{zoomLevel}%</span>
      </button>

      {/* Expanded Controls Box */}
      {isOpen && (
        <div className="bg-slate-950/95 text-white border border-slate-800 rounded-2xl p-3 shadow-2xl backdrop-blur-lg flex flex-col gap-2 min-w-[150px] animate-in fade-in slide-in-from-right-2 duration-200">
          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider text-center border-b border-slate-800 pb-1">
            {language === 'np' ? 'भ्यू जुम (ZOOM)' : 'VIEW ZOOM'}
          </div>

          <div className="flex items-center justify-between gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              onClick={handleZoomOut}
              disabled={zoomLevel <= 40}
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>

            <span className="text-xs font-mono font-bold text-amber-300 px-1">
              {zoomLevel}%
            </span>

            <button
              onClick={handleZoomIn}
              disabled={zoomLevel >= 200}
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-40 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={handleFitScreen}
            className="text-[11px] text-amber-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 py-1 px-2 rounded-xl flex items-center justify-center gap-1 font-medium transition-colors cursor-pointer"
          >
            <span>📱 {language === 'np' ? 'स्क्रिनमा मिलाउनुहोस्' : 'Fit Screen'}</span>
          </button>

          <button
            onClick={handleReset}
            className="text-[11px] text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 py-1 px-2 rounded-xl flex items-center justify-center gap-1 font-medium transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3 text-amber-400" />
            <span>{language === 'np' ? '१००% रिसेट' : '100% Desktop'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
