import React, { useState, useEffect } from 'react';
import { Clock, Calendar, MapPin } from 'lucide-react';
import { Language } from '../types';

interface NepalLiveClockProps {
  language: Language;
}

export const NepalLiveClock: React.FC<NepalLiveClockProps> = ({ language }) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Format time in Nepal Timezone (Asia/Kathmandu UTC+5:45)
  const nepaliTime = currentTime.toLocaleTimeString('ne-NP', {
    timeZone: 'Asia/Kathmandu',
    hour12: true,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const nepaliDate = currentTime.toLocaleDateString('ne-NP', {
    timeZone: 'Asia/Kathmandu',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const englishTime = currentTime.toLocaleTimeString('en-US', {
    timeZone: 'Asia/Kathmandu',
    hour12: true,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const englishDate = currentTime.toLocaleDateString('en-US', {
    timeZone: 'Asia/Kathmandu',
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
      <div className="inline-flex items-center gap-1.5 bg-red-50 text-red-700 px-2.5 py-1 rounded-lg border border-red-200/80 font-medium shadow-2xs">
        <MapPin className="w-3.5 h-3.5 text-red-600 shrink-0" />
        <span className="font-bold">नेपाल समय (Nepal Standard Time):</span>
        <span className="font-mono font-bold text-red-800 text-xs sm:text-sm">
          {language === 'np' ? nepaliTime : englishTime}
        </span>
      </div>

      <div className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 font-medium">
        <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
        <span className="text-slate-800 font-serif">
          {language === 'np' ? nepaliDate : englishDate}
        </span>
      </div>
    </div>
  );
};
