import React, { useState } from 'react';
import { Zap, Pause, Play, ChevronRight } from 'lucide-react';
import { NewsArticle, Language } from '../types';
import { getTranslation } from '../data/translations';

interface BreakingTickerProps {
  articles: NewsArticle[];
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
}

export const BreakingTicker: React.FC<BreakingTickerProps> = ({
  articles,
  language,
  onArticleClick,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  const breakingList = articles.filter((a) => a.isBreaking || a.category === 'breaking');
  const items = breakingList.length > 0 ? breakingList : articles.slice(0, 3);

  if (items.length === 0) return null;

  const currentItem = items[currentIndex % items.length];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % items.length);
  };

  return (
    <div className="bg-red-700 text-white border-b border-red-800 py-2 px-4 sm:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs sm:text-sm">
        {/* Left Badge */}
        <div className="flex items-center gap-2 bg-red-950 text-amber-300 font-extrabold uppercase px-3 py-1 rounded-md shrink-0 shadow-xs tracking-wider animate-pulse">
          <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
          <span>{getTranslation(language, 'breakingNews')}</span>
        </div>

        {/* Ticker Headline */}
        <div
          onClick={() => onArticleClick(currentItem)}
          className="flex-1 truncate cursor-pointer hover:underline font-medium text-slate-100 flex items-center gap-2"
        >
          <span className="bg-red-800 text-white text-[10px] font-bold px-2 py-0.5 rounded-xs shrink-0">
            {currentItem.location || 'Syangja'}
          </span>
          <span className="truncate">
            {language === 'np' ? currentItem.titleNp : currentItem.titleEn}
          </span>
        </div>

        {/* Controls */}
        <div className="hidden sm:flex items-center gap-2 text-red-200">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1 hover:text-white rounded-xs transition-colors cursor-pointer"
            title={isPlaying ? 'Pause Ticker' : 'Play Ticker'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={handleNext}
            className="p-1 hover:text-white rounded-xs transition-colors cursor-pointer flex items-center gap-1 font-semibold"
          >
            <span>Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
