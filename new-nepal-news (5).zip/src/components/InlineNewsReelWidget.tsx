import React from 'react';
import { Play, Film, Flame, Eye, Sparkles, Volume2 } from 'lucide-react';
import { ReelStoryItem, Language } from '../types';

interface InlineNewsReelWidgetProps {
  reel: ReelStoryItem;
  language: Language;
  onOpenReel: (reel: ReelStoryItem) => void;
  compact?: boolean;
}

export const InlineNewsReelWidget: React.FC<InlineNewsReelWidgetProps> = ({
  reel,
  language,
  onOpenReel,
  compact = false,
}) => {
  const isNp = language === 'np';

  if (compact) {
    return (
      <div
        onClick={() => onOpenReel(reel)}
        className="mt-2 bg-slate-900 text-white rounded-xl p-2 border border-slate-800 hover:border-pink-500 transition-all cursor-pointer flex items-center justify-between gap-3 group"
      >
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-10 h-10 rounded-lg overflow-hidden relative shrink-0 bg-slate-950">
            <img
              src={reel.thumbnailUrl}
              alt={reel.titleEn}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform"
            />
            <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </div>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[10px] text-pink-400 font-bold uppercase tracking-wider">
              <Film className="w-3 h-3" />
              <span>{isNp ? 'समाचार रिल' : 'Short Reel'}</span>
              <span className="text-slate-500 font-normal">({reel.duration || '0:30'})</span>
            </div>
            <h5 className="text-xs font-bold text-slate-200 truncate group-hover:text-amber-300">
              {isNp ? reel.titleNp : reel.titleEn}
            </h5>
          </div>
        </div>

        <button className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white text-[10px] font-extrabold px-2.5 py-1.5 rounded-lg shadow-sm shrink-0 flex items-center gap-1 cursor-pointer">
          <Play className="w-3 h-3 fill-white" />
          <span>{isNp ? 'हेर्नुहोस्' : 'Watch'}</span>
        </button>
      </div>
    );
  }

  return (
    <div
      onClick={() => onOpenReel(reel)}
      className="bg-slate-900 text-white rounded-2xl overflow-hidden border border-slate-800 hover:border-pink-500 transition-all cursor-pointer group shadow-md hover:shadow-xl relative flex flex-col justify-between"
    >
      {/* Top Media Thumbnail */}
      <div className="h-36 sm:h-40 relative overflow-hidden bg-slate-950">
        <img
          src={reel.thumbnailUrl}
          alt={reel.titleEn}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/40" />

        {/* Top Badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1 bg-red-600/90 text-white text-[9px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider shadow-md">
          <Film className="w-3 h-3" />
          <span>{isNp ? 'रिल' : 'Reel Short'}</span>
        </div>

        {/* Duration badge */}
        <div className="absolute top-2 right-2 bg-slate-950/80 text-amber-300 text-[10px] font-mono px-1.5 py-0.5 rounded-md border border-slate-700">
          {reel.duration || '0:30'}
        </div>

        {/* Center Big Play Button */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-red-600/90 text-white flex items-center justify-center border border-white/30 shadow-xl group-hover:scale-115 transition-all">
          <Play className="w-5 h-5 fill-white ml-0.5" />
        </div>
      </div>

      {/* Info Content */}
      <div className="p-3 space-y-1">
        <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span>By {reel.creatorName}</span>
          <span className="flex items-center gap-1 text-amber-400 font-bold">
            <Eye className="w-3 h-3" />
            {(reel.views / 1000).toFixed(1)}k
          </span>
        </div>

        <h4 className="text-xs font-bold text-white group-hover:text-amber-300 line-clamp-2 leading-tight">
          {isNp ? reel.titleNp : reel.titleEn}
        </h4>
      </div>
    </div>
  );
};
