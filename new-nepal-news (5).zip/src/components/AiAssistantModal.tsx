import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User, RefreshCw } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'bot',
      text:
        language === 'np'
          ? 'नमस्ते! म न्यू नेपाल न्यूज प्रा. लि. को एआई सम्पादकीय सहायक हुँ। नेपाल, गण्डकी प्रदेश वा स्याङ्जासम्बन्धी कुनै पनि समाचार वा जिज्ञासा मलाई सोध्नुहोस्।'
          : 'Hello! I am the AI Editorial Assistant for New Nepal News Pvt. Ltd. Ask me anything regarding Nepal current affairs, Syangja development, or news topics.',
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputQuery.trim() || loading) return;

    const userText = inputQuery.trim();
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: userText,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: userText,
          language,
        }),
      });

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text:
          data.answer ||
          (language === 'np'
            ? 'धन्यवाद! तपाईंको प्रश्न प्रक्रियाधीन छ।'
            : 'Thank you. Verified updates from New Nepal News desk.'),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch {
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text:
          language === 'np'
            ? 'माफ गर्नुहोस्, सम्पादकीय सर्भरमा केही प्राविधिक समस्या आयो। वालिङ स्याङ्जा ब्युरोसँग समाचार समन्वय भइरहेको छ।'
            : 'Connecting to New Nepal News editorial server in Waling Syangja. Please try asking again shortly.',
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-slate-900 text-white rounded-2xl shadow-2xl overflow-hidden border border-indigo-500/30 flex flex-col h-[580px]">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 p-4 border-b border-indigo-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center text-amber-300 shadow-md">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-serif font-bold text-white flex items-center gap-2">
                <span>{getTranslation(language, 'askAiBot')}</span>
                <span className="text-[10px] bg-indigo-700 text-white font-mono px-2 py-0.5 rounded-full">
                  Gemini AI
                </span>
              </h3>
              <p className="text-[11px] text-indigo-300">
                New Nepal News Pvt. Ltd. Editorial Assistant
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-2.5 max-w-[85%] ${
                m.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center ${
                  m.sender === 'user' ? 'bg-red-700 text-white' : 'bg-indigo-700 text-amber-300'
                }`}
              >
                {m.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>

              <div
                className={`p-3 rounded-2xl whitespace-pre-line leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-red-700 text-white rounded-tr-xs'
                    : 'bg-slate-800/90 text-slate-100 border border-slate-700/70 rounded-tl-xs'
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-2 items-center text-indigo-300 text-xs italic pl-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-300" />
              <span>
                {language === 'np'
                  ? 'जेमिनी एआईद्वारा समाचार विश्लेषण हुँदैछ...'
                  : 'Consulting New Nepal News editorial desk...'}
              </span>
            </div>
          )}
        </div>

        {/* Input Footer */}
        <form onSubmit={handleSend} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            placeholder={
              language === 'np'
                ? 'उदाहरण: "स्याङ्जाको वालिङमा कस्ता परियोजनाहरू छन्?"'
                : 'Ask a question e.g. "What is Syangja Agro-Tourism corridor?"'
            }
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
          />
          <button
            type="submit"
            disabled={loading || !inputQuery.trim()}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold p-2.5 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
