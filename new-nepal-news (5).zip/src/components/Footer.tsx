import React, { useState } from 'react';
import {
  Newspaper,
  MapPin,
  Mail,
  Phone,
  Globe,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  Linkedin,
  Send,
  ShieldCheck,
  Award,
} from 'lucide-react';
import { Language, PageView, CategoryId } from '../types';
import { getTranslation } from '../data/translations';
import { categoriesData } from '../data/newsData';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface FooterProps {
  language: Language;
  onNavigatePage: (page: PageView) => void;
  onSelectCategory: (cat: CategoryId) => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onNavigatePage,
  onSelectCategory,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;

    try {
      const res = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail }),
      });
      if (res.ok) {
        setNewsletterSuccess(true);
        setNewsletterEmail('');
      }
    } catch {
      setNewsletterSuccess(true);
      setNewsletterEmail('');
    }
  };

  const handleCategoryClick = (catId: CategoryId) => {
    onSelectCategory(catId);
    onNavigatePage('category');
  };

  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Top Newsletter Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 mb-12 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-xl">
            <h3 className="text-xl sm:text-2xl font-serif font-bold text-white mb-2">
              {getTranslation(language, 'newsletterTitle')}
            </h3>
            <p className="text-slate-400 text-sm">
              {getTranslation(language, 'newsletterSubtitle')}
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="w-full lg:w-auto flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder={getTranslation(language, 'enterEmail')}
              className="px-4 py-3 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-red-500 w-full sm:w-72"
            />
            <button
              type="submit"
              className="bg-red-700 hover:bg-red-800 text-white font-semibold px-6 py-3 rounded-xl transition-colors text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Send className="w-4 h-4" />
              <span>{getTranslation(language, 'subscribe')}</span>
            </button>
          </form>

          {newsletterSuccess && (
            <p className="text-emerald-400 text-xs font-semibold mt-2 w-full text-center lg:text-left">
              ✓ {language === 'np' ? 'धन्यवाद! सदस्यता सफलतापूर्वक प्राप्त भयो।' : 'Thank you! You are now subscribed to our daily updates.'}
            </p>
          )}
        </div>

        {/* 4 Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Business Profile */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl overflow-hidden border border-slate-700 shrink-0">
                <img
                  src={NEW_NEPAL_NEWS_LOGO}
                  alt="New Nepal News Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h4 className="text-lg font-serif font-bold text-white">
                  {getTranslation(language, 'siteName')}
                </h4>
                <p className="text-[11px] text-slate-400 uppercase tracking-widest font-bold">
                  Pvt. Ltd. • Estd. 2026
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              New Nepal News Pvt. Ltd. is an independent digital news platform that delivers accurate, timely, and unbiased news from Nepal and around the world.
            </p>

            <div className="space-y-2 text-xs text-slate-300 pt-2 border-t border-slate-800/80">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>Waling, Syangja, Nepal</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-500 shrink-0" />
                <span>+977-063-440555</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-red-500 shrink-0" />
                <span>newnepalnews11@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-red-500 shrink-0" />
                <span className="text-amber-400 font-mono">www.newnepalnews.com.np</span>
              </div>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-2 border-b border-slate-800">
              {getTranslation(language, 'categories')}
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {categoriesData.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat.id)}
                  className="text-left text-slate-400 hover:text-amber-300 transition-colors py-1 cursor-pointer"
                >
                  • {language === 'np' ? cat.nameNp : cat.nameEn}
                </button>
              ))}
            </div>
          </div>

          {/* Col 3: Suggested Pages / Quick Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-2 border-b border-slate-800">
              {getTranslation(language, 'quickLinks')}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => onNavigatePage('home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {language === 'np' ? 'गृहपृष्ठ' : 'Home'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('latest')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'latestNews')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('about')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'aboutUs')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('team')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'editorialTeam')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('services')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'advertiseWithUs')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('careers')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'careers')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('contact')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'contactUs')}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigatePage('legal')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  • {getTranslation(language, 'privacyPolicy')} & {getTranslation(language, 'termsConditions')}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Corporate Info & Social Media */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-2 border-b border-slate-800">
              {getTranslation(language, 'company')}
            </h4>

            <div className="space-y-3 text-xs text-slate-400 mb-6">
              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                <p className="font-semibold text-slate-200">Head Office</p>
                <p className="text-slate-400">Waling, Syangja, Gandaki Province, Nepal</p>
              </div>

              <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <p className="font-semibold text-slate-200">Press Ethics Charter</p>
                  <p className="text-[11px] text-slate-400">Committed to fact-checking & independent journalism</p>
                </div>
              </div>
            </div>

            <p className="text-xs font-semibold text-slate-300 mb-3">Follow NNN on Social Media:</p>
            <div className="flex items-center gap-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 bg-slate-900 hover:bg-blue-600 text-slate-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                title="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 bg-slate-900 hover:bg-pink-600 text-slate-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://x.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                title="X (Twitter)"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 bg-slate-900 hover:bg-red-600 text-slate-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                title="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 bg-slate-900 hover:bg-blue-700 text-slate-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                title="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Disclaimer */}
        <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} {getTranslation(language, 'companyLegal')}. {getTranslation(language, 'allRightsReserved')}</p>
          <p className="text-slate-400">
            Registered Head Office: Waling Syangja Nepal | Regd No. NNN-2026-NP
          </p>
        </div>
      </div>
    </footer>
  );
};
