import React, { useState, useEffect } from 'react';
import {
  Globe,
  Radio,
  ShieldCheck,
  Zap,
  Pause,
  Play,
  RefreshCw,
  Flame,
  CheckCircle2,
  Lock,
  ExternalLink,
  Filter,
  Eye,
  Clock,
  ThumbsUp,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';
import { NewsArticle, Language } from '../types';
import { initialLiveFeedArticles, incomingAutoNewsBank } from '../data/autoNewsFeedStream';

interface LiveAutoNewsFeedWallProps {
  language: Language;
  onSelectArticle: (article: NewsArticle) => void;
  compactView?: boolean;
}

export const LiveAutoNewsFeedWall: React.FC<LiveAutoNewsFeedWallProps> = ({
  language,
  onSelectArticle,
  compactView = false,
}) => {
  const isNp = language === 'np';

  const [feedArticles, setFeedArticles] = useState<NewsArticle[]>(initialLiveFeedArticles);
  const [isLiveActive, setIsLiveActive] = useState<boolean>(true);
  const [nextCountdown, setNextCountdown] = useState<number>(10);
  const [filterMode, setFilterMode] = useState<'all' | 'world' | 'nepal'>('all');
  const [autoBankIndex, setAutoBankIndex] = useState<number>(0);
  const [recentNotification, setRecentNotification] = useState<string | null>(null);
  const [safetyGuardActive] = useState<boolean>(true);

  // Auto-Update Engine: Countdown & Injection
  useEffect(() => {
    if (!isLiveActive) return;

    const interval = setInterval(() => {
      setNextCountdown((prev) => {
        if (prev <= 1) {
          // Inject next article from bank
          injectNewArticle();
          return 10; // Reset timer to 10s
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isLiveActive, autoBankIndex]);

  // Function to inject new article onto wall with strict anti-adult verification
  const injectNewArticle = () => {
    const nextItem = incomingAutoNewsBank[autoBankIndex % incomingAutoNewsBank.length];

    // Create unique instance with current timestamp
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newArticle: NewsArticle = {
      ...nextItem,
      id: `live-injected-${Date.now()}`,
      publishedAt: isNp ? 'भर्खरै अपडेट' : 'Just In',
      autoStreamTimestamp: timeStr,
      safetyStatus: 'verified_safe',
      views: Math.floor(Math.random() * 500) + 100,
    };

    setFeedArticles((prev) => [newArticle, ...prev]);
    setAutoBankIndex((prev) => prev + 1);

    // Show floating toast
    const notifyText = isNp
      ? `ताजा अपडेट थपियो: ${newArticle.titleNp}`
      : `Live Update Injected: ${newArticle.titleEn}`;
    setRecentNotification(notifyText);

    setTimeout(() => {
      setRecentNotification(null);
    }, 4000);
  };

  // Filtered articles
  const displayedArticles = feedArticles.filter((item) => {
    if (filterMode === 'world') return item.isWorldNews;
    if (filterMode === 'nepal') return item.isNepalViral;
    return true;
  });

  return (
    <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-7 border border-slate-800 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background Subtle Accent Glow */}
      <div className="absolute -top-24 -right-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Floating Toast Notification when new post auto-arrives */}
      {recentNotification && (
        <div className="fixed top-20 right-4 z-50 bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-400/40 flex items-center gap-3 animate-bounce">
          <div className="p-1.5 bg-white/20 rounded-full">
            <Radio className="w-4 h-4 text-white animate-pulse" />
          </div>
          <div className="text-xs font-bold max-w-xs truncate">
            {recentNotification}
          </div>
        </div>
      )}

      {/* Header Section */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black px-3 py-1 rounded-full text-[11px] uppercase tracking-wider shadow-md">
              <Radio className="w-3.5 h-3.5 animate-ping text-slate-950" />
              <span>{isNp ? 'विश्व र नेपाल स्वचालित प्रत्यक्ष अद्यावधिक' : 'WORLD & NEPAL LIVE AUTO-FEED'}</span>
            </span>

            {/* Anti-Adult Content Guard Shield */}
            <span className="flex items-center gap-1 bg-blue-950/80 border border-blue-500/40 text-blue-300 font-bold px-3 py-1 rounded-full text-[11px] shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400 fill-blue-400/20" />
              <span>{isNp ? 'अश्लील सामग्री निषेध (Family Safe AI Guard Active)' : '100% Anti-Adult Content Shield Active'}</span>
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black font-serif text-white tracking-tight flex items-center gap-2 pt-1">
            <span>{isNp ? 'अन्तर्राष्ट्रिय तथा नेपाल भाइरल स्वचालित समाचार पर्खाल' : 'Global & Nepal Viral Auto-Updating News Wall'}</span>
          </h2>

          <p className="text-xs text-slate-400 max-w-2xl font-medium">
            {isNp
              ? 'विश्वभरका एजेन्सीहरू र नेपालका भाइरल समाचारहरू निरन्तर स्वतः अद्यावधिक हुन्छन्। अश्लील, अनावश्यक वा आपत्तिजनक सामग्री पूर्ण रूपमा सेन्सर गरी हटाइएको छ।'
              : 'Auto-streams real-time updates from international wire services & Nepal trending channels. Strictly moderated with zero tolerance for adult/NSFW content.'}
          </p>
        </div>

        {/* Live Controls Bar */}
        <div className="flex items-center gap-2 flex-wrap self-start lg:self-auto shrink-0">
          {/* Live countdown pill */}
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs font-mono text-slate-300 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>
              {isNp ? 'अर्को अपडेट: ' : 'Next Auto: '}
              <strong className="text-emerald-400 font-bold">{nextCountdown}s</strong>
            </span>
          </div>

          {/* Manual Trigger Button */}
          <button
            onClick={injectNewArticle}
            className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-xs px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
            title={isNp ? 'अहिले नयाँ समाचार थप्नुहोस्' : 'Force fetch next update now'}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isNp ? 'ताजा समाचार पाउनुहोस्' : 'Fetch Now'}</span>
          </button>

          {/* Pause / Resume Live Stream */}
          <button
            onClick={() => setIsLiveActive(!isLiveActive)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border ${
              isLiveActive
                ? 'bg-emerald-950/80 border-emerald-700/80 text-emerald-300 hover:bg-emerald-900/80'
                : 'bg-slate-800 border-slate-700 text-amber-300 hover:bg-slate-700'
            }`}
          >
            {isLiveActive ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>{isNp ? 'अटो रोक (Pause)' : 'Pause Auto Feed'}</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>{isNp ? 'अटो चालु (Live)' : 'Resume Auto Stream'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Filter Tabs & Content Policy Status Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-950/70 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
              filterMode === 'all'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {isNp ? 'सबै पर्खाल पोस्टहरू' : 'All Updates'} ({feedArticles.length})
          </button>

          <button
            onClick={() => setFilterMode('world')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1 ${
              filterMode === 'world'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isNp ? 'विश्व समाचार (World)' : 'World News'}</span>
          </button>

          <button
            onClick={() => setFilterMode('nepal')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1 ${
              filterMode === 'nepal'
                ? 'bg-red-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-300" />
            <span>{isNp ? 'नेपाल भाइरल (Nepal Viral)' : 'Nepal Trending'}</span>
          </button>
        </div>

        {/* Safety Guarantee Pill */}
        <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1.5 self-end sm:self-auto bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isNp ? 'अश्लील रहित र शत-प्रतिशत सुरक्षित' : 'Safe for all ages • 0% Adult Content'}</span>
        </div>
      </div>

      {/* News Wall Feed Grid */}
      <div className={`grid grid-cols-1 ${compactView ? 'md:grid-cols-2' : 'md:grid-cols-2 lg:grid-cols-3'} gap-4`}>
        {displayedArticles.map((article, idx) => (
          <div
            key={article.id}
            onClick={() => onSelectArticle(article)}
            className="bg-slate-950/90 rounded-2xl overflow-hidden border border-slate-800 hover:border-emerald-500/80 transition-all duration-300 shadow-lg hover:shadow-2xl hover:shadow-emerald-950/50 cursor-pointer group flex flex-col justify-between relative"
          >
            {/* Newly Injected Badge */}
            {idx === 0 && (
              <div className="absolute top-3 left-3 z-10 bg-gradient-to-r from-red-600 to-pink-600 text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-full shadow-lg animate-pulse flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>{isNp ? 'भर्खरै थपिएको' : 'NEW AUTO UPDATE'}</span>
              </div>
            )}

            {/* Media Image */}
            <div className="h-44 sm:h-48 relative overflow-hidden bg-slate-900">
              <img
                src={article.imageUrl}
                alt={article.titleEn}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

              {/* Source Agency Badge */}
              <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-700 flex items-center gap-1">
                {article.isWorldNews ? <Globe className="w-3 h-3 text-indigo-400" /> : <Flame className="w-3 h-3 text-red-400" />}
                <span>{article.sourceAgency || 'NNN Wire'}</span>
              </div>

              {/* Timestamp */}
              <div className="absolute bottom-2 left-3 text-[10px] font-mono text-emerald-400 bg-slate-950/80 px-2 py-0.5 rounded-md border border-slate-800">
                {article.autoStreamTimestamp ? `Live @ ${article.autoStreamTimestamp}` : article.publishedAt}
              </div>
            </div>

            {/* Content Details */}
            <div className="p-4 space-y-2.5 flex-1 flex flex-col justify-between">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
                  <span className="uppercase font-bold text-blue-400">{article.category}</span>
                  <span className="flex items-center gap-1 text-slate-400 font-mono">
                    <Eye className="w-3 h-3 text-slate-400" />
                    {article.views.toLocaleString('ne-NP')}
                  </span>
                </div>

                <h3 className="font-serif font-bold text-sm sm:text-base text-white group-hover:text-emerald-300 line-clamp-2 leading-snug">
                  {isNp ? article.titleNp : article.titleEn}
                </h3>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {isNp ? article.excerptNp : article.excerptEn}
                </p>
              </div>

              {/* Anti-Adult Verified Shield Footbar */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1 text-emerald-400 font-semibold font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20" />
                  <span>{isNp ? 'AI सुरक्षा प्रमाणीकरण' : 'AI Safety Verified'}</span>
                </div>

                <span className="text-xs text-emerald-400 group-hover:text-emerald-300 font-bold flex items-center gap-1">
                  <span>{isNp ? 'पूरा पढ्नुहोस्' : 'Read Article'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
