import React, { useState, useRef } from 'react';
import {
  Image,
  Video,
  Smile,
  MapPin,
  Send,
  X,
  Globe,
  Sparkles,
  Camera,
  CheckCircle,
  Film,
  Tag,
  Radio,
} from 'lucide-react';
import { Language, NewsArticle } from '../types';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface CreatePostBarProps {
  language: Language;
  onPostCreated: (newArticle: NewsArticle) => void;
}

export const CreatePostBar: React.FC<CreatePostBarProps> = ({ language, onPostCreated }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [authorName, setAuthorName] = useState('लोकप्रिय नागरिक पत्रकार (Citizen Reporter)');
  const [location, setLocation] = useState('Waling, Syangja (वालिङ, स्याङ्जा)');
  const [category, setCategory] = useState<'breaking' | 'politics' | 'business' | 'sports' | 'general'>('breaking');
  
  // Media attachments state
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
  const [mediaFileName, setMediaFileName] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);

  const isNp = language === 'np';

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setMediaUrl(url);
      setMediaType('image');
      setMediaFileName(file.name);
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setMediaUrl(url);
      setMediaType('video');
      setMediaFileName(file.name);
    }
  };

  const handleRemoveMedia = () => {
    setMediaUrl(null);
    setMediaType(null);
    setMediaFileName('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusText.trim() && !mediaUrl) return;

    // Default high-res fallback image if none provided
    const finalImage =
      mediaType === 'image' && mediaUrl
        ? mediaUrl
        : 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&w=1200&q=80';

    const newPost: NewsArticle = {
      id: `user-post-${Date.now()}`,
      titleEn: statusText.slice(0, 80) || 'Citizen News Status Update',
      titleNp: statusText.slice(0, 80) || 'नागरिक समाचार तथा स्टाटस अपडेट',
      excerptEn: statusText.slice(0, 120) || 'Direct field citizen update uploaded via New Nepal News Portal.',
      excerptNp: statusText.slice(0, 120) || 'न्यू नेपाल न्युज पोर्टल मार्फत प्रत्यक्ष अपलोड गरिएको नागरिक अपडेट।',
      contentEn: statusText,
      contentNp: statusText,
      category: category === 'breaking' ? 'politics' : category,
      imageUrl: finalImage,
      videoUrl: mediaType === 'video' ? mediaUrl || undefined : undefined,
      publishedAt: new Date().toISOString().split('T')[0],
      author: authorName || 'Citizen Reporter',
      authorRole: 'सक्रिय नागरिक संवाददाता (Citizen Journalist)',
      location: location,
      readTimeMinutes: 1,
      isBreaking: true,
      isTrending: true,
      views: 12,
      reactions: { like: 1, important: 1, inspiring: 1, sad: 0 },
      tags: ['CitizenNews', 'NewNepalNews', 'LiveUpdate'],
      comments: [
        {
          id: 'c-1',
          author: 'New Nepal News Verification Desk',
          content: isNp ? 'ताजा नागरिक समाचार अपडेट प्राप्त भयो। धन्यवाद!' : 'Verified public update recorded.',
          date: 'Just now',
          likes: 3,
        },
      ],
    };

    onPostCreated(newPost);

    // Reset Form
    setStatusText('');
    setMediaUrl(null);
    setMediaType(null);
    setMediaFileName('');
    setIsOpen(false);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-md p-3.5 sm:p-4 mb-6">
      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        onChange={handleImageChange}
        className="hidden"
      />
      <input
        type="file"
        ref={videoInputRef}
        accept="video/*"
        onChange={handleVideoChange}
        className="hidden"
      />

      {/* Facebook-style Top Input Row */}
      <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
        <img
          src={NEW_NEPAL_NEWS_LOGO}
          alt="User Profile"
          className="w-10 h-10 sm:w-11 sm:h-11 rounded-full object-cover border-2 border-red-600 shadow-xs shrink-0"
        />

        <button
          onClick={() => setIsOpen(true)}
          className="w-full bg-slate-100 hover:bg-slate-200/80 text-slate-500 text-left px-4 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-colors flex items-center justify-between cursor-pointer group"
        >
          <span className="truncate group-hover:text-slate-800">
            {isNp
              ? 'तपाईंको दिमागमा के छ? समाचार वा स्टाटस लेख्नुहोस्...'
              : "What's on your mind? Write news status or update..."}
          </span>
          <Sparkles className="w-4 h-4 text-amber-500 shrink-0 ml-1" />
        </button>
      </div>

      {/* Action Buttons Row */}
      <div className="flex items-center justify-between pt-2.5 text-xs sm:text-sm font-semibold text-slate-600">
        {/* Photo Upload */}
        <button
          onClick={() => {
            setIsOpen(true);
            setTimeout(() => fileInputRef.current?.click(), 100);
          }}
          className="flex items-center justify-center gap-1.5 flex-1 py-1.5 px-2 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-emerald-600"
        >
          <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
          <span className="text-slate-700">{isNp ? 'फोटो / इमेज' : 'Photo'}</span>
        </button>

        {/* Video Upload */}
        <button
          onClick={() => {
            setIsOpen(true);
            setTimeout(() => videoInputRef.current?.click(), 100);
          }}
          className="flex items-center justify-center gap-1.5 flex-1 py-1.5 px-2 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-blue-600"
        >
          <Film className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
          <span className="text-slate-700">{isNp ? 'भिडियो क्लिप' : 'Video'}</span>
        </button>

        {/* Live Status / Location */}
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center justify-center gap-1.5 flex-1 py-1.5 px-2 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer text-red-600"
        >
          <Radio className="w-4 h-4 sm:w-5 sm:h-5 text-red-500 animate-pulse" />
          <span className="text-slate-700">{isNp ? 'लाइभ समाचार' : 'Live News'}</span>
        </button>
      </div>

      {/* Facebook-Style Modal Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                <Send className="w-4 h-4 text-red-600" />
                <span>{isNp ? 'नयाँ समाचार / स्टाटस पोस्ट गर्नुहोस्' : 'Create Post & Upload News'}</span>
              </h3>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-4 flex-1">
              {/* User Profile info */}
              <div className="flex items-center gap-3">
                <img
                  src={NEW_NEPAL_NEWS_LOGO}
                  alt="Reporter"
                  className="w-10 h-10 rounded-full object-cover border border-amber-400"
                />
                <div>
                  <input
                    type="text"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    placeholder="Reporter / Your Name"
                    className="text-xs font-bold text-slate-800 border-b border-slate-200 focus:border-red-600 outline-none pb-0.5 w-full"
                  />
                  <div className="flex items-center gap-2 mt-1">
                    <span className="bg-slate-100 text-slate-600 text-[10px] font-semibold px-2 py-0.5 rounded-md flex items-center gap-1 border border-slate-200">
                      <Globe className="w-2.5 h-2.5 text-blue-600" />
                      <span>{isNp ? 'सार्वजनिक' : 'Public'}</span>
                    </span>
                    <span className="bg-red-50 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 border border-red-200">
                      <CheckCircle className="w-2.5 h-2.5" />
                      <span>{isNp ? 'प्रमाणित पोस्ट' : 'Verified'}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Status Text Area */}
              <div>
                <textarea
                  value={statusText}
                  onChange={(e) => setStatusText(e.target.value)}
                  placeholder={
                    isNp
                      ? 'तपाईंको क्षेत्रको ताजा समाचार, विचार वा स्टाटस यहाँ लेख्नुहोस्...'
                      : "Write your breaking update, status, or opinion here..."
                  }
                  rows={4}
                  className="w-full text-slate-800 text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-600 focus:bg-white outline-none resize-none"
                  required
                />
              </div>

              {/* Location & Category Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                    {isNp ? 'स्थान (Location)' : 'Location'}
                  </label>
                  <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200">
                    <MapPin className="w-3.5 h-3.5 text-red-600 shrink-0" />
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Waling, Syangja"
                      className="bg-transparent text-slate-800 font-medium outline-none w-full"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                    {isNp ? 'समाचार विधा' : 'Category'}
                  </label>
                  <select
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                    className="w-full bg-slate-100 text-slate-800 font-medium px-3 py-2 rounded-xl border border-slate-200 outline-none"
                  >
                    <option value="breaking">ताजा / मुख्य समाचार (Breaking)</option>
                    <option value="politics">राजनीति (Politics)</option>
                    <option value="business">अर्थतन्त्र (Business)</option>
                    <option value="sports">खेलकुद (Sports)</option>
                    <option value="general">आम समाचार (General)</option>
                  </select>
                </div>
              </div>

              {/* Media Preview Box */}
              {mediaUrl && (
                <div className="relative rounded-xl overflow-hidden border border-slate-300 bg-black/90 p-1">
                  <button
                    type="button"
                    onClick={handleRemoveMedia}
                    className="absolute top-2 right-2 bg-slate-900/90 text-white p-1 rounded-full hover:bg-red-600 transition-colors z-20"
                    title="Remove Attachment"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  {mediaType === 'image' ? (
                    <img
                      src={mediaUrl}
                      alt="Upload Preview"
                      className="w-full max-h-48 object-cover rounded-lg"
                    />
                  ) : (
                    <video
                      src={mediaUrl}
                      controls
                      className="w-full max-h-48 object-contain rounded-lg"
                    />
                  )}
                  <div className="text-[10px] text-amber-300 px-2 py-1 font-mono truncate">
                    Attached: {mediaFileName || 'Media File'}
                  </div>
                </div>
              )}

              {/* Add to Post Options Bar */}
              <div className="border border-slate-200 rounded-xl p-2.5 bg-slate-50 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">
                  {isNp ? 'पोस्टमा थप्नुहोस्:' : 'Add to your post:'}
                </span>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 hover:bg-emerald-100 rounded-lg text-emerald-600 transition-colors cursor-pointer"
                    title={isNp ? 'फोटो थप्नुहोस्' : 'Add Photo'}
                  >
                    <Image className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => videoInputRef.current?.click()}
                    className="p-2 hover:bg-blue-100 rounded-lg text-blue-600 transition-colors cursor-pointer"
                    title={isNp ? 'भिडियो थप्नुहोस्' : 'Add Video'}
                  >
                    <Video className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    className="p-2 hover:bg-amber-100 rounded-lg text-amber-600 transition-colors cursor-pointer"
                    title="Tag Location"
                  >
                    <MapPin className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <Send className="w-4 h-4" />
                <span>{isNp ? 'पोस्ट प्रकाशित गर्नुहोस्' : 'Publish News Post'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
