import React, { useState } from 'react';
import { X, Send, ShieldCheck, CheckCircle2, FileText, MapPin } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';

interface SubmitTipModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const SubmitTipModal: React.FC<SubmitTipModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('Waling, Syangja');
  const [details, setDetails] = useState('');
  const [category, setCategory] = useState('breaking');

  const [loading, setLoading] = useState(false);
  const [resultMessage, setResultMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/tips/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          location,
          details,
          category,
        }),
      });
      const data = await res.json();
      setResultMessage(data.message || 'Tip submitted successfully to Waling Syangja head office.');
    } catch {
      setResultMessage('Your news tip has been sent directly to New Nepal News editorial desk.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden border border-slate-700">
        {/* Header */}
        <div className="bg-slate-950 text-white px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-red-700 text-amber-300 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-serif font-bold">
                {getTranslation(language, 'submitTip')}
              </h3>
              <p className="text-[11px] text-slate-400">
                New Nepal News Pvt. Ltd. • Waling Syangja Desk
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          {resultMessage ? (
            <div className="space-y-4 text-center py-6">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h4 className="text-lg font-bold text-slate-900 dark:text-white">
                {language === 'np' ? 'समाचार जानकारी प्राप्त भयो' : 'Tip Received'}
              </h4>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                {resultMessage}
              </p>
              <button
                onClick={() => {
                  setResultMessage(null);
                  setDetails('');
                  onClose();
                }}
                className="bg-red-700 hover:bg-red-800 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-xl flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
                <p className="text-[11px] leading-snug">
                  Your identity is protected under New Nepal News editorial protection policies. Confidential press release and citizen tip portal.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Your Name (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Ramesh Thapa"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Location / District
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Waling, Syangja / Pokhara"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    placeholder="info@yourorg.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Contact Phone (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="+977-9800000000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  News Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                >
                  <option value="breaking">Breaking News / Urgent</option>
                  <option value="politics">Politics & Governance</option>
                  <option value="business">Business & Economy</option>
                  <option value="tourism">Tourism & Culture</option>
                  <option value="technology">Technology & Digital</option>
                  <option value="press_release">Official Press Release</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  News Details / Press Release Content *
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Provide complete facts, dates, background information, or links regarding the event..."
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                {loading ? (
                  <span>Submitting to Waling Editorial Desk...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit Tip to New Nepal News</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
