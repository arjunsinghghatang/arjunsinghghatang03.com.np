import React, { useState } from 'react';
import {
  Newspaper,
  Globe,
  Search,
  Bookmark,
  Sparkles,
  Send,
  Menu,
  X,
  MapPin,
  Calendar,
  CloudSun,
  Flame,
  ChevronDown,
  Building2,
  Users,
  Briefcase,
  PhoneCall,
  Video,
  ShieldCheck,
  TrendingUp,
  BarChart3,
  Film,
} from 'lucide-react';
import { Language, PageView, CategoryId } from '../types';
import { getTranslation } from '../data/translations';
import { categoriesData, weatherData } from '../data/newsData';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';
import { NepalLiveClock } from './NepalLiveClock';

interface HeaderProps {
  language: Language;
  onLanguageToggle: () => void;
  currentPage: PageView;
  onNavigatePage: (page: PageView) => void;
  selectedCategory: CategoryId | null;
  onSelectCategory: (cat: CategoryId | null) => void;
  bookmarkCount: number;
  onOpenBookmarks: () => void;
  onOpenSearch: () => void;
  onOpenSubmitTip: () => void;
  onOpenAiAssistant: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageToggle,
  currentPage,
  onNavigatePage,
  selectedCategory,
  onSelectCategory,
  bookmarkCount,
  onOpenBookmarks,
  onOpenSearch,
  onOpenSubmitTip,
  onOpenAiAssistant, }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesDropdownOpen, setCategoriesDropdownOpen] = useState(false);
  const [selectedWeatherIdx, setSelectedWeatherIdx] = useState(0);

  const currentWeather = weatherData[selectedWeatherIdx];

  // Current formatted date
  const todayDate = new Date();
  const dateOptions: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  };
  const dateFormatted = todayDate.toLocaleDateString(
    language === 'np' ? 'ne-NP' : 'en-US',
    dateOptions
  );

  const handleNavClick = (page: PageView, catId?: CategoryId) => {
    if (catId) {
      onSelectCategory(catId);
      onNavigatePage('category');
    } else {
      if (page !== 'category') onSelectCategory(null);
      onNavigatePage(page);
    }
    setMobileMenuOpen(false);
    setCategoriesDropdownOpen(false);
  };

  return (
    <header className="w-full bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      {/* Top Utility Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Left: Location & Date & Weather */}
          <div className="flex items-center flex-wrap gap-4">
            <div className="flex items-center gap-1.5 text-amber-400 font-medium">
              <MapPin className="w-3.5 h-3.5" />
              <span>{getTranslation(language, 'headOffice')}</span>
            </div>

            <div className="flex items-center gap-1.5 text-slate-400">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{dateFormatted}</span>
            </div>

            {/* Weather selector pill */}
            <div className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 px-2.5 py-0.5 rounded-full text-slate-200 transition-colors cursor-pointer"
                 onClick={() => setSelectedWeatherIdx((prev) => (prev + 1) % weatherData.length)}>
              <CloudSun className="w-3.5 h-3.5 text-amber-300" />
              <span className="font-semibold">
                {language === 'np' ? currentWeather.locationNp : currentWeather.locationEn}:
              </span>
              <span>{currentWeather.temp}°C</span>
              <span className="text-[10px] text-slate-400">({language === 'np' ? currentWeather.conditionNp : currentWeather.conditionEn})</span>
            </div>
          </div>

          {/* Right Utilities: Language toggle, AI assistant, Submit Tip */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAiAssistant}
              className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-2.5 py-0.5 rounded-md transition-all shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>{getTranslation(language, 'askAiBot')}</span>
            </button>

            <button
              onClick={onOpenSubmitTip}
              className="flex items-center gap-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Send className="w-3 h-3 text-red-400" />
              <span>{getTranslation(language, 'submitTip')}</span>
            </button>

            {/* Language Switch Button */}
            <button
              onClick={onLanguageToggle}
              className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 px-2 py-0.5 rounded-md transition-colors cursor-pointer text-xs font-semibold"
              title={getTranslation(language, 'toggleLanguage')}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{getTranslation(language, 'languageName')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Branding Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3 sm:py-4 flex items-center justify-between gap-4">
        {/* Brand Logo & Name */}
        <div
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-xl overflow-hidden shadow-md group-hover:scale-105 transition-transform duration-300 border border-slate-200 shrink-0">
            <img
              src={NEW_NEPAL_NEWS_LOGO}
              alt="New Nepal News Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl md:text-3xl font-black tracking-tight text-slate-900 font-serif">
                {getTranslation(language, 'siteName')}
              </h1>
              <span className="bg-red-100 text-red-800 text-[10px] font-bold px-1.5 py-0.5 rounded-xs uppercase tracking-wider">
                Pvt. Ltd.
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 font-medium">
              {getTranslation(language, 'tagline')}
            </p>
            {/* Live Nepal Time & Date in Nepali */}
            <NepalLiveClock language={language} />
          </div>
        </div>

        {/* Action Controls: Search & Saved Articles & Analytics */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Analytics Dashboard Quick Button */}
          <button
            onClick={() => handleNavClick('analytics')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer shadow-2xs ${
              currentPage === 'analytics'
                ? 'bg-red-700 text-white shadow-md'
                : 'bg-red-50 hover:bg-red-100 text-red-700 border border-red-200'
            }`}
            title={language === 'np' ? 'एनालिटिक्स तथा आम्दानी ड्यासबोर्ड' : 'Analytics & Earnings'}
          >
            <BarChart3 className="w-4 h-4 text-red-600 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">{language === 'np' ? 'ड्यासबोर्ड' : 'Analytics'}</span>
          </button>

          <button
            onClick={onOpenSearch}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            <Search className="w-4 h-4 text-slate-500" />
            <span>{getTranslation(language, 'searchPlaceholder')}</span>
          </button>

          <button
            onClick={onOpenBookmarks}
            className="relative bg-slate-100 hover:bg-slate-200 text-slate-800 p-2 sm:px-3 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
            title={getTranslation(language, 'bookmarks')}
          >
            <Bookmark className="w-4 h-4 text-red-600" />
            <span>{getTranslation(language, 'bookmarks')}</span>
            {bookmarkCount > 0 && (
              <span className="bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ml-0.5">
                {bookmarkCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Navigation Bar (Desktop & Mobile Portal) */}
      <nav className="bg-slate-900 text-white border-t border-slate-800 overflow-x-auto whitespace-nowrap">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-1 text-sm font-medium">
            {/* Home Link */}
            <button
              onClick={() => handleNavClick('home')}
              className={`px-3.5 py-2.5 transition-colors border-b-2 cursor-pointer ${
                currentPage === 'home'
                  ? 'border-red-500 text-red-400 font-bold bg-slate-800/60'
                  : 'border-transparent text-slate-200 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              {language === 'np' ? 'गृहपृष्ठ (Home)' : 'Home'}
            </button>

            {/* Latest News Link */}
            <button
              onClick={() => handleNavClick('latest')}
              className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 cursor-pointer ${
                currentPage === 'latest'
                  ? 'border-red-500 text-red-400 font-bold bg-slate-800/60'
                  : 'border-transparent text-slate-200 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>{getTranslation(language, 'latestNews')}</span>
            </button>

            {/* Reels & Shorts Link */}
            <button
              onClick={() => handleNavClick('reels')}
              className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 cursor-pointer ${
                currentPage === 'reels'
                  ? 'border-pink-500 text-pink-400 font-bold bg-slate-800/80'
                  : 'border-transparent text-pink-300 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <Film className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
              <span>{language === 'np' ? 'रिल्स तथा शर्ट्स' : 'Reels & Shorts'}</span>
              <span className="text-[9px] font-black uppercase bg-gradient-to-r from-red-600 to-pink-600 text-white px-1.5 py-0.2 rounded-full">
                NEW
              </span>
            </button>

            {/* Analytics Dashboard Link */}
            <button
              onClick={() => handleNavClick('analytics')}
              className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 cursor-pointer ${
                currentPage === 'analytics'
                  ? 'border-amber-400 text-amber-300 font-bold bg-slate-800/80'
                  : 'border-transparent text-amber-200 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'np' ? 'एनालिटिक्स ड्यासबोर्ड' : 'Analytics'}</span>
            </button>

            {/* Top Categories direct links */}
            {categoriesData.slice(0, 6).map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleNavClick('category', cat.id)}
                className={`px-3 py-2.5 transition-colors border-b-2 cursor-pointer ${
                  currentPage === 'category' && selectedCategory === cat.id
                    ? 'border-red-500 text-red-400 font-bold bg-slate-800/60'
                    : 'border-transparent text-slate-200 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                {language === 'np' ? cat.nameNp : cat.nameEn}
              </button>
            ))}

            {/* All Categories Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCategoriesDropdownOpen(!categoriesDropdownOpen)}
                className="px-3 py-2.5 text-slate-200 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>{getTranslation(language, 'categories')}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {categoriesDropdownOpen && (
                <div className="absolute top-full left-0 mt-1 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50 text-slate-200">
                  <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 mb-1">
                    {getTranslation(language, 'categories')}
                  </div>
                  {categoriesData.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleNavClick('category', cat.id)}
                      className="w-full text-left px-4 py-2 text-xs hover:bg-slate-800 hover:text-amber-300 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <span>{language === 'np' ? cat.nameNp : cat.nameEn}</span>
                      <span className="text-[10px] text-slate-500">→</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Secondary Pages Links (About, Team, Services, Careers, Contact) */}
          <div className="flex items-center space-x-1 text-xs text-slate-300">
            <button
              onClick={() => handleNavClick('about')}
              className={`px-2.5 py-2 hover:text-white transition-colors cursor-pointer ${
                currentPage === 'about' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {getTranslation(language, 'aboutUs')}
            </button>
            <button
              onClick={() => handleNavClick('team')}
              className={`px-2.5 py-2 hover:text-white transition-colors cursor-pointer ${
                currentPage === 'team' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {getTranslation(language, 'editorialTeam')}
            </button>
            <button
              onClick={() => handleNavClick('services')}
              className={`px-2.5 py-2 hover:text-white transition-colors cursor-pointer ${
                currentPage === 'services' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              {getTranslation(language, 'advertiseWithUs')}
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className={`px-2.5 py-2 bg-red-700 hover:bg-red-800 text-white rounded-md font-semibold transition-colors cursor-pointer ${
                currentPage === 'contact' ? 'bg-red-800' : ''
              }`}
            >
              {getTranslation(language, 'contactUs')}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 text-slate-200 border-t border-slate-800 px-4 py-4 space-y-4">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              onClick={() => handleNavClick('home')}
              className="bg-slate-800 p-2.5 rounded-lg text-left text-white hover:bg-slate-700"
            >
              🏠 Home
            </button>
            <button
              onClick={() => handleNavClick('latest')}
              className="bg-slate-800 p-2.5 rounded-lg text-left text-amber-300 hover:bg-slate-700"
            >
              🔥 {getTranslation(language, 'latestNews')}
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="bg-slate-800 p-2.5 rounded-lg text-left hover:bg-slate-700"
            >
              🏢 {getTranslation(language, 'aboutUs')}
            </button>
            <button
              onClick={() => handleNavClick('team')}
              className="bg-slate-800 p-2.5 rounded-lg text-left hover:bg-slate-700"
            >
              👥 {getTranslation(language, 'editorialTeam')}
            </button>
            <button
              onClick={() => handleNavClick('services')}
              className="bg-slate-800 p-2.5 rounded-lg text-left hover:bg-slate-700"
            >
              📢 {getTranslation(language, 'advertiseWithUs')}
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="bg-red-700 p-2.5 rounded-lg text-left text-white font-bold hover:bg-red-800"
            >
              📞 {getTranslation(language, 'contactUs')}
            </button>
          </div>

          <div className="border-t border-slate-800 pt-3">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              {getTranslation(language, 'categories')}
            </p>
            <div className="grid grid-cols-2 gap-1 text-xs">
              {categoriesData.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleNavClick('category', cat.id)}
                  className="text-left px-2 py-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-md"
                >
                  {language === 'np' ? cat.nameNp : cat.nameEn}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
