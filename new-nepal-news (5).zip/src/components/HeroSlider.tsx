import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Clock, MapPin, Sparkles, ArrowRight } from 'lucide-react';
import { NewsArticle, Language } from '../types';
import { getTranslation } from '../data/translations';
import { PostInteractionBar } from './PostInteractionBar';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface HeroSliderProps {
  articles: NewsArticle[];
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  articles,
  language,
  onArticleClick,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const featured = articles.filter((a) => a.isFeatured || a.isBreaking || a.isTrending);
  const slides = featured.length > 0 ? featured.slice(0, 4) : articles.slice(0, 4);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  if (slides.length === 0) return null;

  const currentSlide = slides[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden bg-slate-900 text-white shadow-2xl group border border-slate-800">
      {/* Background Image with Gradient Overlay */}
      <div className="relative h-[380px] sm:h-[460px] md:h-[500px] w-full overflow-hidden">
        <img
          src={currentSlide.imageUrl}
          alt={currentSlide.titleEn}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 ease-out transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent"></div>

        {/* Blurred Logo Watermark Overlay */}
        <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-white/20 flex items-center gap-2 shadow-2xl z-20">
          <img src={NEW_NEPAL_NEWS_LOGO} alt="New Nepal News Logo" className="w-6 h-6 rounded-full object-cover border border-amber-300 shadow-sm" />
          <div className="text-left">
            <div className="text-xs font-black text-white leading-none">New Nepal News</div>
            <div className="text-[9px] text-amber-300 font-bold uppercase tracking-wider">न्युज नेपाल</div>
          </div>
        </div>
      </div>

      {/* Slide Content Overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 md:p-10 z-10 space-y-3">
        {/* Badges */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="bg-red-700 text-white text-xs font-black uppercase px-3 py-1 rounded-md tracking-wider shadow-md">
            {currentSlide.isBreaking
              ? getTranslation(language, 'breakingNews')
              : currentSlide.category.toUpperCase()}
          </span>

          {currentSlide.location && (
            <span className="bg-slate-800/90 text-amber-300 text-xs font-semibold px-2.5 py-1 rounded-md backdrop-blur-xs flex items-center gap-1 border border-slate-700">
              <MapPin className="w-3 h-3" />
              <span>{currentSlide.location}</span>
            </span>
          )}

          <span className="bg-slate-800/90 text-slate-300 text-xs font-medium px-2.5 py-1 rounded-md backdrop-blur-xs flex items-center gap-1 border border-slate-700">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>{currentSlide.readTimeMinutes} {getTranslation(language, 'readingTime')}</span>
          </span>
        </div>

        {/* Title */}
        <h2
          onClick={() => onArticleClick(currentSlide)}
          className="text-2xl sm:text-3xl md:text-4xl font-serif font-black text-white hover:text-amber-300 transition-colors cursor-pointer leading-tight max-w-4xl drop-shadow-md"
        >
          {language === 'np' ? currentSlide.titleNp : currentSlide.titleEn}
        </h2>

        {/* Excerpt */}
        <p className="text-sm sm:text-base text-slate-300 max-w-3xl line-clamp-2 leading-relaxed">
          {language === 'np' ? currentSlide.excerptNp : currentSlide.excerptEn}
        </p>

        {/* Author & Read Button */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-slate-800/80">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <span className="font-semibold text-white">
              {getTranslation(language, 'authorBy')}: {currentSlide.author}
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">{currentSlide.authorRole}</span>
          </div>

          <button
            onClick={() => onArticleClick(currentSlide)}
            className="bg-red-700 hover:bg-red-800 text-white font-bold px-5 py-2 rounded-xl text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg hover:gap-3"
          >
            <span>{getTranslation(language, 'readMore')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Hero Post Action Buttons (Like, Comment, Share, Follow, Repost) */}
        <div className="bg-slate-900/80 backdrop-blur-md p-2 rounded-xl border border-slate-700/80">
          <PostInteractionBar
            article={currentSlide}
            language={language}
            onCommentClick={() => onArticleClick(currentSlide)}
          />
        </div>
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={handlePrev}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-slate-950/60 hover:bg-red-700 text-white p-2.5 rounded-full backdrop-blur-md border border-slate-700 transition-all opacity-0 group-hover:opacity-100 cursor-pointer shadow-xl"
        aria-label="Previous Slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        onClick={handleNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-slate-950/60 hover:bg-red-700 text-white p-2.5 rounded-full backdrop-blur-md border border-slate-700 transition-all opacity-0 group-hover:opacity-100 cursor-pointer shadow-xl"
        aria-label="Next Slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Slide Indicators Dots */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-1.5 bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-800">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`h-2 rounded-full transition-all cursor-pointer ${
              idx === currentIndex ? 'w-6 bg-red-500' : 'w-2 bg-slate-600 hover:bg-slate-400'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
