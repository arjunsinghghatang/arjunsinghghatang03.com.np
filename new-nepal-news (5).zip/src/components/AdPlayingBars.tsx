import React, { useState, useEffect } from 'react';
import {
  Megaphone,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  PhoneCall,
  Sparkles,
  X,
  Minimize2,
  Maximize2,
  Tag,
  ShieldCheck,
  Building,
  Info
} from 'lucide-react';
import { Language } from '../types';
import { adsData, AdItem } from '../data/adsData';

interface AdBarProps {
  language: Language;
  onOpenAdvertiseModal?: () => void;
}

/* =========================================================
   1. TOP LEADERBOARD AD PLAYING BAR
   Placed at the top of the app below Header
========================================================= */
export const TopAdPlayingBar: React.FC<AdBarProps> = ({ language, onOpenAdvertiseModal }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);

  const activeAd = adsData[currentIndex];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    let progressTimer: NodeJS.Timeout;

    if (isPlaying) {
      setProgress(0);
      const intervalMs = 50;
      const totalMs = 5000;
      let elapsed = 0;

      progressTimer = setInterval(() => {
        elapsed += intervalMs;
        setProgress((elapsed / totalMs) * 100);
      }, intervalMs);

      timer = setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % adsData.length);
      }, totalMs);
    }

    return () => {
      clearTimeout(timer);
      clearInterval(progressTimer);
    };
  }, [currentIndex, isPlaying]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % adsData.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + adsData.length) % adsData.length);
  };

  return (
    <div className="w-full bg-slate-900 text-white border-b border-slate-800 relative overflow-hidden group">
      {/* Animated progress bar top indicator */}
      <div className="w-full h-1 bg-slate-800">
        <div
          className="h-full bg-gradient-to-r from-red-500 via-amber-400 to-emerald-400 transition-all duration-75"
          style={{ width: `${isPlaying ? progress : 100}%` }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-2.5 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        {/* Left Badge + Sponsor info */}
        <div className="flex items-center gap-3 w-full md:w-auto shrink-0 justify-between md:justify-start">
          <div className="flex items-center gap-2">
            <span className="bg-gradient-to-r from-red-600 to-amber-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded-xs tracking-wider shadow-xs flex items-center gap-1">
              <Megaphone className="w-3 h-3 animate-pulse" />
              <span>{language === 'np' ? activeAd.badgeNp : activeAd.badgeEn}</span>
            </span>
            <span className="text-amber-300 font-bold hidden sm:inline text-xs">
              {language === 'np' ? activeAd.sponsorNp : activeAd.sponsorEn}
            </span>
          </div>

          {/* Controls: Play/Pause, Prev, Next */}
          <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-1 rounded-full border border-slate-700">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1 hover:text-amber-400 transition-colors"
              title={isPlaying ? 'Pause Auto-Play' : 'Play Auto-Play'}
            >
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 fill-current" />}
            </button>
            <span className="text-slate-600">|</span>
            <button
              onClick={handlePrev}
              className="p-1 hover:text-amber-400 transition-colors"
              title="Previous Ad"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] font-mono text-slate-400 px-1">
              {currentIndex + 1}/{adsData.length}
            </span>
            <button
              onClick={handleNext}
              className="p-1 hover:text-amber-400 transition-colors"
              title="Next Ad"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Center: Ad Title & Tagline */}
        <div className="flex-1 flex items-center gap-3 overflow-hidden text-center md:text-left">
          <img
            src={activeAd.image}
            alt={activeAd.titleEn}
            className="w-10 h-10 rounded-lg object-cover shrink-0 hidden sm:block border border-slate-700"
          />
          <div className="truncate space-y-0.5">
            <div className="font-serif font-bold text-slate-100 text-sm truncate group-hover:text-amber-300 transition-colors">
              {language === 'np' ? activeAd.titleNp : activeAd.titleEn}
            </div>
            <p className="text-[11px] text-slate-300 truncate font-sans">
              {language === 'np' ? activeAd.taglineNp : activeAd.taglineEn}
            </p>
          </div>
        </div>

        {/* Right CTA Button */}
        <div className="flex items-center gap-2 shrink-0 w-full md:w-auto justify-end">
          {activeAd.offerDiscount && (
            <span className="hidden lg:inline-block bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold px-2 py-1 rounded-md">
              <Tag className="w-3 h-3 inline mr-1" />
              {activeAd.offerDiscount}
            </span>
          )}
          <a
            href={`tel:${activeAd.phone || '+977-063-440555'}`}
            className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs px-3.5 py-1.5 rounded-lg transition-transform active:scale-95 flex items-center gap-1.5 shadow-xs"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>{language === 'np' ? activeAd.ctaNp : activeAd.ctaEn}</span>
          </a>
          {onOpenAdvertiseModal && (
            <button
              onClick={onOpenAdvertiseModal}
              className="text-[10px] text-slate-400 hover:text-slate-200 underline pl-1"
            >
              {language === 'np' ? 'यहाँ विज्ञापन गर्नुहोस्' : 'Advertise Here'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};


/* =========================================================
   2. MID-FEED AD PLAYING BAR
   Large responsive ad bar placed between news sections
========================================================= */
export const MidFeedAdPlayingBar: React.FC<AdBarProps> = ({ language, onOpenAdvertiseModal }) => {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const ad = adsData[activeIdx];

  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % adsData.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPlaying]);

  return (
    <div className="w-full my-8 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl relative overflow-hidden group">
      {/* Background Decorative Pattern */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-48 h-48 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header bar of the playing ad unit */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 text-xs">
        <div className="flex items-center gap-2">
          <span className="bg-red-700 text-white font-black text-[10px] uppercase px-2 py-0.5 rounded-md tracking-wider flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>{language === 'np' ? 'प्रायोजित विज्ञापन बार' : 'Sponsored Ad Playing Bar'}</span>
          </span>
          <span className="text-slate-400 text-xs font-medium hidden sm:inline">
            {language === 'np' ? 'हाम्रा मुख्य व्यापारिक साझेदारहरू' : 'Our Premier Business Partners'}
          </span>
        </div>

        {/* Play/Pause & Indicators */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {adsData.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveIdx(i)}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${
                  i === activeIdx ? 'w-6 bg-amber-400' : 'w-2 bg-slate-700 hover:bg-slate-500'
                }`}
                title={`Ad ${i + 1}`}
              />
            ))}
          </div>

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1 text-slate-400 hover:text-white transition-colors"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Left Column Image with badge */}
        <div className="md:col-span-5 relative rounded-2xl overflow-hidden aspect-video border border-slate-700/80 group-hover:border-amber-400/50 transition-colors shadow-lg">
          <img
            src={ad.image}
            alt={ad.titleEn}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
          <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-slate-700 flex items-center gap-1">
            <Building className="w-3 h-3" />
            <span>{language === 'np' ? ad.sponsorNp : ad.sponsorEn}</span>
          </div>
          {ad.locationEn && (
            <div className="absolute bottom-3 left-3 text-slate-200 text-xs font-medium">
              📍 {language === 'np' ? ad.locationNp : ad.locationEn}
            </div>
          )}
        </div>

        {/* Right Column Details */}
        <div className="md:col-span-7 space-y-3 text-left">
          <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold">
            <Tag className="w-3.5 h-3.5" />
            <span>{language === 'np' ? ad.categoryNp : ad.categoryEn}</span>
            {ad.offerDiscount && (
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full ml-auto">
                {ad.offerDiscount}
              </span>
            )}
          </div>

          <h3 className="text-xl sm:text-2xl font-serif font-black text-white leading-snug group-hover:text-amber-300 transition-colors">
            {language === 'np' ? ad.titleNp : ad.titleEn}
          </h3>

          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            {language === 'np' ? ad.taglineNp : ad.taglineEn}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href={`tel:${ad.phone || '+977-063-440555'}`}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition-transform active:scale-95 flex items-center gap-2 shadow-md"
            >
              <PhoneCall className="w-4 h-4" />
              <span>{language === 'np' ? ad.ctaNp : ad.ctaEn}</span>
            </a>

            {onOpenAdvertiseModal && (
              <button
                onClick={onOpenAdvertiseModal}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs px-3.5 py-2.5 rounded-xl font-medium transition-colors"
              >
                {language === 'np' ? 'विज्ञापन सम्पर्क' : 'Book Sponsor Ad'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};


/* =========================================================
   3. STICKY BOTTOM FLOATING AD PLAYING BAR
   Floating ticker at bottom of screen with minimize toggle
========================================================= */
export const StickyBottomAdPlayingBar: React.FC<AdBarProps> = ({ language, onOpenAdvertiseModal }) => {
  const [minimized, setMinimized] = useState(false);
  const [closed, setClosed] = useState(false);
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const ad = adsData[index];

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % adsData.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [isPlaying]);

  if (closed) return null;

  if (minimized) {
    return (
      <div className="fixed bottom-4 right-4 z-50 animate-bounce">
        <button
          onClick={() => setMinimized(false)}
          className="bg-slate-900 text-amber-300 border border-amber-400/40 p-3 rounded-full shadow-2xl flex items-center gap-2 text-xs font-bold hover:bg-slate-800 transition-colors cursor-pointer group"
          title="Expand Sponsored Ad Bar"
        >
          <Megaphone className="w-4 h-4 text-red-500 group-hover:scale-110 transition-transform" />
          <span className="hidden sm:inline">
            {language === 'np' ? 'प्रायोजित विज्ञापन (Playing)' : 'Sponsor Ads Playing'}
          </span>
          <Maximize2 className="w-3.5 h-3.5 text-slate-400" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md text-white border-t border-slate-800 shadow-2xl transition-all duration-300">
      {/* Top thin play progress bar */}
      <div className="w-full h-0.5 bg-slate-800">
        <div className="h-full bg-amber-400 animate-pulse w-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-2.5 flex items-center justify-between gap-3 text-xs">
        {/* Left Badge + Media thumbnail */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="relative">
            <img
              src={ad.image}
              alt={ad.titleEn}
              className="w-12 h-12 rounded-xl object-cover border border-amber-400/30"
            />
            <span className="absolute -top-1 -right-1 bg-red-600 text-[9px] text-white font-bold px-1 rounded-xs uppercase">
              AD
            </span>
          </div>

          <div className="hidden sm:block">
            <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-bold px-2 py-0.5 rounded-md">
              {language === 'np' ? ad.sponsorNp : ad.sponsorEn}
            </span>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {language === 'np' ? ad.categoryNp : ad.categoryEn}
            </div>
          </div>
        </div>

        {/* Center Ad Info */}
        <div className="flex-1 min-w-0 space-y-0.5">
          <div className="flex items-center gap-2">
            <h4 className="font-serif font-extrabold text-slate-100 text-xs sm:text-sm truncate">
              {language === 'np' ? ad.titleNp : ad.titleEn}
            </h4>
            {ad.offerDiscount && (
              <span className="hidden md:inline-block bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-1.5 py-0.5 rounded-sm shrink-0">
                {ad.offerDiscount}
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-300 truncate hidden md:block">
            {language === 'np' ? ad.taglineNp : ad.taglineEn}
          </p>
        </div>

        {/* Right CTA & Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <a
            href={`tel:${ad.phone || '+977-063-440555'}`}
            className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs px-3 py-1.5 rounded-lg transition-transform active:scale-95 flex items-center gap-1 shadow-sm"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {language === 'np' ? ad.ctaNp : ad.ctaEn}
            </span>
            <span className="sm:hidden">{language === 'np' ? 'कल' : 'Call'}</span>
          </a>

          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-lg text-slate-400">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1 hover:text-white"
              title={isPlaying ? 'Pause Ad Rotation' : 'Play Ad Rotation'}
            >
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            </button>
            <button
              onClick={() => setIndex((prev) => (prev + 1) % adsData.length)}
              className="p-1 hover:text-white"
              title="Next Ad"
            >
              <ChevronRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => setMinimized(true)}
              className="p-1 hover:text-white"
              title="Minimize Ad Bar"
            >
              <Minimize2 className="w-3 h-3" />
            </button>
            <button
              onClick={() => setClosed(true)}
              className="p-1 hover:text-red-400"
              title="Close Ad Bar"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


/* =========================================================
   4. INLINE ARTICLE AD PLAYING BAR
   Embedded inside SingleArticleModal.tsx
========================================================= */
export const ArticleInlineAdPlayingBar: React.FC<AdBarProps> = ({ language, onOpenAdvertiseModal }) => {
  const [adIndex, setAdIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const ad = adsData[adIndex];

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setAdIndex((prev) => (prev + 1) % adsData.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <div className="my-6 p-4 sm:p-5 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-2xl border border-slate-700 shadow-md relative overflow-hidden">
      <div className="flex items-center justify-between text-[11px] text-amber-300 font-bold mb-3 border-b border-slate-800 pb-2">
        <span className="flex items-center gap-1.5 uppercase tracking-wider">
          <Megaphone className="w-3.5 h-3.5 text-red-500 animate-pulse" />
          <span>{language === 'np' ? ad.badgeNp : ad.badgeEn}</span>
        </span>
        <div className="flex items-center gap-2 text-slate-400 font-normal">
          <span>{adIndex + 1}/{adsData.length}</span>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="hover:text-white p-0.5"
          >
            {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
          </button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-4">
        <img
          src={ad.image}
          alt={ad.titleEn}
          className="w-full sm:w-28 h-24 rounded-xl object-cover border border-slate-700 shrink-0"
        />
        <div className="space-y-1.5 flex-1 min-w-0">
          <span className="text-[10px] text-slate-400 font-medium">
            {language === 'np' ? ad.sponsorNp : ad.sponsorEn}
          </span>
          <h4 className="font-serif font-bold text-sm sm:text-base text-white leading-snug">
            {language === 'np' ? ad.titleNp : ad.titleEn}
          </h4>
          <p className="text-xs text-slate-300 line-clamp-2">
            {language === 'np' ? ad.taglineNp : ad.taglineEn}
          </p>

          <div className="pt-2 flex items-center justify-between gap-2">
            <a
              href={`tel:${ad.phone || '+977-063-440555'}`}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>{language === 'np' ? ad.ctaNp : ad.ctaEn}</span>
            </a>
            {onOpenAdvertiseModal && (
              <button
                onClick={onOpenAdvertiseModal}
                className="text-[10px] text-slate-400 hover:text-slate-200 underline"
              >
                {language === 'np' ? 'विज्ञापन राख्न' : 'Sponsor Story'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
