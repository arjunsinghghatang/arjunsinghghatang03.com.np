import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Heart,
  MessageCircle,
  Share2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  ExternalLink,
  Music,
  Bookmark,
  Send,
  Eye,
  Film,
} from 'lucide-react';
import { ReelStoryItem, Language, NewsArticle } from '../types';

interface ReelsShortsModalProps {
  reels: ReelStoryItem[];
  initialIndex: number;
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onOpenArticle?: (articleId: string) => void;
  articles?: NewsArticle[];
}

export const ReelsShortsModal: React.FC<ReelsShortsModalProps> = ({
  reels,
  initialIndex,
  isOpen,
  onClose,
  language,
  onOpenArticle,
  articles = [],
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentsList, setCommentsList] = useState<string[]>([
    'जय नेपाल! धेरै उत्कृष्ट रिपोर्टिङ।',
    'Great news coverage from Pokhara!',
    'स्याङ्जा ब्युरोबाट निरन्तर अपडेटको लागि धन्यवाद।',
  ]);
  const [newComment, setNewComment] = useState('');

  const currentReel = reels[currentIndex] || reels[0];
  const isNp = language === 'np';

  // Sync like count when reel changes
  useEffect(() => {
    if (currentReel) {
      setLikeCount(currentReel.likes);
      setIsLiked(false);
      setIsSaved(false);
      setShowComments(false);
    }
  }, [currentIndex, currentReel]);

  if (!isOpen || !currentReel) return null;

  const taggedArticle = articles.find((a) => a.id === currentReel.articleId);

  const handleNext = () => {
    if (currentIndex < reels.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    } else {
      setCurrentIndex(reels.length - 1);
    }
  };

  const handleToggleLike = () => {
    if (isLiked) {
      setIsLiked(false);
      setLikeCount((prev) => prev - 1);
    } else {
      setIsLiked(true);
      setLikeCount((prev) => prev + 1);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setCommentsList([newComment.trim(), ...commentsList]);
    setNewComment('');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: isNp ? currentReel.titleNp : currentReel.titleEn,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert(isNp ? 'रिलको लिङ्क कपि भयो!' : 'Reel link copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-2 sm:p-4">
      {/* Modal Container */}
      <div className="relative w-full max-w-sm sm:max-w-md h-[92vh] max-h-[820px] bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col justify-between select-none">
        {/* Top Header Bar */}
        <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-slate-950/90 via-slate-950/40 to-transparent flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-red-600 rounded-md text-white text-xs font-black">
              NNN
            </span>
            <span className="font-serif font-extrabold text-sm tracking-tight">
              {isNp ? 'रिल्स तथा शर्ट्स' : 'Reels & Shorts'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md cursor-pointer transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            <button
              onClick={onClose}
              className="p-2 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video / Visual Container */}
        <div
          onClick={() => setIsPlaying(!isPlaying)}
          className="relative flex-1 w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden cursor-pointer"
        >
          {/* Simulated Short Video / Mixkit MP4 */}
          {currentReel.videoUrl ? (
            <video
              src={currentReel.videoUrl}
              autoPlay
              loop
              muted={isMuted}
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={currentReel.thumbnailUrl}
              alt={currentReel.titleEn}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          )}

          {/* Pause Overlay Icon */}
          {!isPlaying && (
            <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-10">
              <div className="w-16 h-16 rounded-full bg-slate-900/80 text-white flex items-center justify-center border border-white/20 shadow-2xl">
                <Play className="w-8 h-8 fill-white ml-1" />
              </div>
            </div>
          )}

          {/* Top Progress Bar */}
          <div className="absolute top-2 left-4 right-4 z-20 h-1 bg-slate-800/80 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-red-500 to-pink-500 animate-pulse w-3/4 rounded-full" />
          </div>

          {/* Vertical Controls Overlay (Right Side) */}
          <div className="absolute right-3 bottom-24 z-20 flex flex-col items-center gap-5 text-white">
            {/* Creator Avatar */}
            <div className="relative">
              <div className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-pink-500 to-red-600 shadow-xl">
                <img
                  src={currentReel.creatorAvatar}
                  alt={currentReel.creatorName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFollowing(!isFollowing);
                }}
                className={`absolute -bottom-1.5 left-1/2 -translate-x-1/2 text-[10px] px-1.5 py-0.2 rounded-full font-bold shadow-md cursor-pointer ${
                  isFollowing ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
                }`}
              >
                {isFollowing ? '✓' : '+'}
              </button>
            </div>

            {/* Like Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleToggleLike();
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
            >
              <div className={`p-3 rounded-full backdrop-blur-md transition-all ${
                isLiked ? 'bg-red-600 text-white scale-110' : 'bg-slate-950/60 text-white group-hover:bg-slate-800'
              }`}>
                <Heart className={`w-6 h-6 ${isLiked ? 'fill-white' : ''}`} />
              </div>
              <span className="text-[11px] font-bold font-mono">
                {likeCount.toLocaleString('ne-NP')}
              </span>
            </button>

            {/* Comments Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowComments(!showComments);
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
            >
              <div className="p-3 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md transition-all">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold font-mono">
                {currentReel.commentsCount + commentsList.length - 3}
              </span>
            </button>

            {/* Share Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleShare();
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
            >
              <div className="p-3 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md transition-all">
                <Share2 className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-bold font-mono">
                {currentReel.sharesCount}
              </span>
            </button>

            {/* Bookmark */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsSaved(!isSaved);
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
            >
              <div className={`p-3 rounded-full backdrop-blur-md transition-all ${
                isSaved ? 'bg-amber-500 text-slate-950' : 'bg-slate-950/60 text-white group-hover:bg-slate-800'
              }`}>
                <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-slate-950' : ''}`} />
              </div>
            </button>
          </div>

          {/* Up & Down Navigation Arrows */}
          <div className="absolute left-3 bottom-28 z-20 flex flex-col gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handlePrev();
              }}
              className="p-2 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md cursor-pointer"
              title="Previous Reel"
            >
              <ChevronUp className="w-5 h-5" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleNext();
              }}
              className="p-2 bg-slate-950/60 hover:bg-slate-800 text-white rounded-full backdrop-blur-md cursor-pointer"
              title="Next Reel"
            >
              <ChevronDown className="w-5 h-5" />
            </button>
          </div>

          {/* Bottom Info Overlay */}
          <div className="absolute bottom-0 left-0 right-16 z-20 p-4 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent text-white space-y-2">
            {/* Creator Name & Category Tag */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm text-amber-300 flex items-center gap-1">
                @{currentReel.creatorName}
                {currentReel.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />}
              </span>
              <span className="text-[10px] uppercase font-extrabold bg-red-600 px-2 py-0.5 rounded-full text-white">
                {currentReel.category}
              </span>
            </div>

            {/* Reel Caption */}
            <p className="text-xs sm:text-sm font-semibold line-clamp-2 leading-snug">
              {isNp ? currentReel.titleNp : currentReel.titleEn}
            </p>

            {/* Audio Track Tag */}
            <div className="flex items-center gap-1.5 text-[11px] text-slate-300 font-mono">
              <Music className="w-3.5 h-3.5 text-pink-400 animate-spin" />
              <span>Original Sound - NNN News Desk ({currentReel.publishedAt})</span>
            </div>

            {/* Direct Link to News Article */}
            {currentReel.articleId && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onClose();
                  onOpenArticle?.(currentReel.articleId!);
                }}
                className="mt-2 w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white text-xs font-bold py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-lg border border-red-500/40 cursor-pointer active:scale-98"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>
                  {isNp ? 'पूरा समाचार पढ्नुहोस् (Read Full Story)' : 'Read Full News Article'}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Slide-Up Comments Drawer */}
        {showComments && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-x-0 bottom-0 z-30 h-1/2 bg-slate-900 border-t border-slate-800 p-4 rounded-t-3xl flex flex-col justify-between space-y-3 animate-in slide-in-from-bottom duration-300"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200">
                {isNp ? 'प्रतिक्रियाहरू (Comments)' : 'Comments'}
              </h4>
              <button
                onClick={() => setShowComments(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 text-xs">
              {commentsList.map((c, idx) => (
                <div key={idx} className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60 text-slate-200">
                  <div className="font-bold text-amber-300 text-[10px]">@Reader_{idx + 1}</div>
                  <p className="mt-0.5">{c}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder={isNp ? 'प्रतिक्रिया लेख्नुहोस्...' : 'Add a comment...'}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
              />
              <button
                type="submit"
                className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
