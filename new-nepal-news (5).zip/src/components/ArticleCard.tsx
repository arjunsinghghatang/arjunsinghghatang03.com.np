import React from 'react';
import { Bookmark, Clock, Eye, MapPin, MessageSquare } from 'lucide-react';
import { NewsArticle, Language } from '../types';
import { getTranslation } from '../data/translations';
import { NewsAutoVideoPlayBar } from './NewsAutoVideoPlayBar';
import { PostInteractionBar } from './PostInteractionBar';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface ArticleCardProps {
  article: NewsArticle;
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
  onBookmarkToggle?: (articleId: string) => void;
  isBookmarked?: boolean;
  variant?: 'grid' | 'compact' | 'trending' | 'horizontal';
  rankIndex?: number;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  article,
  language,
  onArticleClick,
  onBookmarkToggle,
  isBookmarked = false,
  variant = 'grid',
  rankIndex,
}) => {
  const title = language === 'np' ? article.titleNp : article.titleEn;
  const excerpt = language === 'np' ? article.excerptNp : article.excerptEn;

  if (variant === 'compact') {
    return (
      <div className="space-y-1">
        <div
          onClick={() => onArticleClick(article)}
          className="flex gap-3 items-start group cursor-pointer p-2 rounded-xl hover:bg-slate-100 transition-colors"
        >
          <div className="w-20 h-20 shrink-0 rounded-lg overflow-hidden bg-slate-200 relative">
            <img
              src={article.imageUrl}
              alt={title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            {/* Blurred Logo Overlay Badge */}
            <div className="absolute bottom-1 right-1 bg-slate-950/70 backdrop-blur-md px-1.5 py-0.5 rounded-md border border-white/20 flex items-center gap-1 shadow-md">
              <img src={NEW_NEPAL_NEWS_LOGO} alt="NNN Logo" className="w-3.5 h-3.5 rounded-full object-cover border border-amber-300" />
              <span className="text-[8px] font-black tracking-tighter text-white uppercase font-sans">NNN</span>
            </div>
          </div>

          <div className="flex-1 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 bg-red-50 px-1.5 py-0.5 rounded-xs">
              {article.category}
            </span>
            <h4 className="text-xs sm:text-sm font-semibold text-slate-900 group-hover:text-red-700 line-clamp-2 leading-snug">
              {title}
            </h4>
            <div className="flex items-center gap-2 text-[11px] text-slate-500 pt-0.5">
              <span>{article.readTimeMinutes} {getTranslation(language, 'readingTime')}</span>
              <span>•</span>
              <span className="flex items-center gap-0.5">
                <Eye className="w-3 h-3" />
                {article.views}
              </span>
            </div>
          </div>
        </div>

        {/* Compact Auto Video Play Bar under news */}
        <NewsAutoVideoPlayBar
          article={article}
          language={language}
          onOpenVideoModal={onArticleClick}
          compact
        />

        {/* Post Action Interaction Bar (Like, Comment, Share, Follow, Repost) */}
        <PostInteractionBar
          article={article}
          language={language}
          onCommentClick={() => onArticleClick(article)}
          compact
        />
      </div>
    );
  }

  if (variant === 'trending') {
    return (
      <div
        onClick={() => onArticleClick(article)}
        className="flex items-start gap-4 p-3 rounded-xl bg-white border border-slate-200/80 hover:border-red-500/50 hover:shadow-md transition-all cursor-pointer group"
      >
        {rankIndex !== undefined && (
          <span className="text-3xl font-black font-serif text-red-700 shrink-0 w-8 text-center pt-1">
            0{rankIndex + 1}
          </span>
        )}

        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-red-700 uppercase bg-red-50 px-1.5 py-0.5 rounded-xs">
              {article.category}
            </span>
            {article.location && (
              <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                <MapPin className="w-2.5 h-2.5 text-slate-400" />
                {article.location}
              </span>
            )}
          </div>

          <h3 className="text-sm font-bold text-slate-900 group-hover:text-red-700 line-clamp-2 leading-snug font-serif">
            {title}
          </h3>

          <div className="flex items-center gap-3 text-xs text-slate-500 pt-1">
            <span className="font-medium text-slate-700">{article.author}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3 text-slate-400" />
              {article.views}
            </span>
          </div>

          {/* Interaction Bar for trending posts */}
          <PostInteractionBar
            article={article}
            language={language}
            onCommentClick={() => onArticleClick(article)}
            compact
          />
        </div>

        <div className="w-20 h-20 shrink-0 rounded-lg overflow-hidden bg-slate-100">
          <img
            src={article.imageUrl}
            alt={title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          />
        </div>
      </div>
    );
  }

  if (variant === 'horizontal') {
    return (
      <div className="flex flex-col md:flex-row bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-lg transition-all group">
        <div
          onClick={() => onArticleClick(article)}
          className="w-full md:w-2/5 h-48 md:h-auto overflow-hidden relative cursor-pointer"
        >
          <img
            src={article.imageUrl}
            alt={title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {/* Blurred Logo Watermark Badge */}
          <div className="absolute bottom-3 right-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-xl border border-white/20 flex items-center gap-1.5 shadow-lg">
            <img src={NEW_NEPAL_NEWS_LOGO} alt="New Nepal News" className="w-4 h-4 rounded-full object-cover border border-amber-300" />
            <span className="text-[10px] font-black text-white tracking-wide">New Nepal News</span>
          </div>
          {article.isBreaking && (
            <span className="absolute top-3 left-3 bg-red-700 text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-md shadow-md">
              {getTranslation(language, 'breakingNews')}
            </span>
          )}
        </div>

        <div className="w-full md:w-3/5 p-5 flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="bg-red-50 text-red-700 text-xs font-bold uppercase px-2.5 py-0.5 rounded-md">
                {article.category}
              </span>
              {article.location && (
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {article.location}
                </span>
              )}
            </div>

            <h3
              onClick={() => onArticleClick(article)}
              className="text-lg font-serif font-bold text-slate-900 group-hover:text-red-700 transition-colors cursor-pointer line-clamp-2 leading-snug"
            >
              {title}
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed">
              {excerpt}
            </p>
          </div>

          <div className="space-y-3">
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800">{article.author}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {article.readTimeMinutes} {getTranslation(language, 'readingTime')}
                </span>
              </div>

              {onBookmarkToggle && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onBookmarkToggle(article.id);
                  }}
                  className={`p-1.5 rounded-md hover:bg-slate-100 transition-colors cursor-pointer ${
                    isBookmarked ? 'text-red-600' : 'text-slate-400 hover:text-slate-700'
                  }`}
                  title={isBookmarked ? 'Saved' : 'Save Article'}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-red-600' : ''}`} />
                </button>
              )}
            </div>

            {/* Like, Comment, Repost, Follow, Share toolbar */}
            <PostInteractionBar
              article={article}
              language={language}
              onCommentClick={() => onArticleClick(article)}
            />
          </div>
        </div>
      </div>
    );
  }

  // Standard Grid Card
  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden hover:border-slate-300 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
      <div>
        {/* Card Image Header */}
        <div
          onClick={() => onArticleClick(article)}
          className="relative h-48 w-full overflow-hidden bg-slate-100 cursor-pointer"
        >
          <img
            src={article.imageUrl}
            alt={title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />

          {/* Blurred Logo Watermark Overlay */}
          <div className="absolute bottom-2.5 right-2.5 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-xl border border-white/20 flex items-center gap-1.5 shadow-lg pointer-events-none">
            <img src={NEW_NEPAL_NEWS_LOGO} alt="New Nepal News" className="w-4 h-4 rounded-full object-cover border border-amber-300" />
            <span className="text-[10px] font-black text-white tracking-wide">New Nepal News</span>
          </div>

          <div className="absolute top-3 left-3 flex items-center gap-2">
            <span className="bg-slate-900/90 text-white text-[10px] font-bold uppercase px-2.5 py-1 rounded-md backdrop-blur-xs shadow-md">
              {article.category}
            </span>
            {article.isBreaking && (
              <span className="bg-red-700 text-white text-[10px] font-black uppercase px-2 py-1 rounded-md shadow-md animate-pulse">
                {getTranslation(language, 'breakingNews')}
              </span>
            )}
          </div>

          {onBookmarkToggle && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onBookmarkToggle(article.id);
              }}
              className="absolute top-3 right-3 bg-white/90 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-xs transition-transform active:scale-95 cursor-pointer"
              title={isBookmarked ? 'Remove Bookmark' : 'Save Bookmark'}
            >
              <Bookmark
                className={`w-4 h-4 ${
                  isBookmarked ? 'fill-red-600 text-red-600' : 'text-slate-700'
                }`}
              />
            </button>
          )}
        </div>

        {/* Card Content Body */}
        <div className="p-5 space-y-2">
          {article.location && (
            <p className="text-[11px] font-semibold text-red-700 flex items-center gap-1 uppercase tracking-wider">
              <MapPin className="w-3 h-3" />
              {article.location}
            </p>
          )}

          <h3
            onClick={() => onArticleClick(article)}
            className="text-base sm:text-lg font-serif font-bold text-slate-900 group-hover:text-red-700 transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {title}
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed">
            {excerpt}
          </p>

          {/* Auto Video Play Bar Under Article */}
          <NewsAutoVideoPlayBar
            article={article}
            language={language}
            onOpenVideoModal={onArticleClick}
          />
        </div>
      </div>

      {/* Card Footer & Interaction Toolbar */}
      <div className="px-4 pb-3 pt-2 bg-slate-50/50 space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">{article.author}</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-400">
              <Clock className="w-3.5 h-3.5" />
              {article.readTimeMinutes}m
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <Eye className="w-3.5 h-3.5" />
              {article.views}
            </span>
          </div>
        </div>

        {/* Like, Comment, Repost, Follow, Share Action Toolbar */}
        <PostInteractionBar
          article={article}
          language={language}
          onCommentClick={() => onArticleClick(article)}
        />
      </div>
    </div>
  );
};
