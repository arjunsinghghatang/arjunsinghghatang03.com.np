import React from 'react';
import { X, Bookmark, Trash2, ArrowRight } from 'lucide-react';
import { NewsArticle, Language } from '../types';
import { getTranslation } from '../data/translations';

interface BookmarksDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  bookmarkedArticles: NewsArticle[];
  onSelectArticle: (article: NewsArticle) => void;
  onRemoveBookmark: (articleId: string) => void;
  onClearAllBookmarks: () => void;
}

export const BookmarksDrawer: React.FC<BookmarksDrawerProps> = ({
  isOpen,
  onClose,
  language,
  bookmarkedArticles,
  onSelectArticle,
  onRemoveBookmark,
  onClearAllBookmarks,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 text-slate-900 dark:text-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-700 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="bg-slate-950 text-white p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-red-500 fill-red-500" />
            <h3 className="font-serif font-bold text-base">
              {getTranslation(language, 'bookmarks')} ({bookmarkedArticles.length})
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {bookmarkedArticles.length > 0 && (
              <button
                onClick={onClearAllBookmarks}
                className="text-[11px] text-red-400 hover:text-red-300 font-bold px-2 py-1 rounded bg-slate-800"
              >
                Clear All
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {bookmarkedArticles.length === 0 ? (
            <div className="text-center py-20 text-slate-400 space-y-3">
              <Bookmark className="w-12 h-12 text-slate-600 mx-auto opacity-40" />
              <p className="text-xs">{getTranslation(language, 'noBookmarks')}</p>
            </div>
          ) : (
            bookmarkedArticles.map((art) => (
              <div
                key={art.id}
                className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center gap-3 group"
              >
                <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0 bg-slate-200">
                  <img
                    src={art.imageUrl}
                    alt={art.titleEn}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div
                  onClick={() => {
                    onSelectArticle(art);
                    onClose();
                  }}
                  className="flex-1 cursor-pointer space-y-1"
                >
                  <span className="text-[10px] font-bold text-red-600 uppercase">
                    {art.category}
                  </span>
                  <h4 className="text-xs font-bold font-serif line-clamp-2 group-hover:text-red-600 transition-colors">
                    {language === 'np' ? art.titleNp : art.titleEn}
                  </h4>
                </div>

                <button
                  onClick={() => onRemoveBookmark(art.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                  title="Remove Bookmark"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
