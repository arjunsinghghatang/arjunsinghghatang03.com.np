import React, { useState } from 'react';
import {
  Heart,
  MessageSquare,
  Share2,
  UserPlus,
  UserCheck,
  Repeat2,
  Copy,
  Check,
  Facebook,
  Twitter,
  Send,
} from 'lucide-react';
import { Language, NewsArticle } from '../types';

interface PostInteractionBarProps {
  article: NewsArticle;
  language: Language;
  onCommentClick?: () => void;
  onShareClick?: () => void;
  compact?: boolean;
}

export const PostInteractionBar: React.FC<PostInteractionBarProps> = ({
  article,
  language,
  onCommentClick,
  onShareClick,
  compact = false,
}) => {
  // Local state for interaction counters & toggle status
  const [likes, setLikes] = useState<number>(article.reactions?.like || 18);
  const [isLiked, setIsLiked] = useState<boolean>(false);

  const [reposts, setReposts] = useState<number>(Math.floor((article.views || 100) / 12) + 3);
  const [isReposted, setIsReposted] = useState<boolean>(false);

  const [isFollowing, setIsFollowing] = useState<boolean>(false);
  const [showShareMenu, setShowShareMenu] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const isNp = language === 'np';

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLiked) {
      setLikes((prev) => Math.max(0, prev - 1));
      setIsLiked(false);
    } else {
      setLikes((prev) => prev + 1);
      setIsLiked(true);
    }
  };

  const handleRepost = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isReposted) {
      setReposts((prev) => Math.max(0, prev - 1));
      setIsReposted(false);
    } else {
      setReposts((prev) => prev + 1);
      setIsReposted(true);
    }
  };

  const handleFollow = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFollowing((prev) => !prev);
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onShareClick) {
      onShareClick();
    } else {
      setShowShareMenu((prev) => !prev);
    }
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => {
      setCopiedLink(false);
      setShowShareMenu(false);
    }, 1800);
  };

  const commentCount = article.comments?.length || 4;

  if (compact) {
    return (
      <div className="relative pt-2 border-t border-slate-100 flex items-center justify-between text-slate-500 text-[11px]">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Like */}
          <button
            onClick={handleLike}
            className={`flex items-center gap-1 hover:text-red-600 transition-colors cursor-pointer ${
              isLiked ? 'text-red-600 font-bold' : ''
            }`}
            title={isNp ? 'मन पर्यो (Like)' : 'Like'}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-red-600 text-red-600' : ''}`} />
            <span>{likes}</span>
          </button>

          {/* Comment */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onCommentClick?.();
            }}
            className="flex items-center gap-1 hover:text-blue-600 transition-colors cursor-pointer"
            title={isNp ? 'टिप्पणी (Comment)' : 'Comment'}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{commentCount}</span>
          </button>

          {/* Repost */}
          <button
            onClick={handleRepost}
            className={`flex items-center gap-1 hover:text-emerald-600 transition-colors cursor-pointer ${
              isReposted ? 'text-emerald-600 font-bold' : ''
            }`}
            title={isNp ? 'पुनः सेयर गर्नुहोस् (Repost)' : 'Repost'}
          >
            <Repeat2 className="w-3.5 h-3.5" />
            <span>{reposts}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Follow */}
          <button
            onClick={handleFollow}
            className={`flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
              isFollowing
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200'
            }`}
          >
            {isFollowing ? (
              <>
                <UserCheck className="w-2.5 h-2.5 text-emerald-600" />
                <span>{isNp ? 'अनुसरण गरियो' : 'Following'}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-2.5 h-2.5" />
                <span>{isNp ? '+ पछ्याउनुहोस्' : '+ Follow'}</span>
              </>
            )}
          </button>

          {/* Share */}
          <button
            onClick={handleShareClick}
            className="p-1 hover:text-slate-900 transition-colors cursor-pointer"
            title={isNp ? 'सेयर गर्नुहोस् (Share)' : 'Share'}
          >
            <Share2 className="w-3.5 h-3.5 text-slate-500" />
          </button>
        </div>

        {/* Share Popup Menu */}
        {showShareMenu && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute right-0 bottom-8 z-30 bg-slate-900 text-white p-2 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2 text-xs animate-in fade-in zoom-in-95 duration-150"
          >
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 hover:bg-slate-800 rounded-lg text-blue-400"
              title="Share on Facebook"
            >
              <Facebook className="w-4 h-4" />
            </a>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(
                isNp ? article.titleNp : article.titleEn
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 hover:bg-slate-800 rounded-lg text-sky-400"
              title="Share on Twitter"
            >
              <Twitter className="w-4 h-4" />
            </a>
            <a
              href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                (isNp ? article.titleNp : article.titleEn) + ' ' + window.location.href
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 hover:bg-slate-800 rounded-lg text-emerald-400"
              title="Share on WhatsApp"
            >
              <Send className="w-4 h-4" />
            </a>
            <button
              onClick={handleCopyLink}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-amber-300 flex items-center gap-1 cursor-pointer"
              title="Copy Article Link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative pt-3 border-t border-slate-100 flex items-center justify-between gap-1 text-slate-600 text-xs sm:text-sm font-medium">
      {/* 1. Like Button */}
      <button
        onClick={handleLike}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-red-50 hover:text-red-600 transition-all cursor-pointer ${
          isLiked ? 'text-red-600 bg-red-50 font-bold' : ''
        }`}
      >
        <Heart className={`w-4 h-4 transition-transform active:scale-125 ${isLiked ? 'fill-red-600 text-red-600' : ''}`} />
        <span>{isNp ? 'लाइक' : 'Like'}</span>
        <span className="text-[11px] px-1.5 py-0.2 bg-slate-100 rounded-full text-slate-600 font-mono font-bold">
          {likes}
        </span>
      </button>

      {/* 2. Comment Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onCommentClick?.();
        }}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors cursor-pointer"
      >
        <MessageSquare className="w-4 h-4 text-blue-500" />
        <span>{isNp ? 'कमेन्ट' : 'Comment'}</span>
        <span className="text-[11px] px-1.5 py-0.2 bg-slate-100 rounded-full text-slate-600 font-mono font-bold">
          {commentCount}
        </span>
      </button>

      {/* 3. Repost Button */}
      <button
        onClick={handleRepost}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-emerald-50 hover:text-emerald-600 transition-all cursor-pointer ${
          isReposted ? 'text-emerald-600 bg-emerald-50 font-bold' : ''
        }`}
      >
        <Repeat2 className={`w-4 h-4 ${isReposted ? 'text-emerald-600 rotate-180 transition-transform' : ''}`} />
        <span>{isNp ? 'रिपोष्ट' : 'Repost'}</span>
        <span className="text-[11px] px-1.5 py-0.2 bg-slate-100 rounded-full text-slate-600 font-mono font-bold">
          {reposts}
        </span>
      </button>

      {/* 4. Follow Button */}
      <button
        onClick={handleFollow}
        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
          isFollowing
            ? 'bg-emerald-600 text-white font-bold shadow-xs'
            : 'bg-slate-100 hover:bg-red-700 hover:text-white text-slate-700 font-medium'
        }`}
      >
        {isFollowing ? (
          <>
            <UserCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isNp ? 'अनुसरण गरियो' : 'Following'}</span>
            <span className="sm:hidden">✓</span>
          </>
        ) : (
          <>
            <UserPlus className="w-3.5 h-3.5 text-red-600 group-hover:text-white" />
            <span>{isNp ? 'फलो' : 'Follow'}</span>
          </>
        )}
      </button>

      {/* 5. Share Button */}
      <button
        onClick={handleShareClick}
        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-amber-50 hover:text-amber-700 transition-colors cursor-pointer text-slate-600"
        title={isNp ? 'सेयर गर्नुहोस्' : 'Share Post'}
      >
        <Share2 className="w-4 h-4 text-amber-600" />
        <span className="hidden sm:inline">{isNp ? 'सेयर' : 'Share'}</span>
      </button>

      {/* Share Popover Menu */}
      {showShareMenu && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute right-0 bottom-12 z-30 bg-slate-950 text-white p-2.5 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-3 text-xs animate-in fade-in slide-in-from-bottom-2 duration-150"
        >
          <span className="text-[10px] text-slate-400 font-bold uppercase pl-1">{isNp ? 'सेयर:' : 'Share:'}</span>
          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 hover:bg-slate-800 rounded-xl text-blue-400 transition-colors flex items-center gap-1"
            title="Facebook"
          >
            <Facebook className="w-4 h-4" />
          </a>
          <a
            href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(
              isNp ? article.titleNp : article.titleEn
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 hover:bg-slate-800 rounded-xl text-sky-400 transition-colors flex items-center gap-1"
            title="Twitter"
          >
            <Twitter className="w-4 h-4" />
          </a>
          <a
            href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
              (isNp ? article.titleNp : article.titleEn) + ' ' + window.location.href
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 hover:bg-slate-800 rounded-xl text-emerald-400 transition-colors flex items-center gap-1"
            title="WhatsApp"
          >
            <Send className="w-4 h-4" />
          </a>
          <button
            onClick={handleCopyLink}
            className="p-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-xl transition-colors flex items-center gap-1 font-bold cursor-pointer"
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-[10px]">{isNp ? 'कपी भयो' : 'Copied!'}</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span className="text-[10px]">{isNp ? 'लिङ्क कपी' : 'Copy Link'}</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
