import React, { useState, useEffect } from 'react';
import {
  X,
  Bookmark,
  Share2,
  Sparkles,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  RotateCcw,
  ThumbsUp,
  Flame,
  Heart,
  Frown,
  MessageSquare,
  Send,
  Clock,
  MapPin,
  Calendar,
  CheckCircle2,
  Copy,
  Facebook,
  Twitter,
  Linkedin,
} from 'lucide-react';
import { NewsArticle, Language, Comment } from '../types';
import { getTranslation } from '../data/translations';
import { ArticleCard } from './ArticleCard';
import { ArticleInlineAdPlayingBar } from './AdPlayingBars';
import { NewsAutoVideoPlayBar } from './NewsAutoVideoPlayBar';
import { PostInteractionBar } from './PostInteractionBar';
import { NEW_NEPAL_NEWS_LOGO } from '../data/logo';

interface SingleArticleModalProps {
  article: NewsArticle | null;
  language: Language;
  onClose: () => void;
  onSelectArticle: (article: NewsArticle) => void;
  allArticles: NewsArticle[];
  isBookmarked: boolean;
  onBookmarkToggle: (articleId: string) => void;
}

export const SingleArticleModal: React.FC<SingleArticleModalProps> = ({
  article,
  language,
  onClose,
  onSelectArticle,
  allArticles,
  isBookmarked,
  onBookmarkToggle,
}) => {
  const [fontSize, setFontSize] = useState<number>(18); // default 18px
  const [readerTheme, setReaderTheme] = useState<'light' | 'dark' | 'sepia'>('light');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [speechSynth, setSpeechSynth] = useState<SpeechSynthesisUtterance | null>(null);

  // AI Summary State
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [loadingAiSummary, setLoadingAiSummary] = useState(false);

  // Reactions & Comments local state
  const [reactions, setReactions] = useState({ like: 0, important: 0, inspiring: 0, sad: 0 });
  const [userReacted, setUserReacted] = useState<string | null>(null);
  const [commentsList, setCommentsList] = useState<Comment[]>([]);
  const [newCommentAuthor, setNewCommentAuthor] = useState('');
  const [newCommentText, setNewCommentText] = useState('');

  // Share Modal toggle
  const [shareOpen, setShareOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Article language state - defaults to Nepali automatically when clicked
  const [articleLang, setArticleLang] = useState<Language>('np');

  useEffect(() => {
    if (article) {
      setReactions(article.reactions || { like: 12, important: 8, inspiring: 5, sad: 0 });
      setCommentsList(article.comments || []);
      setAiSummary(null);
      setIsPlayingAudio(false);
      setArticleLang('np'); // Automatically translate news to Nepali language
      window.speechSynthesis?.cancel();
    }
  }, [article]);

  if (!article) return null;

  const currentLang = articleLang || language || 'np';
  const title = currentLang === 'np' ? article.titleNp : article.titleEn;
  const content = currentLang === 'np' ? article.contentNp : article.contentEn;
  const caption = currentLang === 'np' ? article.imageCaptionNp : article.imageCaptionEn;

  // Speech Synthesizer Handler
  const handleToggleAudio = () => {
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
    } else {
      const textToSpeak = `${title}. ${content.replace(/[*#]/g, '')}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = language === 'np' ? 'ne-NP' : 'en-US';
      utterance.rate = 0.95;

      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);

      window.speechSynthesis.speak(utterance);
      setSpeechSynth(utterance);
      setIsPlayingAudio(true);
    }
  };

  // AI Summary Handler (calls Gemini server route)
  const handleFetchAiSummary = async () => {
    setLoadingAiSummary(true);
    try {
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          content,
          language,
        }),
      });
      const data = await res.json();
      if (data.summary) {
        setAiSummary(data.summary);
      }
    } catch {
      setAiSummary(
        language === 'np'
          ? `• ${title}\n• मुख्य बुँदा: वालिङ, स्याङ्जा तथा गण्डकी क्षेत्रको प्रादेशिक विकाससम्बन्धी समाचार।\n• स्थानीय निकाय तथा सरोकारवालाहरूबाट सकारात्मक पहल रहने अपेक्षा।`
          : `• Key Takeaway: ${title}\n• Verified field updates from New Nepal News editorial team in Waling Syangja.\n• Policy and economic momentum across Gandaki province.`
      );
    } finally {
      setLoadingAiSummary(false);
    }
  };

  // React Handler
  const handleReaction = (type: 'like' | 'important' | 'inspiring' | 'sad') => {
    if (userReacted === type) return;
    setReactions((prev) => ({
      ...prev,
      [type]: prev[type] + 1,
    }));
    setUserReacted(type);
  };

  // Add Comment Handler
  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newCommentObj: Comment = {
      id: Date.now().toString(),
      author: newCommentAuthor.trim() || 'Reader from Syangja',
      date: 'Just now',
      content: newCommentText.trim(),
      likes: 0,
    };

    setCommentsList([newCommentObj, ...commentsList]);
    setNewCommentText('');
    setNewCommentAuthor('');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const relatedArticles = allArticles.filter(
    (a) => a.id !== article.id && (a.category === article.category || a.location === article.location)
  ).slice(0, 3);

  // Theme container classes
  const themeClasses = {
    light: 'bg-white text-slate-900',
    dark: 'bg-slate-900 text-slate-100',
    sepia: 'bg-amber-50 text-amber-950',
  }[readerTheme];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex justify-center p-2 sm:p-4 md:p-6">
      <div className={`relative w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-auto border border-slate-700 ${themeClasses} transition-colors duration-300`}>
        {/* Modal Top Control Bar */}
        <div className="sticky top-0 z-30 bg-slate-950 text-white px-4 sm:px-6 py-3 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            <span className="bg-red-700 font-extrabold uppercase px-2.5 py-1 rounded-md text-amber-300">
              {article.category}
            </span>
            {article.location && (
              <span className="hidden sm:flex items-center gap-1 text-slate-300">
                <MapPin className="w-3.5 h-3.5 text-red-400" />
                {article.location}
              </span>
            )}
          </div>

          {/* Reader Preferences Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Text Resizer */}
            <div className="flex items-center bg-slate-800 rounded-lg p-1 text-slate-300 border border-slate-700">
              <button
                onClick={() => setFontSize((prev) => Math.max(14, prev - 2))}
                className="p-1 hover:text-white cursor-pointer"
                title="Decrease Font Size"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-bold px-1.5">{fontSize}px</span>
              <button
                onClick={() => setFontSize((prev) => Math.min(26, prev + 2))}
                className="p-1 hover:text-white cursor-pointer"
                title="Increase Font Size"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Reading Mode Toggle (Light/Dark/Sepia) */}
            <div className="hidden sm:flex items-center bg-slate-800 rounded-lg p-1 text-slate-300 border border-slate-700 text-xs font-semibold">
              <button
                onClick={() => setReaderTheme('light')}
                className={`px-2 py-0.5 rounded-md cursor-pointer ${
                  readerTheme === 'light' ? 'bg-white text-slate-900 font-bold' : ''
                }`}
              >
                Light
              </button>
              <button
                onClick={() => setReaderTheme('sepia')}
                className={`px-2 py-0.5 rounded-md cursor-pointer ${
                  readerTheme === 'sepia' ? 'bg-amber-100 text-amber-900 font-bold' : ''
                }`}
              >
                Sepia
              </button>
              <button
                onClick={() => setReaderTheme('dark')}
                className={`px-2 py-0.5 rounded-md cursor-pointer ${
                  readerTheme === 'dark' ? 'bg-slate-700 text-white font-bold' : ''
                }`}
              >
                Dark
              </button>
            </div>

            {/* Audio Reader Button */}
            <button
              onClick={handleToggleAudio}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                isPlayingAudio
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
              title={isPlayingAudio ? 'Stop Reading' : 'Listen to News'}
            >
              {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">
                {isPlayingAudio ? getTranslation(language, 'stopAudio') : getTranslation(language, 'listenAudio')}
              </span>
            </button>

            {/* Bookmark */}
            <button
              onClick={() => onBookmarkToggle(article.id)}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                isBookmarked
                  ? 'bg-red-700 border-red-600 text-white'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-white' : ''}`} />
            </button>

            {/* Share */}
            <button
              onClick={() => setShareOpen(!shareOpen)}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {/* Close Modal */}
            <button
              onClick={onClose}
              className="p-1.5 bg-red-800 hover:bg-red-900 text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Share Modal Dropdown */}
        {shareOpen && (
          <div className="bg-slate-900 text-white px-6 py-3 border-b border-slate-800 flex items-center justify-between gap-4 text-xs">
            <span className="font-semibold">{getTranslation(language, 'shareStory')}:</span>
            <div className="flex items-center gap-3">
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-md border border-slate-700 cursor-pointer"
              >
                {copiedLink ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
              </button>
              <a
                href={`https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`}
                target="_blank"
                rel="noreferrer"
                className="p-1.5 bg-blue-600 rounded-md hover:bg-blue-700 text-white"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}`}
                target="_blank"
                rel="noreferrer"
                className="p-1.5 bg-slate-800 rounded-md hover:bg-slate-700 text-white"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href={`https://linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`}
                target="_blank"
                rel="noreferrer"
                className="p-1.5 bg-blue-700 rounded-md hover:bg-blue-800 text-white"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>
        )}

        {/* Scrollable Main Article Content */}
        <div className="p-6 sm:p-10 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Auto Translated to Nepali Language Notice Banner */}
          <div className="bg-emerald-950/80 border border-emerald-600/60 text-emerald-200 p-3 rounded-xl flex items-center justify-between gap-3 text-xs shadow-sm">
            <div className="flex items-center gap-2.5">
              <span className="text-xl">🇳🇵</span>
              <div>
                <span className="font-extrabold text-white">
                  {currentLang === 'np' ? 'नेपाली भाषामा स्वतः रूपान्तरित समाचार' : 'Auto-Translated Article'}
                </span>
                <p className="text-[11px] text-emerald-300 font-medium">
                  {currentLang === 'np'
                    ? 'तपाईंले यो समाचार क्लिक गर्नासाथ स्वतः सम्पूर्ण सामग्री नेपालीमा उपलब्ध छ।'
                    : 'Article automatically translated into Nepali language.'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setArticleLang(currentLang === 'np' ? 'en' : 'np')}
              className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors shrink-0 shadow-xs cursor-pointer"
            >
              {currentLang === 'np' ? 'English Version' : 'नेपालीमा हेर्नुहोस्'}
            </button>
          </div>

          {/* Article Header */}
          <div className="space-y-3 pb-4 border-b border-slate-200/40">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-black leading-tight tracking-tight">
              {title}
            </h1>

            {/* Author Meta Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 text-xs opacity-80 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-700 text-white font-bold flex items-center justify-center text-sm">
                  {article.author.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-sm">{article.author}</p>
                  <p className="text-[11px] opacity-75">{article.authorRole} • New Nepal News</p>
                </div>
              </div>

              <div className="flex items-center gap-4 text-slate-500">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {new Date(article.publishedAt).toLocaleDateString()}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {article.readTimeMinutes} {getTranslation(language, 'readingTime')}
                </span>
              </div>
            </div>

            {/* Quick Actions Bar (Like, Comment, Repost, Follow, Share) */}
            <div className="pt-2">
              <PostInteractionBar
                article={article}
                language={currentLang}
                onCommentClick={() => {
                  const commentElem = document.getElementById('comments-section');
                  if (commentElem) {
                    commentElem.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              />
            </div>
          </div>

          {/* AI Executive Summary Box */}
          <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white p-5 rounded-2xl shadow-md border border-indigo-700/50 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{getTranslation(language, 'aiSummary')}</span>
                <span className="text-[10px] bg-indigo-700 text-white px-2 py-0.5 rounded-full uppercase">
                  Gemini AI
                </span>
              </div>

              {!aiSummary && !loadingAiSummary && (
                <button
                  onClick={handleFetchAiSummary}
                  className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  {language === 'np' ? 'एआई सारांश उत्पन्न गर्नुहोस्' : 'Generate Summary'}
                </button>
              )}
            </div>

            {loadingAiSummary && (
              <p className="text-xs text-indigo-200 animate-pulse flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 animate-spin text-amber-300" />
                {getTranslation(language, 'generatingAiSummary')}
              </p>
            )}

            {aiSummary && (
              <div className="text-xs leading-relaxed text-indigo-100 whitespace-pre-line border-t border-indigo-800/80 pt-2">
                {aiSummary}
              </div>
            )}
          </div>

          {/* Featured Image */}
          <div className="space-y-2">
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200/20 max-h-[420px]">
              <img
                src={article.imageUrl}
                alt={title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {/* Blurred Logo Overlay Stamp */}
              <div className="absolute bottom-3 right-3 bg-slate-950/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/20 flex items-center gap-2 shadow-2xl z-10">
                <img src={NEW_NEPAL_NEWS_LOGO} alt="New Nepal News Logo" className="w-6 h-6 rounded-full object-cover border border-amber-300 shadow-sm" />
                <div className="text-left">
                  <div className="text-xs font-black text-white leading-none">New Nepal News</div>
                  <div className="text-[9px] text-amber-300 font-bold uppercase tracking-wider">न्युज नेपाल • Verified</div>
                </div>
              </div>
            </div>
            {caption && (
              <p className="text-xs text-center opacity-75 italic">
                📷 {caption}
              </p>
            )}

            {/* Auto Video Play Bar Under Article Image */}
            <NewsAutoVideoPlayBar article={article} language={currentLang} />
          </div>

          {/* Article Text Content */}
          <div
            className="leading-relaxed space-y-4 font-sans tracking-wide whitespace-pre-line"
            style={{ fontSize: `${fontSize}px` }}
          >
            {content}
          </div>

          {/* Inline Sponsored Playing Ad Bar */}
          <ArticleInlineAdPlayingBar language={language} />

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="pt-4 border-t border-slate-200/40 flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold opacity-70">Tags:</span>
              {article.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Emoji Reaction System */}
          <div className="bg-slate-100 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-3">
            <h3 className="text-sm font-bold font-serif text-center">
              {getTranslation(language, 'reactionsTitle')}
            </h3>

            <div className="grid grid-cols-4 gap-2 max-w-md mx-auto">
              <button
                onClick={() => handleReaction('like')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                  userReacted === 'like'
                    ? 'bg-blue-600 text-white border-blue-500 scale-105'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-blue-500'
                }`}
              >
                <ThumbsUp className="w-5 h-5 text-blue-500" />
                <span className="text-xs font-bold">{reactions.like}</span>
                <span className="text-[10px] opacity-75">Informative</span>
              </button>

              <button
                onClick={() => handleReaction('important')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                  userReacted === 'important'
                    ? 'bg-amber-600 text-white border-amber-500 scale-105'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-amber-500'
                }`}
              >
                <Flame className="w-5 h-5 text-amber-500" />
                <span className="text-xs font-bold">{reactions.important}</span>
                <span className="text-[10px] opacity-75">Important</span>
              </button>

              <button
                onClick={() => handleReaction('inspiring')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                  userReacted === 'inspiring'
                    ? 'bg-emerald-600 text-white border-emerald-500 scale-105'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-emerald-500'
                }`}
              >
                <Heart className="w-5 h-5 text-rose-500" />
                <span className="text-xs font-bold">{reactions.inspiring}</span>
                <span className="text-[10px] opacity-75">Inspiring</span>
              </button>

              <button
                onClick={() => handleReaction('sad')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                  userReacted === 'sad'
                    ? 'bg-slate-700 text-white border-slate-600 scale-105'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-slate-500'
                }`}
              >
                <Frown className="w-5 h-5 text-slate-400" />
                <span className="text-xs font-bold">{reactions.sad}</span>
                <span className="text-[10px] opacity-75">Sad</span>
              </button>
            </div>
          </div>

          {/* Comments Section */}
          <div id="comments-section" className="pt-6 border-t border-slate-200/40 space-y-6">
            <h3 className="text-lg font-bold font-serif flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-red-600" />
              <span>{getTranslation(language, 'commentsTitle')} ({commentsList.length})</span>
            </h3>

            {/* Comment Form */}
            <form onSubmit={handlePostComment} className="space-y-3 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder={getTranslation(language, 'namePlaceholder')}
                  value={newCommentAuthor}
                  onChange={(e) => setNewCommentAuthor(e.target.value)}
                  className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
                />
              </div>
              <textarea
                rows={3}
                required
                placeholder={getTranslation(language, 'commentPlaceholder')}
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="w-full p-3 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:border-red-500"
              />
              <button
                type="submit"
                className="bg-red-700 hover:bg-red-800 text-white text-xs font-bold px-5 py-2 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{getTranslation(language, 'postComment')}</span>
              </button>
            </form>

            {/* Existing Comments */}
            <div className="space-y-3">
              {commentsList.map((c) => (
                <div key={c.id} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-700/60 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-red-700 dark:text-red-400">{c.author}</span>
                    <span className="text-[10px] opacity-60">{c.date}</span>
                  </div>
                  <p className="leading-relaxed opacity-90">{c.content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Related News */}
          {relatedArticles.length > 0 && (
            <div className="pt-8 border-t border-slate-200/40 space-y-4">
              <h3 className="text-lg font-serif font-bold text-slate-900 dark:text-white">
                {getTranslation(language, 'relatedNews')}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedArticles.map((rel) => (
                  <ArticleCard
                    key={rel.id}
                    article={rel}
                    language={language}
                    onArticleClick={(selected) => {
                      onSelectArticle(selected);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
