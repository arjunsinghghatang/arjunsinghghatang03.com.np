import React, { useState } from 'react';
import { Play, Plus, Film, Flame, Sparkles, Eye, CheckCircle2 } from 'lucide-react';
import { ReelStoryItem, Language } from '../types';

interface ReelsShortsBarProps {
  reels: ReelStoryItem[];
  language: Language;
  onSelectReel: (reel: ReelStoryItem, index: number) => void;
  onAddStoryClick?: () => void;
}

export const ReelsShortsBar: React.FC<ReelsShortsBarProps> = ({
  reels,
  language,
  onSelectReel,
  onAddStoryClick,
}) => {
  const isNp = language === 'np';

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-xl space-y-3">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-gradient-to-tr from-pink-500 via-red-500 to-amber-500 rounded-lg text-white shadow-md animate-pulse">
            <Film className="w-4 h-4" />
          </div>
          <h3 className="font-serif font-black text-sm sm:text-base tracking-tight text-white flex items-center gap-1.5">
            <span>{isNp ? 'समाचार रिल्स तथा शर्ट्स' : 'News Reels & Shorts'}</span>
            <span className="text-[10px] font-sans font-extrabold uppercase px-2 py-0.5 rounded-full bg-gradient-to-r from-red-600 to-pink-600 text-white border border-pink-400/30">
              Live Stories
            </span>
          </h3>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
          <span className="hidden sm:inline-block text-[11px] text-amber-300">
            {isNp ? 'फेसबुक/टिकटक शैली' : 'FB / TikTok Style'}
          </span>
          <button
            onClick={() => onSelectReel(reels[0], 0)}
            className="text-xs text-red-400 hover:text-red-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
          >
            <span>{isNp ? 'सबै हेर्नुहोस्' : 'Watch All'}</span>
            <Flame className="w-3.5 h-3.5 text-amber-400" />
          </button>
        </div>
      </div>

      {/* Horizontal Reels Stories Slider */}
      <div className="flex items-center gap-3 overflow-x-auto pb-2 pt-1 scrollbar-thin scrollbar-thumb-slate-700">
        {/* Create / Add Story Button */}
        <div
          onClick={onAddStoryClick}
          className="w-24 sm:w-28 h-40 sm:h-44 shrink-0 rounded-2xl bg-slate-800 border-2 border-dashed border-slate-700 hover:border-red-500 transition-all flex flex-col items-center justify-between p-2.5 cursor-pointer group hover:bg-slate-800/80 relative overflow-hidden"
        >
          <div className="w-full h-24 rounded-xl overflow-hidden bg-slate-900 relative">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
              alt="User"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
            <div className="absolute inset-0 bg-slate-950/40" />
          </div>

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-r from-red-600 to-pink-600 text-white flex items-center justify-center border-2 border-slate-900 shadow-lg group-hover:scale-110 transition-transform">
            <Plus className="w-5 h-5" />
          </div>

          <span className="text-[11px] font-bold text-center text-slate-200 group-hover:text-amber-300 leading-tight pt-3">
            {isNp ? 'स्टोरी थप्नुहोस्' : 'Add Story'}
          </span>
        </div>

        {/* List of Reels */}
        {reels.map((item, idx) => (
          <div
            key={item.id}
            onClick={() => onSelectReel(item, idx)}
            className="w-24 sm:w-28 h-40 sm:h-44 shrink-0 rounded-2xl overflow-hidden relative border-2 border-pink-500/80 hover:border-amber-400 transition-all cursor-pointer group shadow-lg hover:shadow-pink-500/20"
          >
            {/* Thumbnail */}
            <img
              src={item.thumbnailUrl}
              alt={item.titleEn}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

            {/* Top Creator Avatar Ring */}
            <div className="absolute top-2 left-2 flex items-center gap-1">
              <div className="w-7 h-7 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-pink-500 to-red-600 shadow-md">
                <img
                  src={item.creatorAvatar}
                  alt={item.creatorName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              {item.isVerified && (
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-400/20 bg-slate-950 rounded-full" />
              )}
            </div>

            {/* Play Badge */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-950/70 backdrop-blur-md border border-white/30 text-white flex items-center justify-center group-hover:scale-110 group-hover:bg-red-600 transition-all shadow-xl">
              <Play className="w-4 h-4 fill-white ml-0.5" />
            </div>

            {/* Bottom Views & Title */}
            <div className="absolute bottom-2 left-2 right-2 space-y-0.5">
              <div className="flex items-center gap-1 text-[9px] font-bold text-amber-300 font-mono">
                <Eye className="w-2.5 h-2.5" />
                <span>{(item.views / 1000).toFixed(1)}k</span>
              </div>
              <p className="text-[10px] font-bold text-white line-clamp-2 leading-tight group-hover:text-amber-200">
                {isNp ? item.titleNp : item.titleEn}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
