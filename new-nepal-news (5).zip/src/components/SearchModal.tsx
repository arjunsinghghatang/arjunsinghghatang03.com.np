import React, { useState } from 'react';
import { X, Search, MapPin, Calendar, ArrowRight } from 'lucide-react';
import { NewsArticle, Language, CategoryId } from '../types';
import { getTranslation } from '../data/translations';
import { categoriesData } from '../data/newsData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  articles: NewsArticle[];
  onSelectArticle: (article: NewsArticle) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  language,
  articles,
  onSelectArticle,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCat, setSelectedCat] = useState<CategoryId | 'all'>('all');

  if (!isOpen) return null;

  const filteredArticles = articles.filter((art) => {
    const titleMatch =
      art.titleEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      art.titleNp.toLowerCase().includes(searchTerm.toLowerCase());
    const contentMatch =
      art.excerptEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      art.excerptNp.toLowerCase().includes(searchTerm.toLowerCase()) ||
      art.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()));
    const categoryMatch = selectedCat === 'all' || art.category === selectedCat;

    return (titleMatch || contentMatch) && categoryMatch;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex justify-center p-4 pt-12">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden border border-slate-700 flex flex-col max-h-[85vh]">
        {/* Search Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-red-500" />
            <input
              type="text"
              autoFocus
              placeholder={getTranslation(language, 'searchPlaceholder')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-transparent text-white text-base focus:outline-none placeholder-slate-500 font-medium"
            />
            <button
              onClick={onClose}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            <button
              onClick={() => setSelectedCat('all')}
              className={`px-3 py-1 rounded-full whitespace-nowrap font-medium transition-colors cursor-pointer ${
                selectedCat === 'all'
                  ? 'bg-red-700 text-white font-bold'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              All Categories
            </button>
            {categoriesData.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCat(cat.id)}
                className={`px-3 py-1 rounded-full whitespace-nowrap font-medium transition-colors cursor-pointer ${
                  selectedCat === cat.id
                    ? 'bg-red-700 text-white font-bold'
                    : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                {language === 'np' ? cat.nameNp : cat.nameEn}
              </button>
            ))}
          </div>
        </div>

        {/* Search Results List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium px-2">
            <span>
              {getTranslation(language, 'searchResultFor')} "{searchTerm || 'All'}"
            </span>
            <span>{filteredArticles.length} stories found</span>
          </div>

          {filteredArticles.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              <Search className="w-10 h-10 text-slate-600 mx-auto mb-2 opacity-50" />
              <p>{getTranslation(language, 'noResultsFound')}</p>
            </div>
          ) : (
            filteredArticles.map((art) => (
              <div
                key={art.id}
                onClick={() => {
                  onSelectArticle(art);
                  onClose();
                }}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors cursor-pointer border border-transparent hover:border-slate-300 dark:hover:border-slate-700 group"
              >
                <div className="w-20 h-20 shrink-0 rounded-lg overflow-hidden bg-slate-200">
                  <img
                    src={art.imageUrl}
                    alt={art.titleEn}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-red-600">
                    <span>{art.category}</span>
                    {art.location && (
                      <span className="text-slate-400 flex items-center gap-0.5">
                        <MapPin className="w-2.5 h-2.5" />
                        {art.location}
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold font-serif line-clamp-1 group-hover:text-red-600 transition-colors">
                    {language === 'np' ? art.titleNp : art.titleEn}
                  </h4>

                  <p className="text-xs text-slate-500 line-clamp-1">
                    {language === 'np' ? art.excerptNp : art.excerptEn}
                  </p>
                </div>

                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition-colors shrink-0" />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
