import React from 'react';
import { CategoryId, NewsArticle, Language } from '../types';
import { getTranslation } from '../data/translations';
import { categoriesData } from '../data/newsData';
import { ArticleCard } from '../components/ArticleCard';
import { MidFeedAdPlayingBar } from '../components/AdPlayingBars';

interface CategoryViewProps {
  categoryId: CategoryId | null;
  articles: NewsArticle[];
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
  onBookmarkToggle: (articleId: string) => void;
  bookmarkedIds: string[];
}

export const CategoryView: React.FC<CategoryViewProps> = ({
  categoryId,
  articles,
  language,
  onArticleClick,
  onBookmarkToggle,
  bookmarkedIds,
}) => {
  const currentCat = categoriesData.find((c) => c.id === categoryId) || categoriesData[0];
  const catArticles = articles.filter((a) => categoryId === null || a.category === currentCat.id);

  return (
    <div className="space-y-8 pb-12">
      {/* Category Header */}
      <div className={`p-8 sm:p-10 rounded-2xl shadow-xl space-y-3 ${currentCat.color}`}>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full backdrop-blur-xs">
            Category
          </span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif font-black">
          {language === 'np' ? currentCat.nameNp : currentCat.nameEn}
        </h1>
        <p className="text-sm sm:text-base opacity-90 max-w-3xl leading-relaxed">
          {language === 'np' ? currentCat.descriptionNp : currentCat.descriptionEn}
        </p>
      </div>

      {/* Stories Grid */}
      {catArticles.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200 rounded-2xl p-8 space-y-2">
          <p className="text-slate-600 font-semibold text-base">
            {language === 'np' ? 'यस विधामा हाल कुनै समाचार थपिएको छैन।' : 'No news articles currently listed under this category.'}
          </p>
          <p className="text-slate-400 text-xs">
            Our news desk in Waling Syangja is actively covering ongoing developments.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {catArticles.map((art) => (
            <ArticleCard
              key={art.id}
              article={art}
              language={language}
              onArticleClick={onArticleClick}
              onBookmarkToggle={onBookmarkToggle}
              isBookmarked={bookmarkedIds.includes(art.id)}
            />
          ))}
        </div>
      )}

      {/* Category Feed Sponsored Playing Ad Bar */}
      <MidFeedAdPlayingBar language={language} />
    </div>
  );
};
