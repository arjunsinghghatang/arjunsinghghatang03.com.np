import React, { useState } from 'react';
import { Flame, Filter, ArrowUpDown, Search, Grid, List } from 'lucide-react';
import { NewsArticle, Language, CategoryId } from '../types';
import { getTranslation } from '../data/translations';
import { ArticleCard } from '../components/ArticleCard';
import { categoriesData } from '../data/newsData';
import { MidFeedAdPlayingBar } from '../components/AdPlayingBars';
import { ReelsShortsBar } from '../components/ReelsShortsBar';
import { ReelsShortsModal } from '../components/ReelsShortsModal';
import { LiveAutoNewsFeedWall } from '../components/LiveAutoNewsFeedWall';
import { reelsStoriesData } from '../data/reelsData';

interface LatestNewsViewProps {
  articles: NewsArticle[];
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
  onBookmarkToggle: (articleId: string) => void;
  bookmarkedIds: string[];
}

export const LatestNewsView: React.FC<LatestNewsViewProps> = ({
  articles,
  language,
  onArticleClick,
  onBookmarkToggle,
  bookmarkedIds,
}) => {
  const [selectedCat, setSelectedCat] = useState<CategoryId | 'all'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'popular'>('newest');
  const [searchQuery, setSearchQuery] = useState('');
  const [layoutMode, setLayoutMode] = useState<'grid' | 'list'>('grid');
  const [activeReelIdx, setActiveReelIdx] = useState<number | null>(null);
  const [isReelModalOpen, setIsReelModalOpen] = useState<boolean>(false);

  let filtered = articles.filter((art) => {
    const matchCat = selectedCat === 'all' || art.category === selectedCat;
    const matchSearch =
      art.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.titleNp.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.excerptEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  if (sortBy === 'newest') {
    filtered = [...filtered].sort(
      (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    );
  } else if (sortBy === 'popular') {
    filtered = [...filtered].sort((a, b) => b.views - a.views);
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="bg-slate-900 text-white p-6 md:p-8 rounded-2xl shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Flame className="w-4 h-4 text-amber-400" />
          <span>{language === 'np' ? 'ताजा समाचार स्ट्रिम' : 'Real-time Stream'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-serif font-black">
          {getTranslation(language, 'latestNews')}
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm max-w-2xl">
          {language === 'np'
            ? 'न्यू नेपाल न्यूजका संवाददाताहरूद्वारा नेपाल तथा विश्वभरबाट निरन्तर सम्प्रेषित विश्वसनीय समाचार।'
            : 'Verified news stream published continuously by New Nepal News reporters across Nepal.'}
        </p>
      </div>

      {/* Stories & Reels Tray Beside News Stream */}
      <ReelsShortsBar
        reels={reelsStoriesData}
        language={language}
        onSelectReel={(_, idx) => {
          setActiveReelIdx(idx);
          setIsReelModalOpen(true);
        }}
        onAddStoryClick={() => {
          setActiveReelIdx(0);
          setIsReelModalOpen(true);
        }}
      />

      {/* Real-time World & Nepal Live Auto Wall */}
      <LiveAutoNewsFeedWall
        language={language}
        onSelectArticle={(art) => onArticleClick && onArticleClick(art)}
      />

      {/* Filter & Toolbar Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Search Box */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={getTranslation(language, 'searchPlaceholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Sort & Layout Controls */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            <div className="flex items-center gap-2 text-xs">
              <ArrowUpDown className="w-4 h-4 text-slate-500" />
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-medium focus:outline-none focus:border-red-500"
              >
                <option value="newest">{getTranslation(language, 'newestFirst')}</option>
                <option value="popular">{getTranslation(language, 'mostPopular')}</option>
              </select>
            </div>

            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setLayoutMode('grid')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'grid' ? 'bg-white shadow-xs text-red-700' : 'text-slate-500'
                }`}
                title="Grid Layout"
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setLayoutMode('list')}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  layoutMode === 'list' ? 'bg-white shadow-xs text-red-700' : 'text-slate-500'
                }`}
                title="List Layout"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-t border-slate-100 pt-3">
          <button
            onClick={() => setSelectedCat('all')}
            className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors cursor-pointer ${
              selectedCat === 'all'
                ? 'bg-red-700 text-white font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {language === 'np' ? 'सबै विधाहरू' : 'All Categories'}
          </button>
          {categoriesData.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors cursor-pointer ${
                selectedCat === cat.id
                  ? 'bg-red-700 text-white font-bold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {language === 'np' ? cat.nameNp : cat.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* Article Feed Grid/List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200 rounded-2xl p-8">
          <p className="text-slate-500 text-sm">{getTranslation(language, 'noResultsFound')}</p>
        </div>
      ) : (
        <div
          className={
            layoutMode === 'grid'
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'
              : 'space-y-4'
          }
        >
          {filtered.map((art) => (
            <ArticleCard
              key={art.id}
              article={art}
              language={language}
              onArticleClick={onArticleClick}
              onBookmarkToggle={onBookmarkToggle}
              isBookmarked={bookmarkedIds.includes(art.id)}
              variant={layoutMode === 'list' ? 'horizontal' : 'grid'}
            />
          ))}
        </div>
      )}

      {/* Mid Feed Sponsored Ad Playing Bar */}
      <MidFeedAdPlayingBar language={language} />

      {/* Reels Shorts Modal Viewer */}
      {isReelModalOpen && activeReelIdx !== null && (
        <ReelsShortsModal
          reels={reelsStoriesData}
          initialIndex={activeReelIdx}
          isOpen={isReelModalOpen}
          onClose={() => setIsReelModalOpen(false)}
          language={language}
          onOpenArticle={onArticleClick ? (artId) => {
            const art = articles.find((a) => a.id === artId);
            if (art) onArticleClick(art);
          } : undefined}
          articles={articles}
        />
      )}
    </div>
  );
};
