import React, { useState } from 'react';
import { Camera, PlayCircle, Eye, Film } from 'lucide-react';
import { Language, VideoNews } from '../types';
import { getTranslation } from '../data/translations';
import { videoNewsData } from '../data/newsData';

interface GalleryViewProps {
  language: Language;
}

export const GalleryView: React.FC<GalleryViewProps> = ({ language }) => {
  const [activeVideo, setActiveVideo] = useState<VideoNews | null>(null);

  const photoStories = [
    {
      id: 'p1',
      titleEn: 'Autumn Harvest in Syangja Valleys',
      titleNp: 'स्याङ्जाका फाँटहरूमा तोरी र धानको फसल',
      imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=1000',
      caption: 'Waling, Syangja',
    },
    {
      id: 'p2',
      titleEn: 'Majestic Sunset over Pokhara Fewa Lake',
      titleNp: 'फेवा तालमा साँझको मनमोहक दृश्यावलोकन',
      imageUrl: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&q=80&w=1000',
      caption: 'Pokhara, Kaski',
    },
    {
      id: 'p3',
      titleEn: 'Cultural Gurung Homestay Traditions in Sirubari',
      titleNp: 'सिरुवारी गाउँमा गुरुङ संस्कृतिको प्रदर्शन',
      imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&q=80&w=1000',
      caption: 'Sirubari, Syangja',
    },
    {
      id: 'p4',
      titleEn: 'Federal Parliament Complex Action',
      titleNp: 'काठमाडौँस्थित नयाँ बानेश्वर संसद परिसर',
      imageUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&q=80&w=1000',
      caption: 'Baneshwor, Kathmandu',
    },
  ];

  return (
    <div className="space-y-12 pb-12">
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'मल्टिमिडिया पोर्टल' : 'Multimedia Portal'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {language === 'np' ? 'भिडियो तथा फोटो ग्यालरी' : 'Video Reports & Photo Gallery'}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'नेपालको जनजीवन, संस्कृति, प्राकृतिक सौन्दर्य र घटनाक्रमहरू समेटिएका उच्च गुणस्तरीय भिडियो रिपोर्ट तथा फोटो स्टोरीहरू।'
            : 'High-definition video documentaries, field video reports, and vivid photo essays capturing Nepal’s landscape, culture, and newsmakers.'}
        </p>
      </div>

      {/* Video Reports Grid */}
      <section className="space-y-6">
        <h2 className="text-2xl font-serif font-black text-slate-900 flex items-center gap-2">
          <Film className="w-6 h-6 text-red-600" />
          <span>{getTranslation(language, 'videoNews')}</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {videoNewsData.map((vid) => (
            <div
              key={vid.id}
              onClick={() => setActiveVideo(vid)}
              className="bg-slate-900 text-white rounded-2xl overflow-hidden border border-slate-800 hover:border-red-500 transition-all cursor-pointer group shadow-lg flex flex-col justify-between"
            >
              <div className="relative h-44 overflow-hidden bg-slate-950">
                <img
                  src={vid.thumbnailUrl}
                  alt={vid.titleEn}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 transition-colors flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-red-700 text-white flex items-center justify-center group-hover:scale-110 transition-transform shadow-xl">
                    <PlayCircle className="w-7 h-7 text-white fill-white" />
                  </div>
                </div>
                <span className="absolute bottom-2 right-2 bg-slate-950/80 text-amber-300 font-mono text-[10px] font-bold px-2 py-0.5 rounded-md">
                  {vid.duration}
                </span>
              </div>

              <div className="p-4 space-y-2">
                <h4 className="text-xs sm:text-sm font-bold font-serif text-slate-100 group-hover:text-amber-300 transition-colors line-clamp-2">
                  {language === 'np' ? vid.titleNp : vid.titleEn}
                </h4>
              </div>

              <div className="p-4 pt-0 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-800">
                <span>{vid.views}</span>
                <span>{vid.publishedAt}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Video Modal Player */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl space-y-4 p-6 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="font-bold text-sm font-serif">
                {language === 'np' ? activeVideo.titleNp : activeVideo.titleEn}
              </h4>
              <button
                onClick={() => setActiveVideo(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>
            <div className="aspect-video bg-black rounded-xl overflow-hidden">
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1`}
                title={activeVideo.titleEn}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* Photo Stories Grid */}
      <section className="space-y-6 pt-4">
        <h2 className="text-2xl font-serif font-black text-slate-900 flex items-center gap-2">
          <Camera className="w-6 h-6 text-red-600" />
          <span>{getTranslation(language, 'photoGallery')}</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {photoStories.map((p) => (
            <div
              key={p.id}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all group"
            >
              <div className="h-64 overflow-hidden relative">
                <img
                  src={p.imageUrl}
                  alt={p.titleEn}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute bottom-3 left-3 bg-slate-950/80 text-white text-xs font-bold px-3 py-1 rounded-md backdrop-blur-xs">
                  📍 {p.caption}
                </span>
              </div>
              <div className="p-4">
                <h4 className="font-serif font-bold text-base text-slate-900">
                  {language === 'np' ? p.titleNp : p.titleEn}
                </h4>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
