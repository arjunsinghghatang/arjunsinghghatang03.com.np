import React from 'react';
import { ShieldCheck, FileText, Lock, RefreshCw } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';

interface LegalViewProps {
  language: Language;
}

export const LegalView: React.FC<LegalViewProps> = ({ language }) => {
  return (
    <div className="space-y-12 pb-12">
      {/* Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'कानूनी नियम तथा गोपनीयता' : 'Legal Compliance'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {getTranslation(language, 'privacyPolicy')}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'न्यू नेपाल न्यूज प्रा. लि. को कानूनी अनुपालन, गोपनीयता नीति, प्रतिलिपि अधिकार र समाचार सच्याउने नीति।'
            : 'Legal compliance, digital reader data protection, copyright terms, and editorial corrections policy of New Nepal News Pvt. Ltd.'}
        </p>
      </div>

      <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 shadow-xs space-y-8 text-slate-800 text-xs sm:text-sm leading-relaxed">
        {/* Section 1 */}
        <div className="space-y-3">
          <h2 className="text-xl font-serif font-bold text-slate-900 flex items-center gap-2">
            <Lock className="w-5 h-5 text-red-700" />
            <span>
              {language === 'np' ? '१. गोपनीयता नीति तथा तथ्याङ्क सुरक्षा' : '1. Privacy Policy & Data Handling'}
            </span>
          </h2>
          <p>
            {language === 'np'
              ? 'न्यू नेपाल न्यूज प्रा. लि. (www.newnepalnews.com.np) पाठकको गोपनीयताप्रति पूर्ण रूपमा प्रतिबद्ध छ। हाम्रा सामग्रीहरू पढ्दा वा नागरिक समाचार पठाउँदा हामी पाठकका व्यक्तिगत विवरणहरू सुरक्षित राख्छौं।'
              : 'New Nepal News Pvt. Ltd. (www.newnepalnews.com.np) is committed to safeguarding reader privacy. When you browse our digital portal, subscribe to newsletters, or submit citizen news tips, we strictly collect only minimal telemetry required for web performance and security.'}
          </p>
          <ul className="list-disc pl-5 space-y-1 text-slate-600">
            <li>
              {language === 'np'
                ? 'हामी पाठकका व्यक्तिगत विवरणहरू कसैलाई पनि बिक्री वा वितरण गर्दैनौं।'
                : 'We do not sell, rent, or distribute user personal data to third-party ad networks.'}
            </li>
            <li>
              {language === 'np'
                ? 'गोप्य रूपमा पठाइएका नागरिक खबर तथा सुराकहरू पत्रकारिता आचारसंहिता अनुसार पूर्ण सुरक्षित राखिन्छ।'
                : 'Citizen news tips submitted anonymously are protected under newsroom confidentiality charters.'}
            </li>
            <li>
              {language === 'np'
                ? 'कुकीजको प्रयोग purely भाषा चयन तथा प्रयोगकर्ता अनुभव सहज बनाउनका लागि मात्र गरिन्छ।'
                : 'Cookie storage is used purely for user interface preferences (e.g., dark reader mode, language selection, and bookmarked articles).'}
            </li>
          </ul>
        </div>

        {/* Section 2 */}
        <div className="space-y-3 pt-6 border-t border-slate-200">
          <h2 className="text-xl font-serif font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-red-700" />
            <span>
              {language === 'np' ? '२. प्रतिलिपि अधिकार तथा सर्वाधिकार' : '2. Copyright & Content Syndication'}
            </span>
          </h2>
          <p>
            {language === 'np'
              ? 'यस पोर्टलमा प्रकाशित सम्पूर्ण समाचार, तस्बिर, भिडियो रिपोर्ट तथा ग्राफिक्सहरू स्याङ्जा वालिङस्थित न्यू नेपाल न्यूज प्रा. लि. को बौद्धिक सम्पत्ति हुन्।'
              : 'All original news articles, field photographs, video reports, and investigative graphics published on this portal are the intellectual property of New Nepal News Pvt. Ltd., headquartered in Waling, Syangja, Nepal.'}
          </p>
          <p>
            {language === 'np'
              ? 'न्यू नेपाल न्यूज प्रा. लि. को लिखित अनुमति बिना सामग्रीहरू पुनःप्रकाशन वा प्रतिलिपि गर्न पूर्ण रूपमा निषेध गरिएको छ।'
              : 'Reproduction, syndication, or re-publishing of any content without prior written permission or clear do-follow attribution to New Nepal News Pvt. Ltd. is strictly prohibited under Nepalese and international copyright laws.'}
          </p>
        </div>

        {/* Section 3 */}
        <div className="space-y-3 pt-6 border-t border-slate-200">
          <h2 className="text-xl font-serif font-bold text-slate-900 flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-red-700" />
            <span>
              {language === 'np' ? '३. सम्पादकीय संशोधन नीति' : '3. Editorial Corrections Policy'}
            </span>
          </h2>
          <p>
            {language === 'np'
              ? 'कुनै समाचारमा प्राविधिक वा तथ्यगत त्रुटि भएमा वालिङ स्याङ्जास्थित हाम्रो सम्पादकीय मण्डलले तुरुन्तै संशोधन गरी स्पष्ट सूचना सहित अद्यावधिक गर्नेछ।'
              : 'In the event of a factual error, our editorial desk in Waling Syangja promptly updates the article text with a clear, transparent correction notice at the bottom of the story outlining what was corrected and when.'}
          </p>
          <p>
            {language === 'np' ? 'सच्याउनका लागि इमेल गर्नुहोस्: ' : 'Readers can request factual corrections directly by emailing '}
            <span className="font-bold text-red-700">newnepalnews11@gmail.com</span>
          </p>
        </div>
      </div>
    </div>
  );
};
