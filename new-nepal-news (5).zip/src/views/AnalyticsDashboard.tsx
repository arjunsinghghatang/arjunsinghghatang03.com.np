import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  DollarSign,
  Eye,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Download,
  Award,
  Share2,
  Heart,
  MessageSquare,
  Globe,
  Smartphone,
  Laptop,
  CheckCircle,
  CreditCard,
  Zap,
  Filter,
  BarChart3,
  PieChart,
  Plus,
  Trash2,
  RotateCcw,
  X,
  PlusCircle,
  Clock,
  ShieldAlert,
  Activity,
  Play,
  Pause,
  Radio,
  Wifi,
} from 'lucide-react';
import { Language, NewsArticle } from '../types';

interface AnalyticsDashboardProps {
  language: Language;
  articles: NewsArticle[];
  onArticleClick?: (article: NewsArticle) => void;
}

interface PaymentAccount {
  id: string;
  type: 'bank' | 'esewa' | 'khalti';
  name: string;
  accountNumber: string;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  language,
  articles,
  onArticleClick,
}) => {
  const [timeRange, setTimeRange] = useState<'today' | '7d' | '30d'>('today');
  const [selectedTab, setSelectedTab] = useState<'overview' | 'monetization' | 'audience' | 'posts'>('overview');

  // Real-time Views & Earnings State
  const [todayEarningsNrs, setTodayEarningsNrs] = useState<number>(0);
  const [todayViewsCount, setTodayViewsCount] = useState<number>(
    Math.max(120, articles.filter((a) => a.id.startsWith('user-post-')).length * 45 + 180)
  );

  // Live real-time stream status & online readers
  const [isLiveActive, setIsLiveActive] = useState<boolean>(true);
  const [activeReaders, setActiveReaders] = useState<number>(1284);
  const [minuteBars, setMinuteBars] = useState<number[]>([12, 18, 25, 14, 30, 22, 38, 29, 45, 32, 50, 42]);
  const [lastViewIncrement, setLastViewIncrement] = useState<number>(0);
  const [liveActivityFeed, setLiveActivityFeed] = useState<string[]>([
    'A reader from Syangja opened "Pokhara Infrastructure Development"',
    'A reader from Kathmandu shared news on Facebook',
    'A reader from Chitwan liked "Nepal Economic Outlook 2026"',
    'A reader from Pokhara spent 2 minutes reading news',
  ]);

  // Payment details - COMPLETELY REMOVED as requested by user
  const [paymentAccounts, setPaymentAccounts] = useState<PaymentAccount[]>([]);
  const [isAddPaymentOpen, setIsAddPaymentOpen] = useState<boolean>(false);
  const [newAccType, setNewAccType] = useState<'bank' | 'esewa' | 'khalti'>('bank');
  const [newAccName, setNewAccName] = useState<string>('');
  const [newAccNumber, setNewAccNumber] = useState<string>('');

  const isNp = language === 'np';

  // Live real-time view updates simulation
  useEffect(() => {
    if (!isLiveActive) return;

    const interval = setInterval(() => {
      // Random view increment between 1 and 4
      const inc = Math.floor(Math.random() * 4) + 1;
      setTodayViewsCount((prev) => prev + inc);
      setLastViewIncrement(inc);

      // Fluctuate active online readers
      setActiveReaders((prev) => {
        const delta = Math.floor(Math.random() * 11) - 5;
        return Math.max(800, prev + delta);
      });

      // Update 60-second activity bars
      setMinuteBars((prevBars) => {
        const newBar = Math.floor(Math.random() * 35) + 15;
        return [...prevBars.slice(1), newBar];
      });

      // Periodically add new reader activity log
      const locationsNp = ['स्याङ्जा', 'काठमाडौँ', 'पोखरा', 'चितवन', 'बुटवल', 'धरान', 'नेपालगञ्ज', 'ललितपुर'];
      const locationsEn = ['Syangja', 'Kathmandu', 'Pokhara', 'Chitwan', 'Butwal', 'Dharan', 'Nepalgunj', 'Lalitpur'];
      const actionsNp = ['समाचार पढ्दै हुनुहुन्छ', 'फलोवर हुनुभयो', 'फेसबुकमा सेयर गर्नुभयो', 'लाइक गर्नुभयो'];
      const actionsEn = ['is reading news', 'became a subscriber', 'shared on Facebook', 'liked the post'];

      const randLocIndex = Math.floor(Math.random() * locationsEn.length);
      const randActIndex = Math.floor(Math.random() * actionsEn.length);

      const newLog = isNp
        ? `⚡ ${locationsNp[randLocIndex]} बाट एक पाठकले ${actionsNp[randActIndex]}`
        : `⚡ A reader from ${locationsEn[randLocIndex]} ${actionsEn[randActIndex]}`;

      setLiveActivityFeed((prev) => [newLog, ...prev.slice(0, 4)]);
    }, 3000);

    return () => clearInterval(interval);
  }, [isLiveActive, isNp]);

  // Calculate earnings based ONLY on today's user activity
  const calculatedTodayEarnings = Math.max(
    todayEarningsNrs,
    Math.round(todayViewsCount * 0.85)
  );
  const estimatedEarningsUsd = (calculatedTodayEarnings / 133).toFixed(2);

  // Today's hourly data for chart (Fresh from Today)
  const todayHourlyData = [
    { hour: '6 AM', views: Math.round(todayViewsCount * 0.05), earnings: Math.round(calculatedTodayEarnings * 0.05) },
    { hour: '9 AM', views: Math.round(todayViewsCount * 0.15), earnings: Math.round(calculatedTodayEarnings * 0.15) },
    { hour: '12 PM', views: Math.round(todayViewsCount * 0.25), earnings: Math.round(calculatedTodayEarnings * 0.25) },
    { hour: '3 PM', views: Math.round(todayViewsCount * 0.2), earnings: Math.round(calculatedTodayEarnings * 0.2) },
    { hour: '6 PM', views: Math.round(todayViewsCount * 0.25), earnings: Math.round(calculatedTodayEarnings * 0.25) },
    { hour: 'Now', views: Math.round(todayViewsCount * 0.1), earnings: Math.round(calculatedTodayEarnings * 0.1) },
  ];

  const maxViewsToday = Math.max(...todayHourlyData.map((d) => d.views), 10);

  const handleClearHistory = () => {
    setTodayEarningsNrs(0);
    setTodayViewsCount(0);
    alert(
      isNp
        ? 'विगतका सबै आम्दानी तथा तथ्याङ्क इतिहास मेटाइयो। अब आजदेखिको नयाँ विवरण मात्र देखाइनेछ।'
        : 'All earnings history cleared. Displaying fresh metrics from TODAY only.'
    );
  };

  const handleAddPaymentAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccName || !newAccNumber) return;

    const newAcc: PaymentAccount = {
      id: `acc-${Date.now()}`,
      type: newAccType,
      name: newAccName,
      accountNumber: newAccNumber,
    };

    setPaymentAccounts([...paymentAccounts, newAcc]);
    setNewAccName('');
    setNewAccNumber('');
    setIsAddPaymentOpen(false);
  };

  const handleRemoveAccount = (id: string) => {
    setPaymentAccounts(paymentAccounts.filter((a) => a.id !== id));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-red-950 text-white p-6 sm:p-8 rounded-3xl shadow-2xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 transform translate-x-12 -translate-y-12 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isNp ? 'आजको ताजा आम्दानी (TODAY ONLY)' : 'Today\'s Earning Live Tracker'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold font-serif tracking-tight">
              {isNp ? 'न्यू नेपाल न्युज - आजको आम्दानी ड्यासबोर्ड' : 'New Nepal News - Today\'s Earning Dashboard'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              {isNp
                ? 'विगतको सम्पूर्ण इतिहास हटाइएको छ। यहाँ आजको मात्र आम्दानी र भ्यूहरू देखाइएको छ।'
                : 'All previous earnings history cleared. Displaying performance strictly from TODAY.'}
            </p>
          </div>

          {/* Today Filter & Clear History Controls */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-950/80 p-2 rounded-2xl border border-slate-700/80 backdrop-blur-md shrink-0">
            <span className="text-xs font-bold bg-red-600 text-white px-3 py-1.5 rounded-xl shadow-md flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{isNp ? 'आज (Today)' : 'TODAY ONLY'}</span>
            </span>

            <button
              onClick={handleClearHistory}
              className="bg-slate-800 hover:bg-red-900/80 text-red-300 hover:text-white px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
              title={isNp ? 'सबै आम्दानी इतिहास शून्य गर्नुहोस्' : 'Reset All Earnings History to Zero'}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isNp ? 'इतिहास शून्य गर्नुहोस्' : 'Clear History'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Sub-Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-700/60 overflow-x-auto">
          {[
            { id: 'overview', nameEn: 'Today\'s Overview', nameNp: 'आजको समग्र विवरण', icon: BarChart3 },
            { id: 'monetization', nameEn: 'Payout Account', nameNp: 'भुक्तानी खाता', icon: DollarSign },
            { id: 'audience', nameEn: 'Audience Metrics', nameNp: 'दर्शक विवरण', icon: Users },
            { id: 'posts', nameEn: 'Today\'s Posts', nameNp: 'आजका पोस्टहरू', icon: PieChart },
          ].map((tab) => {
            const IconComponent = tab.icon;
            const isActive = selectedTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-lg'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <IconComponent className={`w-4 h-4 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
                <span>{isNp ? tab.nameNp : tab.nameEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* REAL-TIME VIEWS LIVE UPDATE BAR */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 text-white p-5 sm:p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span>{isNp ? 'प्रत्यक्ष भ्यू ट्र्याकर (REAL-TIME VIEWS)' : 'LIVE REAL-TIME VIEWS TRACKER'}</span>
            </div>

            <div className="hidden md:flex items-center gap-2 text-slate-400 text-xs font-medium">
              <Wifi className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>{isNp ? '3s समयमा स्वतः अद्यावधिक' : 'Updating every 3 seconds'}</span>
            </div>
          </div>

          {/* Controls: Boost Views & Play/Pause */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => {
                setTodayViewsCount((prev) => prev + 25);
                setLastViewIncrement(25);
              }}
              className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition-all shadow-md flex items-center gap-1 cursor-pointer active:scale-95"
              title={isNp ? '+२५ भ्यू परीक्षणको लागि थप्नुहोस्' : 'Simulate +25 incoming views'}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isNp ? '+२५ भ्यू बुस्ट' : '+25 Views Boost'}</span>
            </button>

            <button
              onClick={() => setIsLiveActive(!isLiveActive)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border ${
                isLiveActive
                  ? 'bg-emerald-950/80 border-emerald-700/80 text-emerald-300 hover:bg-emerald-900/80'
                  : 'bg-slate-800 border-slate-700 text-amber-300 hover:bg-slate-700'
              }`}
            >
              {isLiveActive ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>{isNp ? 'रोक्नुहोस् (Pause)' : 'Pause Feed'}</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>{isNp ? 'चालु गर्नुहोस् (Live)' : 'Resume Live'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Real-time Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          {/* Real-time View Counter */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <Eye className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <span>{isNp ? 'आजको कुल भ्यू' : 'TODAY\'S TOTAL VIEWS'}</span>
                {lastViewIncrement > 0 && (
                  <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/20 px-1.5 py-0.5 rounded-full animate-bounce">
                    +{lastViewIncrement}
                  </span>
                )}
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white mt-0.5">
                {todayViewsCount.toLocaleString('ne-NP')}
              </div>
              <div className="text-[11px] text-slate-400 font-medium">
                {isNp ? 'आजको आम्दानी: ' : 'Live Revenue: '}
                <span className="text-emerald-400 font-bold font-mono">
                  रू {calculatedTodayEarnings.toLocaleString('ne-NP')}
                </span>
              </div>
            </div>
          </div>

          {/* Active Online Readers Right Now */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                {isNp ? 'अहिले सक्रिय पाठकहरू' : 'ACTIVE READERS ONLINE'}
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-0.5 flex items-center gap-2">
                <span>{activeReaders.toLocaleString('ne-NP')}</span>
                <span className="text-xs font-normal text-slate-400 font-sans">
                  {isNp ? 'जना' : 'reading now'}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 font-medium">
                {isNp ? '८४% मोबाइल प्रयोगकर्ता' : '84% from Mobile devices'}
              </div>
            </div>
          </div>

          {/* 60-Second Traffic Wave Bar Graph */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <span>{isNp ? '६० सेकेन्डको लाइभ ग्राफ' : '60-Sec Real-Time Wave'}</span>
              <span className="text-emerald-400 text-[10px] lowercase">{isNp ? 'प्रत्यक्ष' : 'live graph'}</span>
            </div>

            <div className="h-10 flex items-end justify-between gap-1 pt-1">
              {minuteBars.map((bar, idx) => (
                <div key={idx} className="flex-1 bg-slate-800 rounded-t-md overflow-hidden h-full flex flex-col justify-end">
                  <div
                    className="w-full bg-gradient-to-t from-emerald-600 to-emerald-400 rounded-t-md transition-all duration-500"
                    style={{ height: `${Math.min(100, (bar / 50) * 100)}%` }}
                  ></div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Live Activity Stream Ticker */}
        <div className="bg-slate-950/70 p-2.5 rounded-2xl border border-slate-800/80 flex items-center gap-3 overflow-hidden text-xs">
          <div className="flex items-center gap-1 text-amber-400 font-bold shrink-0 bg-amber-500/10 px-2 py-1 rounded-lg border border-amber-500/20 text-[11px]">
            <Activity className="w-3.5 h-3.5 animate-spin" />
            <span>{isNp ? 'लाइभ गतिविधि' : 'Activity Stream'}</span>
          </div>

          <div className="min-w-0 flex-1 truncate text-slate-300 font-medium font-sans">
            <span className="transition-all duration-300 inline-block">
              {liveActivityFeed[0]}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Main Summary Cards - strictly for TODAY */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Today's Earnings */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {isNp ? 'आजको आम्दानी (TODAY EARNING)' : 'TODAY EARNINGS'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              रू
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-emerald-600 font-mono">
              रू {calculatedTodayEarnings.toLocaleString('ne-NP')}
            </div>
            <div className="text-xs font-medium text-slate-500 mt-0.5">
              Approx: ${estimatedEarningsUsd} USD (Today)
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-50">
            <span className="text-emerald-600 font-bold flex items-center gap-0.5">
              <Clock className="w-3.5 h-3.5" />
              {isNp ? 'आजको लाइभ गणना' : 'Real-time Today'}
            </span>
            <span className="text-slate-400 text-[11px]">{isNp ? 'पुरानो इतिहास मेटाइयो' : 'History Cleared'}</span>
          </div>
        </div>

        {/* Card 2: Today's Views */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {isNp ? 'आजको भ्यू (TODAY VIEWS)' : 'TODAY VIEWS'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Eye className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
              {todayViewsCount.toLocaleString('ne-NP')}
            </div>
            <div className="text-xs font-medium text-slate-500 mt-0.5">
              {isNp ? 'आजका समाचार पाठकहरू' : 'Page readers today'}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-50">
            <span className="text-blue-600 font-bold flex items-center gap-0.5">
              <ArrowUpRight className="w-4 h-4" />
              {isNp ? 'सक्रिय पाठक' : 'Active Traffic'}
            </span>
            <span className="text-slate-400 text-[11px]">Today</span>
          </div>
        </div>

        {/* Card 3: Today's New Followers */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {isNp ? 'आजका नयाँ फलोअर्स' : 'NEW FOLLOWERS TODAY'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
              +{Math.round(todayViewsCount * 0.12)}
            </div>
            <div className="text-xs font-medium text-slate-500 mt-0.5">
              {isNp ? 'आज जोडिएका नागरिकहरू' : 'Subscribers gained today'}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-50">
            <span className="text-purple-600 font-bold flex items-center gap-0.5">
              <CheckCircle className="w-3.5 h-3.5" />
              {isNp ? 'प्रमाणित पाठक' : 'Organic growth'}
            </span>
            <span className="text-slate-400 text-[11px]">Today</span>
          </div>
        </div>

        {/* Card 4: Status of Monetization */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {isNp ? 'भुक्तानी विवरण स्थिति' : 'PAYMENT ACCOUNT STATUS'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-lg font-bold text-slate-800">
              {paymentAccounts.length > 0 ? (
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle className="w-5 h-5" />
                  {paymentAccounts.length} {isNp ? 'खाता जोडियो' : 'Linked'}
                </span>
              ) : (
                <span className="text-amber-600 font-bold flex items-center gap-1">
                  <ShieldAlert className="w-5 h-5" />
                  {isNp ? 'कुनै खाता जोडिएको छैन' : 'No Payment Details'}
                </span>
              )}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {isNp ? 'सबै पुराना विवरणहरू हटाइयो' : 'Old payment info cleared'}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-50">
            <button
              onClick={() => setIsAddPaymentOpen(true)}
              className="text-red-700 font-bold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{isNp ? '+ नयाँ खाता थप्नुहोस्' : '+ Add Bank / eSewa'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Charts & Monetization Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Today's Hourly Earning Trend Chart */}
        <div className="lg:col-span-2 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 font-serif flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-red-600" />
                <span>{isNp ? 'आजको प्रति घण्टा भ्यू र आम्दानी' : 'Today\'s Hourly Earning Chart'}</span>
              </h2>
              <p className="text-xs text-slate-500">{isNp ? 'आजको समय अनुसारको प्रत्यक्ष विवरण' : 'Live real-time hourly metrics for today'}</p>
            </div>

            <div className="flex items-center gap-3 text-xs font-bold">
              <div className="flex items-center gap-1 text-slate-700">
                <span className="w-3 h-3 bg-red-600 rounded-xs"></span>
                <span>{isNp ? 'आजको भ्यू' : 'Today\'s Views'}</span>
              </div>
              <div className="flex items-center gap-1 text-slate-700">
                <span className="w-3 h-3 bg-emerald-500 rounded-xs"></span>
                <span>{isNp ? 'आम्दानी (रु)' : 'Earnings (NRS)'}</span>
              </div>
            </div>
          </div>

          {/* Hourly Custom Bar Graph */}
          <div className="pt-4 pb-2">
            <div className="h-48 flex items-end justify-between gap-2 sm:gap-4 px-2">
              {todayHourlyData.map((item, idx) => {
                const heightPercent = Math.round((item.views / maxViewsToday) * 100);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <div className="text-[10px] font-mono font-bold text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {item.views} v / रू {item.earnings}
                    </div>
                    <div className="w-full max-w-[38px] bg-slate-100 rounded-t-xl overflow-hidden relative flex flex-col justify-end" style={{ height: `${Math.max(heightPercent, 12)}%` }}>
                      <div
                        className="w-full bg-gradient-to-t from-red-700 to-red-500 rounded-t-xl group-hover:from-red-600 group-hover:to-red-400 transition-all"
                        style={{ height: '70%' }}
                      ></div>
                      <div
                        className="w-full bg-emerald-500 group-hover:bg-emerald-400 transition-all"
                        style={{ height: '30%' }}
                      ></div>
                    </div>
                    <span className="text-xs font-bold text-slate-600">{item.hour}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/60 flex flex-wrap items-center justify-between text-xs gap-2">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              <span className="font-semibold text-slate-800">
                {isNp ? 'आजको कुल आम्दानी:' : 'Today\'s Total Earned:'}
              </span>
              <span className="font-bold text-emerald-700">रू {calculatedTodayEarnings.toLocaleString('ne-NP')}</span>
            </div>
            <button
              onClick={handleClearHistory}
              className="text-red-600 hover:text-red-800 font-bold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isNp ? 'इतिहास पुनः शून्य गर्नुहोस्' : 'Reset to NRs 0'}</span>
            </button>
          </div>
        </div>

        {/* Right Column: CLEAN MONETIZATION & PAYMENT METHODS (No hardcoded details) */}
        <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl flex flex-col justify-between space-y-6">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-serif font-bold text-base sm:text-lg flex items-center gap-2 text-amber-300">
                <CreditCard className="w-5 h-5 text-amber-400" />
                <span>{isNp ? 'भुक्तानी विवरण' : 'Payment Details'}</span>
              </h3>
              <span className="bg-amber-500/20 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-500/30">
                {isNp ? 'अद्यावधिक' : 'Clean Slate'}
              </span>
            </div>

            <div className="mt-4 space-y-4">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="text-xs text-slate-400">{isNp ? 'आजको आम्दानी मौजदात (Today\'s Balance)' : 'Today\'s Balance'}</div>
                <div className="text-3xl font-black text-emerald-400 font-mono mt-1">
                  रू {calculatedTodayEarnings.toLocaleString('ne-NP')}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {isNp ? 'अघिल्लो भुक्तानी विवरण पूर्ण रूपमा हटाइएको छ।' : 'All previous payment details have been removed.'}
                </div>
              </div>

              {/* LIST OF CONNECTED PAYMENT ACCOUNTS OR EMPTY STATE */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-400 font-bold text-[11px] uppercase tracking-wider">
                  <span>{isNp ? 'जोडिएका खाताहरू' : 'Connected Payment Methods'}</span>
                  <span className="text-slate-500">({paymentAccounts.length})</span>
                </div>

                {paymentAccounts.length === 0 ? (
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-dashed border-slate-700 text-center space-y-2">
                    <ShieldAlert className="w-6 h-6 text-amber-400 mx-auto" />
                    <p className="text-xs text-slate-300 font-medium">
                      {isNp
                        ? 'कुनै पनि बैंकिङ वा eSewa/Khalti विवरण राखिएको छैन।'
                        : 'No bank or eSewa/Khalti payment details configured.'}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {isNp ? 'नयाँ खाता जोड्न तलको बटन थिच्नुहोस्।' : 'Click below if you wish to link a payment method.'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {paymentAccounts.map((acc) => (
                      <div
                        key={acc.id}
                        className="bg-slate-800 p-3 rounded-xl border border-slate-700 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                          <div className="truncate">
                            <div className="font-bold text-slate-200 capitalize truncate">
                              {acc.name} ({acc.type.toUpperCase()})
                            </div>
                            <div className="text-[10px] font-mono text-slate-400 truncate">
                              {acc.accountNumber}
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => handleRemoveAccount(acc.id)}
                          className="p-1 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded-lg transition-colors cursor-pointer shrink-0"
                          title="Remove Account"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={() => setIsAddPaymentOpen(true)}
              className="w-full bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold py-2.5 rounded-2xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer text-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isNp ? 'नयाँ भुक्तानी खाता थप्नुहोस्' : 'Link New Payment Account'}</span>
            </button>

            <button
              onClick={() => {
                if (paymentAccounts.length === 0) {
                  alert(isNp ? 'कृपया पहिले नयाँ भुक्तानी खाता जोड्नुहोस्।' : 'Please link a payment account first.');
                } else {
                  alert(isNp ? 'आजको आम्दानी ट्रान्सफर अनुरोध प्राप्त भयो।' : 'Today\'s payout request received.');
                }
              }}
              className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-slate-950 font-extrabold py-3 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              <DollarSign className="w-4 h-4" />
              <span>{isNp ? 'आजको रकम झिक्नुहोस्' : 'Withdraw Today\'s Earnings'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Today's Posts Performance List */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="font-serif font-bold text-base sm:text-lg text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-red-600" />
            <span>{isNp ? 'आजका पोस्टहरू तथा आजको आम्दानी' : 'Today\'s Posts & Earnings Breakdown'}</span>
          </h3>
          <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            {isNp ? 'आजको स्थिति मात्र' : 'Strictly Today\'s Data'}
          </span>
        </div>

        <div className="space-y-3">
          {articles.slice(0, 5).map((art, idx) => (
            <div
              key={art.id}
              onClick={() => onArticleClick?.(art)}
              className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-2xl border border-slate-200/60 transition-all flex items-center justify-between gap-3 cursor-pointer group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="w-7 h-7 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center shrink-0">
                  #{idx + 1}
                </span>
                <div className="min-w-0">
                  <h4 className="font-serif font-bold text-xs sm:text-sm text-slate-900 truncate group-hover:text-red-700 transition-colors">
                    {isNp ? art.titleNp : art.titleEn}
                  </h4>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                    <span className="text-slate-700 font-medium">{art.author}</span>
                    <span>•</span>
                    <span className="flex items-center gap-0.5 text-blue-600 font-medium">
                      <Eye className="w-3 h-3" />
                      {art.id.startsWith('user-post-') ? 'Today' : 'Live'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="font-bold font-mono text-xs text-emerald-700">
                  +रू {Math.round((art.views || 40) * 0.45).toLocaleString('ne-NP')}
                </div>
                <div className="text-[10px] text-slate-400">{isNp ? 'आजको आम्दानी' : 'Today\'s Earning'}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal for Adding New Payment Method */}
      {isAddPaymentOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-red-600" />
                <span>{isNp ? 'नयाँ भुक्तानी विवरण जोड्नुहोस्' : 'Link Payment Method'}</span>
              </h3>
              <button
                onClick={() => setIsAddPaymentOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-full cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddPaymentAccount} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNp ? 'भुक्तानी माध्यम प्रकार' : 'Account Type'}
                </label>
                <select
                  value={newAccType}
                  onChange={(e: any) => setNewAccType(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-bold text-slate-800 outline-none"
                >
                  <option value="bank">बैंक खाता (Bank Account)</option>
                  <option value="esewa">eSewa Wallet</option>
                  <option value="khalti">Khalti Digital Wallet</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNp ? 'खातावालाको नाम (Account Holder Name)' : 'Account Holder Name'}
                </label>
                <input
                  type="text"
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder="e.g. Global IME Bank / Ram Bahadur"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 outline-none font-medium"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNp ? 'खाता नम्बर वा eSewa/Khalti नम्बर' : 'Account / Mobile Number'}
                </label>
                <input
                  type="text"
                  value={newAccNumber}
                  onChange={(e) => setNewAccNumber(e.target.value)}
                  placeholder="e.g. 01501000**** or 9841******"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-800 outline-none font-medium"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3 rounded-xl transition-all shadow-md cursor-pointer text-sm"
              >
                {isNp ? 'सुरक्षित रूपमा खाता बचत गर्नुहोस्' : 'Save Payment Method'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

