import React from 'react';
import {
  Building2,
  CheckCircle2,
  Globe,
  MapPin,
  Mail,
  Phone,
  Target,
  Award,
  Users,
  Calendar,
  ShieldCheck,
  Newspaper,
  Compass,
} from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';

interface AboutViewProps {
  language: Language;
}

export const AboutView: React.FC<AboutViewProps> = ({ language }) => {
  return (
    <div className="space-y-12 pb-12">
      {/* Hero Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl relative overflow-hidden space-y-4">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none p-12">
          <Newspaper className="w-80 h-80 text-white" />
        </div>

        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'कम्पनी परिचय' : 'Company Overview'}
        </span>

        <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-black text-white max-w-3xl leading-tight">
          {getTranslation(language, 'companyLegal')}
        </h1>

        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'नेपाल तथा विश्वभरका सत्य, तथ्य र निष्पक्ष समाचार सम्प्रेषण गर्ने स्वतन्त्र डिजिटल न्यूज प्लेटफर्म।'
            : 'Independent digital news platform delivering accurate, timely, and unbiased news from Nepal and around the world.'}
        </p>
      </div>

      {/* Key Company Details Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'उद्योग' : 'Industry'}
          </p>
          <p className="text-xs font-extrabold text-slate-900">
            {language === 'np' ? 'डिजिटल न्यूज तथा मिडिया' : 'Digital News & Media'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'स्थापना वर्ष' : 'Founded Year'}
          </p>
          <p className="text-xs font-extrabold text-slate-900">
            {language === 'np' ? '२०८२ (२०२६)' : '2026'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'प्रधान कार्यालय' : 'Head Office'}
          </p>
          <p className="text-xs font-extrabold text-slate-900">
            {language === 'np' ? 'वालिङ, स्याङ्जा' : 'Waling Syangja'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'कम्पनीको प्रकार' : 'Business Type'}
          </p>
          <p className="text-xs font-extrabold text-slate-900">
            {language === 'np' ? 'प्राइभेट लिमिटेड' : 'Private Limited'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'कार्यरत टोली' : 'Team Members'}
          </p>
          <p className="text-xs font-extrabold text-slate-900">
            {language === 'np' ? '१५ जना पूर्णकालीन कर्मचारी' : '15 Full-time Staff'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <p className="text-[10px] font-bold uppercase text-slate-400">
            {language === 'np' ? 'आधिकारिक पोर्टल' : 'Official Portal'}
          </p>
          <p className="text-xs font-extrabold text-red-700">newnepalnews.com.np</p>
        </div>
      </div>

      {/* Narrative Section: About Us */}
      <section className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-xs">
        <div className="md:col-span-7 space-y-4">
          <span className="text-xs font-bold text-red-700 uppercase tracking-widest bg-red-50 px-2.5 py-1 rounded-md">
            {language === 'np' ? 'हाम्रो परिचय' : 'Who We Are'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-black text-slate-900">
            {language === 'np'
              ? 'गण्डकी प्रदेशको मुटुबाट निष्पक्ष पत्रकारिता'
              : 'Journalistic Excellence from the Heart of Gandaki Province'}
          </h2>
          <p className="text-slate-600 text-sm leading-relaxed">
            {language === 'np'
              ? 'न्यू नेपाल न्यूज एक स्वतन्त्र डिजिटल समाचार प्लेटफर्म हो जसले नेपाल र विश्वभरका सही, सामयिक र निष्पक्ष समाचार सम्प्रेषण गर्दछ। हामी राजनीति, अर्थतन्त्र, प्रविधि, खेलकुद, मनोरञ्जन, पर्यटन, शिक्षा र अन्तर्राष्ट्रिय विषयहरू समेट्छौं।'
              : 'New Nepal News is an independent digital news platform that delivers accurate, timely, and unbiased news from Nepal and around the world. We cover politics, business, technology, sports, entertainment, tourism, education, and international affairs.'}
          </p>
          <p className="text-slate-600 text-sm leading-relaxed">
            {language === 'np'
              ? 'स्याङ्जाको वालिङमा प्रधान कार्यालय रहेको हाम्रो डिजिटल न्युजरुमको मुख्य ध्येय आधुनिक प्रविधिको प्रयोग गरी जनतालाई छिटो र भरपर्दो समाचार पुर्याउनु हो।'
              : 'Established with a decentralized newsroom model headquartered in Waling, Syangja, our mission is to provide trustworthy journalism while making news accessible through modern digital platforms.'}
          </p>
        </div>

        <div className="md:col-span-5 bg-slate-900 text-white rounded-2xl p-6 space-y-4 border border-slate-800">
          <h3 className="text-lg font-serif font-bold text-amber-300">
            {language === 'np' ? 'सम्पर्क विवरण' : 'Quick Contact Specs'}
          </h3>
          <div className="space-y-3 text-xs">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">
                  {language === 'np' ? 'दर्ता भएको ठेगाना' : 'Registered Address'}
                </p>
                <p className="text-slate-300">
                  {language === 'np' ? 'वालिङ, स्याङ्जा, गण्डकी प्रदेश, नेपाल' : 'Waling, Syangja, Gandaki Province, Nepal'}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <Mail className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">
                  {language === 'np' ? 'इमेल' : 'Emails'}
                </p>
                <p className="text-slate-300">newnepalnews11@gmail.com</p>
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <Phone className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">
                  {language === 'np' ? 'फोन नम्बर' : 'Phone Line'}
                </p>
                <p className="text-slate-300">+977-063-440555</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission Cards */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Vision Card */}
        <div className="bg-gradient-to-br from-red-900 to-slate-900 text-white p-8 rounded-3xl border border-red-800 shadow-xl space-y-4">
          <div className="p-3 bg-red-700/80 text-amber-300 rounded-2xl w-fit">
            <Target className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-serif font-black text-white">
            {language === 'np' ? 'हाम्रो दूरदृष्टि (Vision)' : 'Our Vision'}
          </h3>
          <p className="text-red-100 text-base leading-relaxed font-medium">
            {language === 'np'
              ? '"नेपालको सबैभन्दा विश्वासिलो डिजिटल समाचार माध्यम बन्नु।"'
              : '"To become Nepal\'s most trusted digital news platform."'}
          </p>
          <p className="text-xs text-red-200 leading-relaxed pt-2 border-t border-red-800">
            {language === 'np'
              ? 'नेपालका ७७ वै जिल्लामा सत्यतथ्य समाचार, मल्टिमिडिया रिपोर्टिङ र नागरिककेन्द्रित पत्रकारिताको नयाँ मापदण्ड कायम गर्दै।'
              : 'Setting benchmark standards in factual reporting, multimedia storytelling, and citizen-first digital journalism across all 77 districts of Nepal.'}
          </p>
        </div>

        {/* Mission Card */}
        <div className="bg-white border border-slate-200 p-8 rounded-3xl shadow-xs space-y-4">
          <div className="p-3 bg-slate-900 text-amber-400 rounded-2xl w-fit">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h3 className="text-2xl font-serif font-black text-slate-900">
            {language === 'np' ? 'हाम्रो ध्येय (Mission)' : 'Our Mission'}
          </h3>
          <ul className="space-y-3 text-sm text-slate-700 font-medium">
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                {language === 'np' ? 'तथ्यपरक र निष्पक्ष समाचार सम्प्रेषण गर्ने।' : 'Deliver factual and unbiased news.'}
              </span>
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                {language === 'np'
                  ? 'सुशासनमा पारदर्शिता र जवाफदेहिता प्रवर्द्धन गर्ने।'
                  : 'Promote transparency and accountability in governance.'}
              </span>
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                {language === 'np'
                  ? 'स्वतन्त्र पत्रकारिता र स्थलगत संवाददाताहरूलाई प्रोत्साहन गर्ने।'
                  : 'Support independent journalism and field correspondents.'}
              </span>
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>
                {language === 'np'
                  ? 'नागरिकहरूलाई चौबीसै घण्टा ताजा अपडेटहरू प्रदान गर्ने।'
                  : 'Keep citizens informed with real-time updates 24/7.'}
              </span>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};
