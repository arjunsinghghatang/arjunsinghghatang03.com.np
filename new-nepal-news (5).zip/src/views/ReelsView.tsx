import React, { useState } from 'react';
import { Film, Play, Sparkles, Flame, Eye, Heart, MessageCircle, Share2, PlusCircle, CheckCircle2 } from 'lucide-react';
import { ReelStoryItem, Language, NewsArticle } from '../types';
import { reelsStoriesData } from '../data/reelsData';
import { ReelsShortsModal } from '../components/ReelsShortsModal';
import { ReelsShortsBar } from '../components/ReelsShortsBar';

interface ReelsViewProps {
  language: Language;
  articles: NewsArticle[];
  onArticleClick: (article: NewsArticle) => void;
}

export const ReelsView: React.FC<ReelsViewProps> = ({
  language,
  articles,
  onArticleClick,
}) => {
  const [selectedReelIndex, setSelectedReelIndex] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const isNp = language === 'np';

  const handleOpenReel = (index: number) => {
    setSelectedReelIndex(index);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-purple-900/60 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-pink-500 to-red-600 text-white px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider">
              <Film className="w-3.5 h-3.5" />
              <span>{isNp ? 'नेपाल समाचार रिल्स हब' : 'Nepal News Reels & Shorts Feed'}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold font-serif tracking-tight">
              {isNp ? 'समाचार रिल्स, शर्ट्स तथा प्रत्यक्ष भिडियोहरू' : 'Reels, Shorts & Video Stories'}
            </h1>

            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {isNp
                ? 'टिकटक, फेसबुक रिल्स र युट्युब शर्ट्स शैलीमा नेपालका ताजा घटनाक्रम, पोखरा-स्याङ्जा रिपोर्टिङ तथा विशेष भिडियोहरू हेर्नुहोस्।'
                : 'Experience fast-paced vertical news reels, field reports, and video stories inspired by TikTok, YouTube Shorts & Facebook Reels.'}
            </p>
          </div>

          <button
            onClick={() => handleOpenReel(0)}
            className="bg-gradient-to-r from-red-600 via-pink-600 to-amber-500 hover:scale-105 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer text-sm shrink-0 active:scale-95 border border-pink-400/40"
          >
            <Play className="w-5 h-5 fill-white" />
            <span>{isNp ? 'सबै रिल्स प्ले गर्नुहोस्' : 'Play All Reels'}</span>
          </button>
        </div>
      </div>

      {/* Top Story Tray */}
      <ReelsShortsBar
        reels={reelsStoriesData}
        language={language}
        onSelectReel={(_, idx) => handleOpenReel(idx)}
        onAddStoryClick={() => handleOpenReel(0)}
      />

      {/* Grid of Short Reels */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <h3 className="text-lg font-serif font-black text-slate-900 flex items-center gap-2">
            <Flame className="w-5 h-5 text-red-600" />
            <span>{isNp ? 'लोकप्रिय समाचार रिल्स' : 'Trending Short News Reels'}</span>
          </h3>

          <span className="text-xs font-bold text-slate-500 font-mono">
            {reelsStoriesData.length} {isNp ? 'भिडियोहरू' : 'Reels Available'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {reelsStoriesData.map((reel, idx) => (
            <div
              key={reel.id}
              onClick={() => handleOpenReel(idx)}
              className="h-72 sm:h-80 rounded-2xl overflow-hidden relative border-2 border-slate-800 hover:border-pink-500 transition-all duration-300 cursor-pointer group shadow-md hover:shadow-2xl bg-slate-900 flex flex-col justify-between"
            >
              {/* Media Thumbnail */}
              <img
                src={reel.thumbnailUrl}
                alt={reel.titleEn}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
              />

              {/* Dark Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-black/50" />

              {/* Top Creator Avatar Ring */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5 z-10">
                <div className="w-7 h-7 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-pink-500 to-red-600 shadow-md">
                  <img
                    src={reel.creatorAvatar}
                    alt={reel.creatorName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                {reel.isVerified && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 fill-blue-400" />
                )}
              </div>

              {/* Play Button Icon */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-slate-950/80 backdrop-blur-md border border-white/30 text-white flex items-center justify-center group-hover:scale-115 group-hover:bg-red-600 transition-all shadow-2xl z-10">
                <Play className="w-6 h-6 fill-white ml-0.5" />
              </div>

              {/* Duration Tag */}
              <div className="absolute top-2 right-2 bg-slate-950/80 text-amber-300 text-[10px] font-mono px-2 py-0.5 rounded-md border border-slate-700 z-10">
                {reel.duration || '0:30'}
              </div>

              {/* Bottom Info */}
              <div className="absolute bottom-2 left-2 right-2 space-y-1 z-10">
                <div className="flex items-center justify-between text-[10px] text-amber-300 font-mono font-bold">
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3 text-amber-400" />
                    {(reel.views / 1000).toFixed(1)}k
                  </span>
                  <span className="flex items-center gap-0.5 text-pink-400">
                    <Heart className="w-3 h-3 fill-pink-400" />
                    {(reel.likes / 1000).toFixed(1)}k
                  </span>
                </div>

                <p className="text-xs font-bold text-white line-clamp-2 leading-tight group-hover:text-amber-200">
                  {isNp ? reel.titleNp : reel.titleEn}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Popup Viewer */}
      {isModalOpen && selectedReelIndex !== null && (
        <ReelsShortsModal
          reels={reelsStoriesData}
          initialIndex={selectedReelIndex}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          language={language}
          onOpenArticle={(artId) => {
            const art = articles.find((a) => a.id === artId);
            if (art) onArticleClick(art);
          }}
          articles={articles}
        />
      )}
    </div>
  );
};
