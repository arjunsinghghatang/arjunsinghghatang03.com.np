import React, { useState } from 'react';
import {
  Flame,
  TrendingUp,
  Cpu,
  Trophy,
  Landmark,
  Compass,
  PlayCircle,
  ArrowRight,
  MapPin,
  Sparkles,
  Newspaper,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { NewsArticle, Language, CategoryId, PageView, VideoNews } from '../types';
import { getTranslation } from '../data/translations';
import { HeroSlider } from '../components/HeroSlider';
import { ArticleCard } from '../components/ArticleCard';
import { CreatePostBar } from '../components/CreatePostBar';
import { videoNewsData, categoriesData } from '../data/newsData';
import { MidFeedAdPlayingBar } from '../components/AdPlayingBars';
import { ReelsShortsBar } from '../components/ReelsShortsBar';
import { ReelsShortsModal } from '../components/ReelsShortsModal';
import { InlineNewsReelWidget } from '../components/InlineNewsReelWidget';
import { reelsStoriesData } from '../data/reelsData';
import { LiveAutoNewsFeedWall } from '../components/LiveAutoNewsFeedWall';
import { Film } from 'lucide-react';

interface HomeViewProps {
  articles: NewsArticle[];
  language: Language;
  onArticleClick: (article: NewsArticle) => void;
  onBookmarkToggle: (articleId: string) => void;
  bookmarkedIds: string[];
  onNavigatePage: (page: PageView) => void;
  onSelectCategory: (cat: CategoryId) => void;
  onOpenSubmitTip: () => void;
  onPostCreated?: (newPost: NewsArticle) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  articles,
  language,
  onArticleClick,
  onBookmarkToggle,
  bookmarkedIds,
  onNavigatePage,
  onSelectCategory,
  onOpenSubmitTip,
  onPostCreated,
}) => {
  const [activeVideo, setActiveVideo] = useState<VideoNews | null>(null);
  const [activeReelIdx, setActiveReelIdx] = useState<number | null>(null);
  const [isReelModalOpen, setIsReelModalOpen] = useState<boolean>(false);

  const handleOpenReelModal = (idx: number) => {
    setActiveReelIdx(idx);
    setIsReelModalOpen(true);
  };

  // Categorized Article slices
  const trendingArticles = articles.filter((a) => a.isTrending || a.views > 9000).slice(0, 5);
  const syangjaArticles = articles.filter((a) => a.location?.includes('Syangja') || a.location?.includes('Waling') || a.id === 'art-1').slice(0, 3);
  const businessArticles = articles.filter((a) => a.category === 'business').slice(0, 4);
  const techArticles = articles.filter((a) => a.category === 'technology').slice(0, 4);
  const sportsArticles = articles.filter((a) => a.category === 'sports').slice(0, 4);
  const politicsArticles = articles.filter((a) => a.category === 'politics').slice(0, 4);
  const tourismArticles = articles.filter((a) => a.category === 'tourism').slice(0, 4);
  const opinionArticles = articles.filter((a) => a.category === 'opinion').slice(0, 3);

  return (
    <div className="space-y-8 pb-12">
      {/* Facebook-style Write Status & Upload Media Bar */}
      {onPostCreated && (
        <CreatePostBar
          language={language}
          onPostCreated={onPostCreated}
        />
      )}

      {/* 1. Hero Breaking News Slider */}
      <section className="pt-2">
        <HeroSlider
          articles={articles}
          language={language}
          onArticleClick={onArticleClick}
        />
      </section>

      {/* 1.5 Facebook & TikTok Style Stories & Reels Bar */}
      <section>
        <ReelsShortsBar
          reels={reelsStoriesData}
          language={language}
          onSelectReel={(_, idx) => handleOpenReelModal(idx)}
          onAddStoryClick={() => handleOpenReelModal(0)}
        />
      </section>

      {/* 1.8 WORLD & NEPAL LIVE AUTO-UPDATE NEWS WALL FEED */}
      <section>
        <LiveAutoNewsFeedWall
          language={language}
          onSelectArticle={onArticleClick}
        />
      </section>

      {/* 2. Syangja & Gandaki Special Spotlight (Head Office Feature) */}
      <section className="bg-gradient-to-r from-red-900 via-red-950 to-slate-900 text-white rounded-2xl p-6 md:p-8 border border-red-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-red-800/80 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-red-700 text-amber-300 rounded-xl shadow-md">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-serif font-extrabold text-white">
                {getTranslation(language, 'localSyangja')}
              </h3>
              <p className="text-xs text-red-200">
                {language === 'np'
                  ? 'वालिङ, पुतलीबजार, गल्याङ र पोखरा ब्युरोबाट प्रत्यक्ष समाचार रिपोर्टिङ'
                  : 'Direct field reporting from Waling, Putalibazar, Galyang & Pokhara Bureau'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              onSelectCategory('breaking');
              onNavigatePage('category');
            }}
            className="text-xs font-bold bg-white text-red-900 hover:bg-amber-300 hover:text-slate-950 px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <span>{getTranslation(language, 'viewAll')}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {syangjaArticles.map((art) => (
            <div
              key={art.id}
              onClick={() => onArticleClick(art)}
              className="bg-slate-900/90 border border-red-800/60 rounded-xl overflow-hidden hover:border-amber-400 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="h-40 overflow-hidden relative">
                <img
                  src={art.imageUrl}
                  alt={art.titleEn}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-2 left-2 bg-red-700 text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                  {art.location}
                </span>
              </div>
              <div className="p-4 space-y-2">
                <h4 className="text-sm font-bold font-serif text-white group-hover:text-amber-300 transition-colors line-clamp-2">
                  {language === 'np' ? art.titleNp : art.titleEn}
                </h4>
                <p className="text-xs text-slate-300 line-clamp-2">
                  {language === 'np' ? art.excerptNp : art.excerptEn}
                </p>
              </div>
              <div className="p-4 pt-0 text-[11px] text-amber-400 font-semibold flex items-center justify-between border-t border-slate-800/80">
                <span>By {art.author}</span>
                <span>{art.readTimeMinutes} min read</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Main Content Grid: Trending News Sidebar + Latest Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Feed Left (8 cols) */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-3">
            <h3 className="text-xl font-serif font-black text-slate-900 flex items-center gap-2">
              <Flame className="w-5 h-5 text-red-600" />
              <span>{getTranslation(language, 'latestNews')}</span>
            </h3>

            <button
              onClick={() => onNavigatePage('latest')}
              className="text-xs font-bold text-red-700 hover:text-red-900 flex items-center gap-1 cursor-pointer"
            >
              <span>{getTranslation(language, 'viewAll')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {articles.slice(0, 6).map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                language={language}
                onArticleClick={onArticleClick}
                onBookmarkToggle={onBookmarkToggle}
                isBookmarked={bookmarkedIds.includes(art.id)}
              />
            ))}
          </div>
        </div>

        {/* Trending Sidebar Right (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Trending Articles */}
          <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-serif font-bold text-amber-300 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-red-500" />
                <span>{getTranslation(language, 'trending')}</span>
              </h3>
              <span className="text-[10px] bg-red-700 text-white font-bold px-2 py-0.5 rounded-full">
                LIVE 24/7
              </span>
            </div>

            <div className="space-y-3">
              {trendingArticles.map((art, idx) => (
                <ArticleCard
                  key={art.id}
                  article={art}
                  language={language}
                  onArticleClick={onArticleClick}
                  variant="trending"
                  rankIndex={idx}
                />
              ))}
            </div>
          </div>

          {/* Reels Shorts Right Beside News Sidebar */}
          <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-1 bg-gradient-to-r from-pink-500 to-red-600 rounded-md text-white">
                  <Film className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-serif font-bold text-white">
                  {language === 'np' ? 'समाचार भिडियो रिल्स' : 'News Shorts & Reels'}
                </h3>
              </div>
              <button
                onClick={() => handleOpenReelModal(0)}
                className="text-[11px] font-bold text-pink-400 hover:text-pink-300 underline cursor-pointer"
              >
                {language === 'np' ? 'सबै हेर्नुहोस्' : 'Watch All'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {reelsStoriesData.slice(0, 4).map((reel, idx) => (
                <InlineNewsReelWidget
                  key={reel.id}
                  reel={reel}
                  language={language}
                  onOpenReel={() => handleOpenReelModal(idx)}
                />
              ))}
            </div>
          </div>

          {/* Submit Tip CTA Box */}
          <div className="bg-gradient-to-br from-red-700 to-red-900 text-white p-6 rounded-2xl shadow-lg space-y-3 border border-red-600">
            <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
              <ShieldCheck className="w-5 h-5 text-amber-300" />
              <span>{language === 'np' ? 'नागरिक पत्रकारिता डेस्क' : 'Citizen Journalism Desk'}</span>
            </div>
            <h4 className="text-lg font-serif font-bold">
              {language === 'np' ? 'के तपाईंसँग कुनै समाचार वा प्रेस विज्ञप्ति छ?' : 'Have a News Tip or Press Release?'}
            </h4>
            <p className="text-xs text-red-100 leading-relaxed">
              {language === 'np'
                ? 'वालिङ स्याङ्जास्थित न्यू नेपाल न्यूजको सम्पादकीय कक्षमा सिधै खबर वा समाचार पठाउनुहोस्।'
                : 'Send confidential leads directly to the New Nepal News editorial room in Waling Syangja.'}
            </p>
            <button
              onClick={onOpenSubmitTip}
              className="w-full bg-white text-red-900 hover:bg-amber-300 hover:text-slate-950 font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer shadow-md"
            >
              {getTranslation(language, 'submitTip')}
            </button>
          </div>
        </div>
      </section>

      {/* Interactive Mid-Feed Ad Playing Bar */}
      <MidFeedAdPlayingBar
        language={language}
        onOpenAdvertiseModal={() => onNavigatePage('services')}
      />

      {/* 4. Category Blocks: Business & Technology */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
        {/* Business Category Block */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-emerald-600 pb-3">
            <h3 className="text-lg font-serif font-extrabold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              <span>{language === 'np' ? 'व्यापार तथा अर्थतन्त्र' : 'Business & Economy'}</span>
            </h3>
            <button
              onClick={() => {
                onSelectCategory('business');
                onNavigatePage('category');
              }}
              className="text-xs font-bold text-emerald-700 hover:underline"
            >
              {getTranslation(language, 'viewAll')} →
            </button>
          </div>

          <div className="space-y-3">
            {businessArticles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                language={language}
                onArticleClick={onArticleClick}
                variant="compact"
              />
            ))}
          </div>
        </div>

        {/* Technology Category Block */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-cyan-600 pb-3">
            <h3 className="text-lg font-serif font-extrabold text-slate-900 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-cyan-600" />
              <span>{language === 'np' ? 'सूचना तथा प्रविधि' : 'Technology & IT'}</span>
            </h3>
            <button
              onClick={() => {
                onSelectCategory('technology');
                onNavigatePage('category');
              }}
              className="text-xs font-bold text-cyan-700 hover:underline"
            >
              {getTranslation(language, 'viewAll')} →
            </button>
          </div>

          <div className="space-y-3">
            {techArticles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                language={language}
                onArticleClick={onArticleClick}
                variant="compact"
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Video Reports Showcase */}
      <section className="bg-slate-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-700 text-white rounded-xl">
              <PlayCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold text-white">
                {getTranslation(language, 'videoNews')}
              </h3>
              <p className="text-xs text-slate-400">Ground documentaries and field video reports</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {videoNewsData.map((vid) => (
            <div
              key={vid.id}
              onClick={() => setActiveVideo(vid)}
              className="bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 hover:border-red-500 transition-all cursor-pointer group shadow-lg flex flex-col justify-between"
            >
              <div className="relative h-44 overflow-hidden bg-slate-950">
                <img
                  src={vid.thumbnailUrl}
                  alt={vid.titleEn}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 transition-colors flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-red-700 text-white flex items-center justify-center group-hover:scale-110 transition-transform shadow-xl">
                    <PlayCircle className="w-7 h-7 text-white fill-white" />
                  </div>
                </div>
                <span className="absolute bottom-2 right-2 bg-slate-950/80 text-amber-300 font-mono text-[10px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                  {vid.duration}
                </span>
              </div>

              <div className="p-4 space-y-2">
                <span className="text-[10px] font-bold uppercase text-red-400 bg-red-950/80 px-2 py-0.5 rounded-xs">
                  {vid.category}
                </span>
                <h4 className="text-xs sm:text-sm font-bold font-serif text-slate-100 group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                  {language === 'np' ? vid.titleNp : vid.titleEn}
                </h4>
              </div>

              <div className="p-4 pt-0 text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-800/60">
                <span>{vid.views}</span>
                <span>{vid.publishedAt}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Video Modal Player */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl space-y-4 p-6 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="font-bold text-sm font-serif">
                {language === 'np' ? activeVideo.titleNp : activeVideo.titleEn}
              </h4>
              <button
                onClick={() => setActiveVideo(null)}
                className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>
            <div className="aspect-video bg-black rounded-xl overflow-hidden">
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1`}
                title={activeVideo.titleEn}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      {/* 6. Sports & Tourism Blocks */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Sports Block */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-amber-600 pb-3">
            <h3 className="text-lg font-serif font-extrabold text-slate-900 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-600" />
              <span>{language === 'np' ? 'खेलकुद' : 'Sports'}</span>
            </h3>
            <button
              onClick={() => {
                onSelectCategory('sports');
                onNavigatePage('category');
              }}
              className="text-xs font-bold text-amber-700 hover:underline"
            >
              {getTranslation(language, 'viewAll')} →
            </button>
          </div>

          <div className="space-y-3">
            {sportsArticles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                language={language}
                onArticleClick={onArticleClick}
                variant="compact"
              />
            ))}
          </div>
        </div>

        {/* Tourism Block */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-teal-600 pb-3">
            <h3 className="text-lg font-serif font-extrabold text-slate-900 flex items-center gap-2">
              <Compass className="w-5 h-5 text-teal-600" />
              <span>{language === 'np' ? 'पर्यटन तथा संस्कृति' : 'Tourism & Culture'}</span>
            </h3>
            <button
              onClick={() => {
                onSelectCategory('tourism');
                onNavigatePage('category');
              }}
              className="text-xs font-bold text-teal-700 hover:underline"
            >
              {getTranslation(language, 'viewAll')} →
            </button>
          </div>

          <div className="space-y-3">
            {tourismArticles.map((art) => (
              <ArticleCard
                key={art.id}
                article={art}
                language={language}
                onArticleClick={onArticleClick}
                variant="compact"
              />
            ))}
          </div>
        </div>
      </section>

      {/* 7. Opinion & Editorial Column */}
      <section className="bg-slate-100 border border-slate-200 rounded-2xl p-6 md:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-300 pb-3">
          <h3 className="text-xl font-serif font-black text-slate-900">
            {getTranslation(language, 'opinionAndAnalysis')}
          </h3>
          <button
            onClick={() => {
              onSelectCategory('opinion');
              onNavigatePage('category');
            }}
            className="text-xs font-bold text-red-700 hover:underline"
          >
            {getTranslation(language, 'viewAll')} →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {opinionArticles.map((art) => (
            <div
              key={art.id}
              onClick={() => onArticleClick(art)}
              className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all cursor-pointer space-y-3 group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-900 text-white font-serif font-bold flex items-center justify-center shrink-0 text-sm">
                  {art.author.charAt(0)}
                </div>
                <div>
                  <h5 className="font-bold text-xs text-slate-900">{art.author}</h5>
                  <p className="text-[10px] text-slate-500">{art.authorRole}</p>
                </div>
              </div>

              <h4 className="font-serif font-bold text-sm text-slate-900 group-hover:text-red-700 transition-colors leading-snug line-clamp-2">
                "{language === 'np' ? art.titleNp : art.titleEn}"
              </h4>

              <p className="text-xs text-slate-600 line-clamp-2">
                {language === 'np' ? art.excerptNp : art.excerptEn}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Reels Shorts Modal Viewer */}
      {isReelModalOpen && activeReelIdx !== null && (
        <ReelsShortsModal
          reels={reelsStoriesData}
          initialIndex={activeReelIdx}
          isOpen={isReelModalOpen}
          onClose={() => setIsReelModalOpen(false)}
          language={language}
          onOpenArticle={onArticleClick ? (artId) => {
            const art = articles.find((a) => a.id === artId);
            if (art) onArticleClick(art);
          } : undefined}
          articles={articles}
        />
      )}
    </div>
  );
};
