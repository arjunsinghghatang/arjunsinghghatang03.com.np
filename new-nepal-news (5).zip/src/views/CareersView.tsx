import React, { useState } from 'react';
import { Briefcase, MapPin, Calendar, CheckCircle2, X, Send } from 'lucide-react';
import { Language, CareerJob } from '../types';
import { getTranslation } from '../data/translations';
import { careerJobsData } from '../data/newsData';

interface CareersViewProps {
  language: Language;
}

export const CareersView: React.FC<CareersViewProps> = ({ language }) => {
  const [selectedJob, setSelectedJob] = useState<CareerJob | null>(null);
  const [applicantSubmitted, setApplicantSubmitted] = useState(false);

  return (
    <div className="space-y-12 pb-12">
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'हाम्रो न्युजरुममा जोडिनुहोस्' : 'Join Our Newsroom'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {getTranslation(language, 'careers')}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'निष्पक्ष र खोजमूलक डिजिटल पत्रकारितामा आफ्नो उज्ज्वल भविष्य बनाउनुहोस्। न्यू नेपाल न्यूज प्रा. लि. ले वालिङ स्याङ्जा, पोखरा र काठमाडौँ न्युजरुमका लागि विभिन्न पदहरूमा अवसर प्रदान गर्दछ।'
            : 'Build your career in independent digital journalism. New Nepal News Pvt. Ltd. offers vibrant roles in Waling Syangja, Pokhara, and Kathmandu desks.'}
        </p>
      </div>

      {/* Jobs List */}
      <div className="space-y-6">
        {careerJobsData.map((job) => (
          <div
            key={job.id}
            className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs hover:shadow-lg transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
          >
            <div className="space-y-3 max-w-2xl">
              <div className="flex flex-wrap items-center gap-2">
                <span className="bg-red-50 text-red-700 text-xs font-bold uppercase px-2.5 py-0.5 rounded-md">
                  {language === 'np' ? job.departmentNp : job.departmentEn}
                </span>
                <span className="bg-slate-100 text-slate-700 text-xs font-semibold px-2.5 py-0.5 rounded-md">
                  {language === 'np' ? job.typeNp : job.typeEn}
                </span>
              </div>

              <h3 className="text-xl font-serif font-bold text-slate-900">
                {language === 'np' ? job.titleNp : job.titleEn}
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed">
                {language === 'np' ? job.descriptionNp : job.descriptionEn}
              </p>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-2">
                <span className="flex items-center gap-1 font-semibold text-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-red-600" />
                  {language === 'np' ? job.locationNp : job.locationEn}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Deadline: {job.deadline}
                </span>
              </div>
            </div>

            <button
              onClick={() => setSelectedJob(job)}
              className="bg-slate-900 hover:bg-red-700 text-white font-bold px-6 py-3 rounded-xl text-xs transition-colors shrink-0 cursor-pointer text-center"
            >
              Apply Online
            </button>
          </div>
        ))}
      </div>

      {/* Application Modal */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-2xl shadow-2xl overflow-hidden border border-slate-700 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h4 className="font-serif font-bold text-lg">
                  Apply for {language === 'np' ? selectedJob.titleNp : selectedJob.titleEn}
                </h4>
                <p className="text-xs text-slate-500">New Nepal News Pvt. Ltd. Hiring Desk</p>
              </div>
              <button
                onClick={() => {
                  setSelectedJob(null);
                  setApplicantSubmitted(false);
                }}
                className="p-1.5 bg-slate-800 text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {applicantSubmitted ? (
              <div className="text-center py-8 space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                <h4 className="text-base font-bold">Application Submitted!</h4>
                <p className="text-xs text-slate-400">
                  Our HR & Editorial board in Waling Syangja will review your application.
                </p>
                <button
                  onClick={() => {
                    setSelectedJob(null);
                    setApplicantSubmitted(false);
                  }}
                  className="bg-red-700 text-white text-xs font-bold px-5 py-2 rounded-xl"
                >
                  Close
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setApplicantSubmitted(true);
                }}
                className="space-y-3 text-xs"
              >
                <div>
                  <label className="block font-bold mb-1">
                    {language === 'np' ? 'पूरा नाम *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={language === 'np' ? 'उदा. निशा कोइराला' : 'e.g. Nisha Koirala'}
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold mb-1">
                      {language === 'np' ? 'इमेल *' : 'Email *'}
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="nisha@mail.com"
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">
                      {language === 'np' ? 'फोन नम्बर *' : 'Phone *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="+977-9800000000"
                      className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">
                    {language === 'np' ? 'बायोडाटा / लिङ्क' : 'Link to Portfolio / Resume / Articles'}
                  </label>
                  <input
                    type="url"
                    placeholder="https://drive.google.com/your-cv"
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">
                    {language === 'np' ? 'आवेदन पत्र / छोटो विवरण' : 'Cover Note / Why join NNN?'}
                  </label>
                  <textarea
                    rows={3}
                    required
                    placeholder={
                      language === 'np'
                        ? 'तपाईंको पत्रकारिता सम्बन्धी अनुभव र योग्यताको विवरण...'
                        : 'Briefly state your journalism experience and availability...'
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3 rounded-xl transition-colors cursor-pointer text-xs flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>
                    {language === 'np' ? 'आवेदन पेस गर्नुहोस्' : 'Submit Application'}
                  </span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
