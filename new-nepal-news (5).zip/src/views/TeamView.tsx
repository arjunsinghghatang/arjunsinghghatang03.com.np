import React from 'react';
import { Users, Mail, Twitter, Linkedin, Facebook, ShieldCheck, Award } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';
import { teamMembersData } from '../data/newsData';

interface TeamViewProps {
  language: Language;
}

export const TeamView: React.FC<TeamViewProps> = ({ language }) => {
  return (
    <div className="space-y-12 pb-12">
      {/* Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'नेतृत्व तथा न्युजरुम' : 'Leadership & Newsroom'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {getTranslation(language, 'editorialTeam')}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'न्यू नेपाल न्यूज प्रा. लि. लाई स्वतन्त्रता र निष्पक्षताका साथ हाँक्ने सम्पादक, खोज पत्रकार र मिडिया टोली।'
            : 'Meet the experienced editors, investigative reporters, and media executives steering New Nepal News Pvt. Ltd. with unyielding editorial independence.'}
        </p>
      </div>

      {/* Team Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {teamMembersData.map((member) => (
          <div
            key={member.id}
            className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
          >
            <div>
              <div className="relative h-64 overflow-hidden bg-slate-100">
                <img
                  src={member.avatar}
                  alt={member.nameEn}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <h3 className="text-xl font-serif font-bold text-white">
                    {language === 'np' ? member.nameNp : member.nameEn}
                  </h3>
                  <p className="text-xs text-amber-300 font-semibold">
                    {language === 'np' ? member.roleNp : member.roleEn}
                  </p>
                </div>
              </div>

              <div className="p-6 space-y-3">
                <p className="text-xs text-slate-600 leading-relaxed">
                  {language === 'np' ? member.bioNp : member.bioEn}
                </p>
              </div>
            </div>

            <div className="p-6 pt-0 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <a
                href={`mailto:${member.email}`}
                className="flex items-center gap-1.5 text-slate-700 hover:text-red-700 font-medium"
              >
                <Mail className="w-3.5 h-3.5 text-red-600" />
                <span className="truncate">{member.email}</span>
              </a>

              <div className="flex items-center gap-2">
                {member.socials.facebook && (
                  <a
                    href={member.socials.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 hover:text-blue-600"
                  >
                    <Facebook className="w-3.5 h-3.5" />
                  </a>
                )}
                {member.socials.twitter && (
                  <a
                    href={member.socials.twitter}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 hover:text-sky-500"
                  >
                    <Twitter className="w-3.5 h-3.5" />
                  </a>
                )}
                {member.socials.linkedin && (
                  <a
                    href={member.socials.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 hover:text-blue-700"
                  >
                    <Linkedin className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Code of Ethics Section */}
      <section className="bg-slate-900 text-white p-8 rounded-3xl border border-slate-800 space-y-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-8 h-8 text-emerald-400" />
          <div>
            <h3 className="text-xl font-serif font-bold text-white">
              {language === 'np' ? 'पत्रकारिता आचारसंहिता' : 'Press Ethics Charter'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'np'
                ? 'देश तथा विदेशका पाठकहरूप्रति हाम्रो प्रतिबद्धता'
                : 'Our Pledge to Readers across Nepal and Overseas'}
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-4xl">
          {language === 'np'
            ? 'न्यू नेपाल न्यूज प्रा. लि. का सम्पूर्ण पत्रकारहरू प्रेस काउन्सिल नेपालको आचारसंहिताप्रति पूर्ण प्रतिबद्ध छन्। हामी बहु-स्रोत पुष्टि, निष्पक्ष समाचार र सबै पक्षको विचार समेट्न ग्यारेन्टी गर्दछौं।'
            : 'At New Nepal News Pvt. Ltd., all journalists strictly adhere to the Press Council Nepal guidelines. We guarantee strict multi-source verification, mandatory right-to-reply for criticized subjects, and non-partisan coverage.'}
        </p>
      </section>
    </div>
  );
};
