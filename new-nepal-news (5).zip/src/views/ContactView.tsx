import React, { useState } from 'react';
import { Mail, Phone, MapPin, Globe, Send, CheckCircle2, Clock, Building2 } from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';

interface ContactViewProps {
  language: Language;
}

export const ContactView: React.FC<ContactViewProps> = ({ language }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="space-y-12 pb-12">
      {/* Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'सम्पर्क गर्नुहोस्' : 'Get in Touch'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {getTranslation(language, 'contactUs')}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'समाचार जिज्ञासा, प्रेस विज्ञप्ति, प्रतिक्रिया वा विज्ञापन सम्बन्धी जानकारीका लागि स्याङ्जा वालिङस्थित हाम्रो प्रधान कार्यालयमा सम्पर्क गर्नुहोस्।'
            : 'Reach out to our main head office in Waling, Syangja for news inquiries, press releases, editorial feedback, or advertisement bookings.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Contact Info Sidebar (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
            <h3 className="text-xl font-serif font-bold text-slate-900 border-b border-slate-200 pb-3">
              {language === 'np' ? 'प्रधान कार्यालयको विवरण' : 'Head Office Details'}
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">
                    {language === 'np' ? 'मुख्य कार्यालयको ठेगाना' : 'Main Office Address'}
                  </p>
                  <p className="text-slate-600">
                    {language === 'np' ? 'वालिङ, स्याङ्जा, गण्डकी प्रदेश, नेपाल' : 'Waling, Syangja, Gandaki Province, Nepal'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">
                    {language === 'np' ? 'आधिकारिक इमेल' : 'Official Email Desk'}
                  </p>
                  <p className="text-slate-700 font-medium">newnepalnews11@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">
                    {language === 'np' ? 'फोन नम्बर' : 'Phone Line'}
                  </p>
                  <p className="text-slate-700 font-medium">+977-063-440555</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">
                    {language === 'np' ? 'आधिकारिक वेबसाइट' : 'Official Website'}
                  </p>
                  <p className="text-red-700 font-mono font-bold">www.newnepalnews.com.np</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">
                    {language === 'np' ? 'न्युजरुम समय' : 'Newsroom Hours'}
                  </p>
                  <p className="text-slate-600">
                    {language === 'np' ? '२४/७ निरन्तर समाचार सम्प्रेषण' : '24/7 Live Publishing Operations'}
                  </p>
                  <p className="text-slate-500">
                    {language === 'np'
                      ? 'प्रशासनिक कार्य: आइतबार - शुक्रबार (बिहान ९:०० - बेलुका ६:००)'
                      : 'Admin Desk: Sun - Fri (9:00 AM - 6:00 PM)'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Syangja Waling Map Representation */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 space-y-3">
            <h4 className="font-serif font-bold text-base text-amber-300">
              {language === 'np' ? 'स्थान: वालिङ, स्याङ्जा' : 'Location: Waling, Syangja'}
            </h4>
            <div className="w-full h-48 bg-slate-800 rounded-2xl overflow-hidden relative border border-slate-700 flex items-center justify-center text-center p-4">
              <iframe
                title="Waling Syangja Map"
                src="https://maps.google.com/maps?q=Waling%20Syangja%20Nepal&t=&z=13&ie=UTF8&iwloc=&output=embed"
                className="w-full h-full border-0 rounded-xl"
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </div>

        {/* Interactive Contact Form (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-xs">
          {submitted ? (
            <div className="text-center py-12 space-y-4">
              <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto" />
              <h3 className="text-2xl font-serif font-bold text-slate-900">
                Message Received!
              </h3>
              <p className="text-slate-600 text-sm max-w-md mx-auto">
                Thank you for contacting New Nepal News Pvt. Ltd. Our editorial team in Waling, Syangja will respond to your inquiry promptly.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
                }}
                className="bg-red-700 hover:bg-red-800 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <h3 className="text-xl font-serif font-bold text-slate-900 border-b border-slate-200 pb-3">
                Send Us a Direct Message
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aakash Sharma"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    placeholder="+977-9800000000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Inquiry Subject
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
                  >
                    <option value="">General Inquiry</option>
                    <option value="editorial">Editorial Feedback / News Correction</option>
                    <option value="advertisement">Advertisement / Sponsored Content</option>
                    <option value="press_release">Press Release Submission</option>
                    <option value="partnership">Media Partnership</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Your Message *
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="Write your detailed query or press message..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-red-500"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md text-sm"
              >
                <Send className="w-4 h-4" />
                <span>Submit Inquiry to New Nepal News</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
