import React, { useState } from 'react';
import {
  Megaphone,
  CheckCircle2,
  Send,
  Calculator,
  Newspaper,
  Zap,
  Video,
  Camera,
  FileText,
  DollarSign,
  Award,
} from 'lucide-react';
import { Language } from '../types';
import { getTranslation } from '../data/translations';
import { serviceItemsData, adPackagesData } from '../data/newsData';

interface AdvertiseViewProps {
  language: Language;
}

export const AdvertiseView: React.FC<AdvertiseViewProps> = ({ language }) => {
  // Interactive Rate Card Calculator
  const [selectedPlacement, setSelectedPlacement] = useState<'leaderboard' | 'sidebar' | 'sponsored' | 'video'>('leaderboard');
  const [durationMonths, setDurationMonths] = useState<number>(1);

  const priceRates = {
    leaderboard: 25000,
    sidebar: 18000,
    sponsored: 30000,
    video: 45000,
  };

  const calculatedTotal = priceRates[selectedPlacement] * durationMonths;

  const [bookingSubmitted, setBookingSubmitted] = useState(false);

  return (
    <div className="space-y-12 pb-12">
      {/* Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-4">
        <span className="bg-red-700 text-white text-xs font-bold uppercase px-3 py-1 rounded-full tracking-wider">
          {language === 'np' ? 'विज्ञापन तथा मिडिया सेवाहरू' : 'Media Services & Rate Card'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-black text-white">
          {getTranslation(language, 'advertiseWithUs')}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-2xl leading-relaxed">
          {language === 'np'
            ? 'नेपाल तथा विदेशका १५ लाख भन्दा बढी डिजिटल पाठकहरूसम्म आफ्नो व्यवसाय र ब्रान्डको प्रचारप्रसार गर्नुहोस्।'
            : 'Amplify your business, corporate press releases, and brand reach across 1.5 Million+ monthly digital news readers in Nepal and the diaspora.'}
        </p>
      </div>

      {/* Services Showcase */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl font-serif font-black text-slate-900">
            {language === 'np' ? 'हाम्रा डिजिटल मिडिया सेवाहरू' : 'Our Digital Media Services'}
          </h2>
          <p className="text-xs text-slate-500">
            {language === 'np'
              ? 'न्यू नेपाल न्यूज प्रा. लि. द्वारा संचालित बहुआयामिक डिजिटल मिडिया सेवाहरू'
              : 'Comprehensive digital media publishing solutions operated by New Nepal News Pvt. Ltd.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {serviceItemsData.map((svc) => (
            <div
              key={svc.id}
              className="bg-white border border-slate-200 p-6 rounded-2xl shadow-xs hover:shadow-lg transition-all space-y-3"
            >
              <div className="w-12 h-12 bg-red-50 text-red-700 rounded-xl flex items-center justify-center font-bold">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-base font-serif font-bold text-slate-900">
                {language === 'np' ? svc.titleNp : svc.titleEn}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {language === 'np' ? svc.descNp : svc.descEn}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Advertising Packages */}
      <section className="space-y-6 pt-4">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl font-serif font-black text-slate-900">
            {language === 'np' ? 'मासिक विज्ञापन प्याकेजहरू' : 'Monthly Advertising Bundles'}
          </h2>
          <p className="text-xs text-slate-500">
            {language === 'np'
              ? 'स्थानीय तथा राष्ट्रिय ब्रान्डहरू, संघसंस्था र सरकारी सूचनाका लागि लचिलो विज्ञापन योजनाहरू'
              : 'Flexible monthly packages designed for national brands, local businesses, and government press releases.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {adPackagesData.map((pkg) => (
            <div
              key={pkg.id}
              className={`rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6 relative transition-all ${
                pkg.recommended
                  ? 'bg-slate-900 text-white border-2 border-red-600 shadow-2xl scale-105'
                  : 'bg-white text-slate-900 border border-slate-200 shadow-xs'
              }`}
            >
              {pkg.recommended && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-red-700 text-white font-black text-[10px] uppercase px-3 py-1 rounded-full shadow-md tracking-wider">
                  Most Popular
                </span>
              )}

              <div className="space-y-3">
                <h3 className="text-lg font-serif font-bold">
                  {language === 'np' ? pkg.titleNp : pkg.titleEn}
                </h3>
                <div className="text-2xl font-black text-red-600 dark:text-amber-400">
                  {pkg.priceNpr}
                </div>
                <p className="text-xs opacity-80 font-medium">{pkg.impressions}</p>

                <ul className="space-y-2 text-xs pt-4 border-t border-slate-200 dark:border-slate-800">
                  {(language === 'np' ? pkg.featuresNp : pkg.featuresEn).map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => {
                  const el = document.getElementById('ad-booking-form');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`w-full font-bold py-3 rounded-xl text-xs transition-colors cursor-pointer text-center ${
                  pkg.recommended
                    ? 'bg-red-700 hover:bg-red-800 text-white'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                Book This Package
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Ad Rate Calculator & Booking Form */}
      <section id="ad-booking-form" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-6">
        {/* Rate Calculator (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-6 shadow-xl">
          <div className="flex items-center gap-2.5 text-amber-300 font-bold text-base border-b border-slate-800 pb-3">
            <Calculator className="w-5 h-5" />
            <span>Interactive Ad Rate Calculator</span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Select Ad Format</label>
              <select
                value={selectedPlacement}
                onChange={(e: any) => setSelectedPlacement(e.target.value)}
                className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-red-500"
              >
                <option value="leaderboard">Top Leaderboard Banner (NPR 25,000/mo)</option>
                <option value="sidebar">Sidebar Rectangle Banner (NPR 18,000/mo)</option>
                <option value="sponsored">Sponsored Article / Press Release (NPR 30,000/mo)</option>
                <option value="video">Video Pre-roll Ad Placement (NPR 45,000/mo)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Duration (Months)</label>
              <div className="flex items-center gap-2">
                {[1, 3, 6, 12].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setDurationMonths(m)}
                    className={`flex-1 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
                      durationMonths === m
                        ? 'bg-red-700 text-white border-red-600'
                        : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {m} {m === 1 ? 'Month' : 'Months'}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1 text-center">
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Estimated Campaign Total</p>
              <p className="text-3xl font-black text-amber-300 font-serif">
                NPR {calculatedTotal.toLocaleString()}
              </p>
              <p className="text-[10px] text-slate-500">Includes taxes & monthly analytics report</p>
            </div>
          </div>
        </div>

        {/* Ad Booking Form (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs">
          {bookingSubmitted ? (
            <div className="text-center py-12 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <h3 className="text-xl font-serif font-bold text-slate-900">
                Ad Booking Request Submitted!
              </h3>
              <p className="text-xs text-slate-600">
                Our business editor in Waling Syangja will contact you with artwork specifications and contract details.
              </p>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setBookingSubmitted(true);
              }}
              className="space-y-4 text-xs"
            >
              <h3 className="text-xl font-serif font-bold text-slate-900 border-b border-slate-200 pb-3">
                Book Advertisement or Press Release
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Company / Brand Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Syangja Organic Agro Pvt. Ltd."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contact Person *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Adhikari"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    placeholder="info@brand.com"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="+977-9800000000"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Campaign Objective / Instructions</label>
                <textarea
                  rows={4}
                  placeholder="Provide campaign start date, target audience, or press release copy..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-3.5 rounded-xl transition-colors cursor-pointer shadow-md text-sm"
              >
                Submit Campaign Request
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
};
