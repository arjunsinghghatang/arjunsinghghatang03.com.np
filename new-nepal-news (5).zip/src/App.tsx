import React, { useState, useEffect } from 'react';
import {
  NewsArticle,
  PageView,
  CategoryId,
  Language,
} from './types';
import { articlesData } from './data/newsData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { BreakingTicker } from './components/BreakingTicker';
import { SingleArticleModal } from './components/SingleArticleModal';
import { SubmitTipModal } from './components/SubmitTipModal';
import { AiAssistantModal } from './components/AiAssistantModal';
import { SearchModal } from './components/SearchModal';
import { BookmarksDrawer } from './components/BookmarksDrawer';
import { TopAdPlayingBar, StickyBottomAdPlayingBar } from './components/AdPlayingBars';
import { ZoomController } from './components/ZoomController';

// Views
import { HomeView } from './views/HomeView';
import { LatestNewsView } from './views/LatestNewsView';
import { CategoryView } from './views/CategoryView';
import { AboutView } from './views/AboutView';
import { TeamView } from './views/TeamView';
import { ContactView } from './views/ContactView';
import { AdvertiseView } from './views/AdvertiseView';
import { CareersView } from './views/CareersView';
import { LegalView } from './views/LegalView';
import { GalleryView } from './views/GalleryView';
import { AnalyticsDashboard } from './views/AnalyticsDashboard';
import { ReelsView } from './views/ReelsView';

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId | null>(null);

  // Active Articles state with user generated posts
  const [articles, setArticles] = useState<NewsArticle[]>(articlesData);

  const handlePostCreated = (newPost: NewsArticle) => {
    setArticles((prev) => [newPost, ...prev]);
  };

  // Active Selected Article Modal
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  // Modal Flags
  const [isSubmitTipOpen, setIsSubmitTipOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);

  // Bookmarks state (persist in localStorage)
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nnn_bookmarks');
      return saved ? JSON.parse(saved) : ['art-1'];
    } catch {
      return ['art-1'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('nnn_bookmarks', JSON.stringify(bookmarkedIds));
    } catch {
      // Ignore fallback
    }
  }, [bookmarkedIds]);

  const handleLanguageToggle = () => {
    setLanguage((prev) => (prev === 'en' ? 'np' : 'en'));
  };

  const handleBookmarkToggle = (articleId: string) => {
    setBookmarkedIds((prev) =>
      prev.includes(articleId) ? prev.filter((id) => id !== articleId) : [...prev, articleId]
    );
  };

  const bookmarkedArticles = articlesData.filter((a) => bookmarkedIds.includes(a.id));

  const handleArticleClick = (article: NewsArticle) => {
    setSelectedArticle(article);
    setLanguage('np'); // Automatically translate news to Nepali language
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col justify-between selection:bg-red-700 selection:text-white">
      {/* Top Header */}
      <div>
        <Header
          language={language}
          onLanguageToggle={handleLanguageToggle}
          currentPage={currentPage}
          onNavigatePage={(page) => {
            setCurrentPage(page);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => setSelectedCategory(cat)}
          bookmarkCount={bookmarkedIds.length}
          onOpenBookmarks={() => setIsBookmarksOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenSubmitTip={() => setIsSubmitTipOpen(true)}
          onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        />

        {/* Top Playing Leaderboard Ad Bar */}
        <TopAdPlayingBar
          language={language}
          onOpenAdvertiseModal={() => {
            setCurrentPage('services');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />

        {/* Breaking News Ticker on top of homepage */}
        {currentPage === 'home' && (
          <BreakingTicker
            articles={articles}
            language={language}
            onArticleClick={handleArticleClick}
          />
        )}

        {/* Main Body View Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-8 py-6 w-full flex-1">
          {currentPage === 'home' && (
            <HomeView
              articles={articles}
              language={language}
              onArticleClick={handleArticleClick}
              onBookmarkToggle={handleBookmarkToggle}
              bookmarkedIds={bookmarkedIds}
              onNavigatePage={(page) => {
                setCurrentPage(page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onSelectCategory={(cat) => setSelectedCategory(cat)}
              onOpenSubmitTip={() => setIsSubmitTipOpen(true)}
              onPostCreated={handlePostCreated}
            />
          )}

          {currentPage === 'latest' && (
            <LatestNewsView
              articles={articles}
              language={language}
              onArticleClick={handleArticleClick}
              onBookmarkToggle={handleBookmarkToggle}
              bookmarkedIds={bookmarkedIds}
            />
          )}

          {currentPage === 'reels' && (
            <ReelsView
              language={language}
              articles={articles}
              onArticleClick={handleArticleClick}
            />
          )}

          {currentPage === 'category' && (
            <CategoryView
              categoryId={selectedCategory}
              articles={articles}
              language={language}
              onArticleClick={handleArticleClick}
              onBookmarkToggle={handleBookmarkToggle}
              bookmarkedIds={bookmarkedIds}
            />
          )}

          {currentPage === 'about' && <AboutView language={language} />}

          {currentPage === 'team' && <TeamView language={language} />}

          {currentPage === 'contact' && <ContactView language={language} />}

          {currentPage === 'services' && <AdvertiseView language={language} />}

          {currentPage === 'careers' && <CareersView language={language} />}

          {currentPage === 'legal' && <LegalView language={language} />}

          {currentPage === 'gallery' && <GalleryView language={language} />}

          {currentPage === 'analytics' && (
            <AnalyticsDashboard
              language={language}
              articles={articles}
              onArticleClick={handleArticleClick}
            />
          )}
        </main>
      </div>

      {/* Footer */}
      <Footer
        language={language}
        onNavigatePage={(page) => {
          setCurrentPage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectCategory={(cat) => setSelectedCategory(cat)}
      />

      {/* Single News Article Detail Reader Modal */}
      <SingleArticleModal
        article={selectedArticle}
        language={language}
        onClose={() => setSelectedArticle(null)}
        onSelectArticle={handleArticleClick}
        allArticles={articlesData}
        isBookmarked={selectedArticle ? bookmarkedIds.includes(selectedArticle.id) : false}
        onBookmarkToggle={handleBookmarkToggle}
      />

      {/* Submit Tip Modal */}
      <SubmitTipModal
        isOpen={isSubmitTipOpen}
        onClose={() => setIsSubmitTipOpen(false)}
        language={language}
      />

      {/* AI News Desk Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        language={language}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        language={language}
        articles={articlesData}
        onSelectArticle={handleArticleClick}
      />

      {/* Saved Bookmarks Drawer */}
      <BookmarksDrawer
        isOpen={isBookmarksOpen}
        onClose={() => setIsBookmarksOpen(false)}
        language={language}
        bookmarkedArticles={bookmarkedArticles}
        onSelectArticle={handleArticleClick}
        onRemoveBookmark={handleBookmarkToggle}
        onClearAllBookmarks={() => setBookmarkedIds([])}
      />

      {/* Floating Bottom Sticky Ad Playing Bar */}
      <StickyBottomAdPlayingBar
        language={language}
        onOpenAdvertiseModal={() => {
          setCurrentPage('services');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Floating Interactive Zoom Controller for Mobile / Tablet / Desktop */}
      <ZoomController language={language} />
    </div>
  );
}
